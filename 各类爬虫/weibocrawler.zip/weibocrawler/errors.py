#-*- coding: utf-8 -*-

'''
@author: Jiajun Huang
created at 2013/12/7
'''

from urllib2 import URLError

class UnsuspectedPageStructError(Exception):
    pass

class JsonDataParsingError(Exception):
    pass

