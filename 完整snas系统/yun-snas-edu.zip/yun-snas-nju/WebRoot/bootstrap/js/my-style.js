 $(document).ready(function(){
        $('#left-links-li li').click(function(){
            $(this).siblings().removeClass('active');
            $(this).addClass('active');

        })

    })