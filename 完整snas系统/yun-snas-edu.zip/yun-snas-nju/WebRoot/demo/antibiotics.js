var antibiotics = [
  { bacteria: "安全监管", pos: 800, neg: 5, middle: 2, gram: "positive" },
  { bacteria: "供应商", pos: 10, neg: 0.8, middle: 0.09, gram: "positive" },
  { bacteria: "保质期", pos: 3, neg: 0.1, middle: 0.1, gram: "positive" },
  { bacteria: "食品安全", pos: 850, neg: 1.2, middle: 1, gram: "positive" },
  { bacteria: "洋快餐", pos: 1, neg: 2, middle: 0.02, gram: "negative" },
  { bacteria: "星巴克", pos: 850, neg: 2, middle: 0.4, gram: "negative" },
  { bacteria: "狗肉", pos: 100, neg: 0.4, middle: 0.1, gram: "negative" },
  { bacteria: "食药监", pos: 1, neg: 0.4, middle: 0.008, gram: "positive" },
  { bacteria: "宣传周", pos: 870, neg: 1, middle: 1.6, gram: "positive" },
  { bacteria: "学校食堂", pos: 0.001, neg: 0.01, middle: 0.007, gram: "positive" },
  { bacteria: "麦当劳", pos: 1, neg: 1, middle: 0.1, gram: "negative" },
  { bacteria: "添加剂", pos: 0.03, neg: 0.03, middle: 0.001, gram: "negative" },
  { bacteria: "地沟油", pos: 0.007, neg: 0.1, middle: 0.001, gram: "negative" },
  { bacteria: "转基因", pos: 0.001, neg: 14, middle: 10, gram: "negative" },
  { bacteria: "洋快餐", pos: 0.005, neg: 10, middle: 40, gram: "negative" },
  { bacteria: "福喜", pos: 0.005, neg: 11, middle: 10, gram: "negative" }
];