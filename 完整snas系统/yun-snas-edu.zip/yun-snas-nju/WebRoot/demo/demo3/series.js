userNameList = ['snas','test','huawei','WIC','spaq','tt']
tagDistributeArray=  new Array(
[
		{
            name: '食品安全1',
            data: [542, 332, 11],
            stack: 'neg'
        },
		{
            name: '昆山爆炸',
            data: [332, 324, 11],
            stack: 'neg'
        },
		{
            name: '央视',
            data: [322, 523, 11],
            stack: 'pos'
        }, 
		{
            name: '苹果手机',
            data: [332, 142, 11],
            stack: 'pos'
        }
		]
,
[
		{
            name: '食品安全2',
            data: [542, 909, 44],
            stack: 'neg'
        },
		{
            name: '昆山爆炸',
            data: [332, 909, 1444],
            stack: 'neg'
        },
		{
            name: '央视',
            data: [322, 909, 643],
            stack: 'pos'
        }, 
		{
            name: '苹果手机',
            data: [332, 909, 422],
            stack: 'pos'
        }
],
[
		{
            name: '食品安全3',
            data: [542, 332, 888],
            stack: 'neg'
        },
		{
            name: '昆山爆炸',
            data: [332, 324, 888],
            stack: 'neg'
        },
		{
            name: '央视',
            data: [322, 523, 888],
            stack: 'pos'
        }, 
		{
            name: '苹果手机',
            data: [332, 142, 888],
            stack: 'pos'
        }
],
[
		{
            name: '食品安全4',
            data: [222, 332, 44],
            stack: 'neg'
        },
		{
            name: '昆山爆炸',
            data: [222, 324, 1444],
            stack: 'neg'
        },
		{
            name: '央视',
            data: [222, 523, 643],
            stack: 'pos'
        }, 
		{
            name: '苹果手机',
            data: [222, 142, 422],
            stack: 'pos'
        }
],
[
		{
            name: '食品安全5',
            data: [9, 332, 44],
            stack: 'neg'
        },
		{
            name: '昆山爆炸',
            data: [9, 324, 1444],
            stack: 'neg'
        },
		{
            name: '央视',
            data: [9, 523, 643],
            stack: 'pos'
        }, 
		{
            name: '苹果手机',
            data: [9, 142, 422],
            stack: 'pos'
        }
],
[
		{
            name: '食品安全6',
            data: [542, 10, 44],
            stack: 'neg'
        },
		{
            name: '昆山爆炸',
            data: [332, 10, 1444],
            stack: 'neg'
        },
		{
            name: '央视',
            data: [322, 10, 643],
            stack: 'pos'
        }, 
		{
            name: '苹果手机',
            data: [332, 10, 422],
            stack: 'pos'
        }
],
[
		{
            name: 'default',
            data: [5, 5, 5],
            stack: 'neg'
        },
		{
            name: '昆山爆炸',
            data: [5, 5, 5],
            stack: 'neg'
        },
		{
            name: '央视',
            data: [5, 5, 5],
            stack: 'pos'
        }, 
		{
            name: '苹果手机',
            data: [5, 5, 5],
            stack: 'pos'
        }
]
)
var series=[
		{
            name: '食品安全',
            data: [542, 332, 44],
            stack: 'neg'
        },
		{
            name: '昆山爆炸',
            data: [332, 324, 1444],
            stack: 'neg'
        },
		{
            name: '央视',
            data: [322, 523, 643],
            stack: 'pos'
        }, 
		{
            name: '苹果手机',
            data: [332, 142, 422],
            stack: 'pos'
        }
		];