﻿var	colors = Highcharts.getOptions().colors;
userNameList = ['snas','test','huawei','WIC','spaq','tt']
var topicCategoriesArray = new Array(
['食品安全1', '反腐', '世界杯', '暴恐案', '青岛油管爆炸'],
['食品安全2', '反腐', '世界杯', '暴恐案', '青岛油管爆炸'],
['食品安全3', '反腐', '世界杯', '暴恐案', '青岛油管爆炸'],
['食品安全4', '反腐', '世界杯', '暴恐案', '青岛油管爆炸'],
['食品安全5', '反腐', '世界杯', '暴恐案', '青岛油管爆炸'],
['食品安全6', '反腐', '世界杯', '暴恐案', '青岛油管爆炸'],
['default', '反腐', '世界杯', '暴恐案', '青岛油管爆炸']
)
topicArray = new Array(
[
		{
            y: 25,
            color: colors[0],
            drilldown: 
			{
                name: '食品安全',
                categories: ['转基因', '地沟油', '麦当劳','狗肉'],
                data: [7, 5, 10,3],
                color: colors[0]
            }
        }, 
		{
            y: 35,
            color: colors[1],
            drilldown: 
			{
                name: '反腐',
                categories: ['薄熙来', '铁道部王志军', '周永康被抓', '徐才厚落马'],
                data: [3, 6, 13, 13],
                color: colors[1]
            }
        }, 
		{
            y: 27,
            color: colors[2],
            drilldown: 
			{
                name: '世界杯',
                categories: ['无助的C罗', '内马尔重伤', '巴西惨败', '德国夺冠', 
				'阿根廷惜败','梅西1V5', '西班牙小组未出现'],
                data: [1, 3, 5, 9, 4, 3, 2],
                color: colors[2]
            }
        }, 
		{
            y: 11,
            color: colors[3],
            drilldown: 
			{
                name: '暴恐案',
                categories: ['乌鲁木齐火车南站', '巴楚暴力案','云南'],
                data: [4, 1, 6],
                color: colors[3]
            }
        }, 
		{
            y: 2,
            color: colors[4],
            drilldown: 
			{
                name: '青岛油管爆炸',
                categories: ['黄岛区输油管', '中石化'],
                data: [ 0.5, 1.5],
                color: colors[4]
            }
        }
],
[
		{
            y: 25,
            color: colors[0],
            drilldown: 
			{
                name: '食品安全',
                categories: ['转基因', '地沟油', '麦当劳','狗肉'],
                data: [7, 5, 10,3],
                color: colors[0]
            }
        }, 
		{
            y: 35,
            color: colors[1],
            drilldown: 
			{
                name: '反腐',
                categories: ['薄熙来', '铁道部王志军', '周永康被抓', '徐才厚落马'],
                data: [3, 6, 13, 13],
                color: colors[1]
            }
        }, 
		{
            y: 27,
            color: colors[2],
            drilldown: 
			{
                name: '世界杯',
                categories: ['无助的C罗', '内马尔重伤', '巴西惨败', '德国夺冠', 
				'阿根廷惜败','梅西1V5', '西班牙小组未出现'],
                data: [1, 3, 5, 9, 4, 3, 2],
                color: colors[2]
            }
        }, 
		{
            y: 11,
            color: colors[3],
            drilldown: 
			{
                name: '暴恐案',
                categories: ['乌鲁木齐火车南站', '巴楚暴力案','云南'],
                data: [4, 1, 6],
                color: colors[3]
            }
        }, 
		{
            y: 2,
            color: colors[4],
            drilldown: 
			{
                name: '青岛油管爆炸',
                categories: ['黄岛区输油管', '中石化'],
                data: [ 0.5, 1.5],
                color: colors[4]
            }
        }
],
[
		{
            y: 25,
            color: colors[0],
            drilldown: 
			{
                name: '食品安全',
                categories: ['转基因', '地沟油', '麦当劳','狗肉'],
                data: [7, 5, 10,3],
                color: colors[0]
            }
        }, 
		{
            y: 35,
            color: colors[1],
            drilldown: 
			{
                name: '反腐',
                categories: ['薄熙来', '铁道部王志军', '周永康被抓', '徐才厚落马'],
                data: [3, 6, 13, 13],
                color: colors[1]
            }
        }, 
		{
            y: 27,
            color: colors[2],
            drilldown: 
			{
                name: '世界杯',
                categories: ['无助的C罗', '内马尔重伤', '巴西惨败', '德国夺冠', 
				'阿根廷惜败','梅西1V5', '西班牙小组未出现'],
                data: [1, 3, 5, 9, 4, 3, 2],
                color: colors[2]
            }
        }, 
		{
            y: 11,
            color: colors[3],
            drilldown: 
			{
                name: '暴恐案',
                categories: ['乌鲁木齐火车南站', '巴楚暴力案','云南'],
                data: [4, 1, 6],
                color: colors[3]
            }
        }, 
		{
            y: 2,
            color: colors[4],
            drilldown: 
			{
                name: '青岛油管爆炸',
                categories: ['黄岛区输油管', '中石化'],
                data: [ 0.5, 1.5],
                color: colors[4]
            }
        }
],
[
		{
            y: 25,
            color: colors[0],
            drilldown: 
			{
                name: '食品安全',
                categories: ['转基因', '地沟油', '麦当劳','狗肉'],
                data: [7, 5, 10,3],
                color: colors[0]
            }
        }, 
		{
            y: 35,
            color: colors[1],
            drilldown: 
			{
                name: '反腐',
                categories: ['薄熙来', '铁道部王志军', '周永康被抓', '徐才厚落马'],
                data: [3, 6, 13, 13],
                color: colors[1]
            }
        }, 
		{
            y: 27,
            color: colors[2],
            drilldown: 
			{
                name: '世界杯',
                categories: ['无助的C罗', '内马尔重伤', '巴西惨败', '德国夺冠', 
				'阿根廷惜败','梅西1V5', '西班牙小组未出现'],
                data: [1, 3, 5, 9, 4, 3, 2],
                color: colors[2]
            }
        }, 
		{
            y: 11,
            color: colors[3],
            drilldown: 
			{
                name: '暴恐案',
                categories: ['乌鲁木齐火车南站', '巴楚暴力案','云南'],
                data: [4, 1, 6],
                color: colors[3]
            }
        }, 
		{
            y: 2,
            color: colors[4],
            drilldown: 
			{
                name: '青岛油管爆炸',
                categories: ['黄岛区输油管', '中石化'],
                data: [ 0.5, 1.5],
                color: colors[4]
            }
        }
],
[
		{
            y: 25,
            color: colors[0],
            drilldown: 
			{
                name: '食品安全',
                categories: ['转基因', '地沟油', '麦当劳','狗肉'],
                data: [7, 5, 10,3],
                color: colors[0]
            }
        }, 
		{
            y: 35,
            color: colors[1],
            drilldown: 
			{
                name: '反腐',
                categories: ['薄熙来', '铁道部王志军', '周永康被抓', '徐才厚落马'],
                data: [3, 6, 13, 13],
                color: colors[1]
            }
        }, 
		{
            y: 27,
            color: colors[2],
            drilldown: 
			{
                name: '世界杯',
                categories: ['无助的C罗', '内马尔重伤', '巴西惨败', '德国夺冠', 
				'阿根廷惜败','梅西1V5', '西班牙小组未出现'],
                data: [1, 3, 5, 9, 4, 3, 2],
                color: colors[2]
            }
        }, 
		{
            y: 11,
            color: colors[3],
            drilldown: 
			{
                name: '暴恐案',
                categories: ['乌鲁木齐火车南站', '巴楚暴力案','云南'],
                data: [4, 1, 6],
                color: colors[3]
            }
        }, 
		{
            y: 2,
            color: colors[4],
            drilldown: 
			{
                name: '青岛油管爆炸',
                categories: ['黄岛区输油管', '中石化'],
                data: [ 0.5, 1.5],
                color: colors[4]
            }
        }
],
[
		{
            y: 25,
            color: colors[0],
            drilldown: 
			{
                name: '食品安全',
                categories: ['转基因', '地沟油', '麦当劳','狗肉'],
                data: [7, 5, 10,3],
                color: colors[0]
            }
        }, 
		{
            y: 35,
            color: colors[1],
            drilldown: 
			{
                name: '反腐',
                categories: ['薄熙来', '铁道部王志军', '周永康被抓', '徐才厚落马'],
                data: [3, 6, 13, 13],
                color: colors[1]
            }
        }, 
		{
            y: 27,
            color: colors[2],
            drilldown: 
			{
                name: '世界杯',
                categories: ['无助的C罗', '内马尔重伤', '巴西惨败', '德国夺冠', 
				'阿根廷惜败','梅西1V5', '西班牙小组未出现'],
                data: [1, 3, 5, 9, 4, 3, 2],
                color: colors[2]
            }
        }, 
		{
            y: 11,
            color: colors[3],
            drilldown: 
			{
                name: '暴恐案',
                categories: ['乌鲁木齐火车南站', '巴楚暴力案','云南'],
                data: [4, 1, 6],
                color: colors[3]
            }
        }, 
		{
            y: 2,
            color: colors[4],
            drilldown: 
			{
                name: '青岛油管爆炸',
                categories: ['黄岛区输油管', '中石化'],
                data: [ 0.5, 1.5],
                color: colors[4]
            }
        }
],
[
		{
            y: 20,
            color: colors[0],
            drilldown: 
			{
                name: '食品安全',
                categories: ['转基因', '地沟油', '麦当劳','狗肉'],
                data: [5, 5, 5,5],
                color: colors[0]
            }
        }, 
		{
            y: 20,
            color: colors[1],
            drilldown: 
			{
                name: '反腐',
                categories: ['薄熙来', '铁道部王志军', '周永康被抓', '徐才厚落马'],
                data: [5, 5, 5, 5],
                color: colors[1]
            }
        }, 
		{
            y: 35,
            color: colors[2],
            drilldown: 
			{
                name: '世界杯',
                categories: ['无助的C罗', '内马尔重伤', '巴西惨败', '德国夺冠', 
				'阿根廷惜败','梅西1V5', '西班牙小组未出现'],
                data: [5, 5, 5, 5, 5, 5, 5],
                color: colors[2]
            }
        }, 
		{
            y: 15,
            color: colors[3],
            drilldown: 
			{
                name: '暴恐案',
                categories: ['乌鲁木齐火车南站', '巴楚暴力案','云南'],
                data: [5, 5, 5],
                color: colors[3]
            }
        }, 
		{
            y: 10,
            color: colors[4],
            drilldown: 
			{
                name: '青岛油管爆炸',
                categories: ['黄岛区输油管', '中石化'],
                data: [ 5, 5],
                color: colors[4]
            }
        }
]

)


