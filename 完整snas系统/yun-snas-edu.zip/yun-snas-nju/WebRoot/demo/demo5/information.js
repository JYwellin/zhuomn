﻿timeRange = '至2014-10-22'
userNameList = ['snas','test','huawei','WIC','spaq','tt']

informationArray = new Array(
[{name: '情报统计',data: 	[
    ['bbs', 10],
    ['blog', 18],
    ['weibo', 201],
    ['nw', 50],
    ['np', 42]
]}],
[{name: '情报统计',data: 	[
    ['bbs', 105],
    ['blog', 200],
    ['weibo', 201],
    ['nw', 50],
    ['np', 42]
]}],
[{name: '情报统计',data: 	[
    ['bbs', 105],
    ['blog', 18],
    ['weibo', 330],
    ['nw', 50],
    ['np', 42]
]}],
[{name: '情报统计',data: 	[
    ['bbs', 105],
    ['blog', 18],
    ['weibo', 201],
    ['nw', 50],
    ['np', 400]
]}],
 [{name: '情报统计',data: 	[
    ['bbs', 105],
    ['blog', 18],
    ['weibo', 201],
    ['nw', 500],
    ['np', 42]
]}],
 [{name: '情报统计',data: 	[
    ['bbs', 105],
    ['blog', 180],
    ['weibo', 201],
    ['nw', 5000],
    ['np', 42]
]}],
[{name: '情报统计',data: 	[
    ['bbs', 5],
    ['blog', 5],
    ['weibo', 5],
    ['nw', 5],
    ['np', 5]
]}]

)

