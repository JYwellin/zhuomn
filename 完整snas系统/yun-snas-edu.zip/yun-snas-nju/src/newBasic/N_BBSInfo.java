package newBasic;

import java.util.List;

import org.bson.types.ObjectId;

import newConstants.N_Constants;

/*
 * BBS
 * 2014年8月22日20:21:48
 * niuliqiang
 */
public class N_BBSInfo implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3885652102183077547L;
	
	private ObjectId oid;
	private String title;
	private String content;				//
	private String url;						//
	private String time;						//发表时间
	private int replyNum;							//回复量
	private int clickNum;
	private double attention;				//关注度
	private String sentiment;				//情感
	private String source;
	private String source_url;
	private List<String> tags;				//
	
	public N_BBSInfo(){
		title = "";
		content = "";
		url = "";
		time = "";
		replyNum = 0;
		clickNum = 0;
		attention = 0;
		sentiment = N_Constants.SENTIMENT_NEUTRAL;
		source = "";
		source_url = "";
		tags = null;
	}

	public ObjectId getOid() {
		return oid;
	}

	public void setOid(ObjectId oid) {
		this.oid = oid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public int getReplyNum() {
		return replyNum;
	}

	public void setReplyNum(int replyNum) {
		this.replyNum = replyNum;
	}

	public int getClickNum() {
		return clickNum;
	}

	public void setClickNum(int clickNum) {
		this.clickNum = clickNum;
	}

	public double getAttention() {
		return attention;
	}

	public void setAttention(double attention) {
		this.attention = attention;
	}

	public String getSentiment() {
		return sentiment;
	}

	public void setSentiment(String sentiment) {
		this.sentiment = sentiment;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getSource_url() {
		return source_url;
	}

	public void setSource_url(String source_url) {
		this.source_url = source_url;
	}

	public List<String> getTags() {
		return tags;
	}

	public void setTags(List<String> tags) {
		this.tags = tags;
	}

	
}
