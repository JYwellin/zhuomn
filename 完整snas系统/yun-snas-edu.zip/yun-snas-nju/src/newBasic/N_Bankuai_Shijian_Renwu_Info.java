package newBasic;

import org.bson.types.ObjectId;

/*
 * 2014年10月30日16:22:32
 * 版块	事件	人物
 */
public class N_Bankuai_Shijian_Renwu_Info implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6833297991238566506L;
	private ObjectId oid;
	private String title;
	private String content;				//
	private String url;						//
	private String source;
	private boolean deal;
	private String addTime;
	
	public N_Bankuai_Shijian_Renwu_Info(){
		oid = null;
		title = "";
		content = "";
		url = "";
		source = "";
		deal = false;
		addTime = "";
	}

	public String getAddTime() {
		return addTime;
	}

	public void setAddTime(String addTime) {
		this.addTime = addTime;
	}

	public ObjectId getOid() {
		return oid;
	}

	public void setOid(ObjectId oid) {
		this.oid = oid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public boolean isDeal() {
		return deal;
	}

	public void setDeal(boolean deal) {
		this.deal = deal;
	}
	
}
