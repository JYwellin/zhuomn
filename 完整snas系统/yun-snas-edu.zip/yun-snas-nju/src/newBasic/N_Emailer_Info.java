package newBasic;

import org.bson.types.ObjectId;

public class N_Emailer_Info implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -822898327453842761L;
	private ObjectId oid;
	private String name;
	private String email;
	private String extra;
	
	public N_Emailer_Info(){
		oid= null;
		name = "";
		email = "";
		extra = "";
	}

	public ObjectId getOid() {
		return oid;
	}

	public void setOid(ObjectId oid) {
		this.oid = oid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getExtra() {
		return extra;
	}

	public void setExtra(String extra) {
		this.extra = extra;
	}
	
}
