package newBasic;

import java.io.Serializable;

/*
 * 2014年8月17日14:49:10
 * 关键字类
 * @Niuliqiang
 */
public class N_KeywordsInfo implements Serializable {

		private static final long serialVersionUID = 783602052492804931L;
		public String keywords;
		public int def_page_num;
		public int user_count;
		public boolean attention;
		
		public N_KeywordsInfo(){
			keywords = "";
			def_page_num = 1;
			user_count = 1;
			attention = true;
		}
		public N_KeywordsInfo(String k, int d, int u, boolean a){
			keywords = k;
			def_page_num = d;
			user_count = u;
			attention = a;
		}
		public String getKeywords() {
			return keywords;
		}
		public void setKeywords(String keywords) {
			this.keywords = keywords;
		}
		public int getDef_page_num() {
			return def_page_num;
		}
		public void setDef_page_num(int def_page_num) {
			this.def_page_num = def_page_num;
		}
		public int getUser_count() {
			return user_count;
		}
		public void setUser_count(int user_count) {
			this.user_count = user_count;
		}
		public boolean isAttention() {
			return attention;
		}
		public void setAttention(boolean attention) {
			this.attention = attention;
		}
		
}
