package newBasic;

import java.util.List;

import org.bson.types.ObjectId;

/*
 * 门户 新闻类
 * 2014年9月17日22:09:06
 * niuliqiang
 */
public class N_NewsInfo implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7061320475037456208L;
	
	public ObjectId oid;
	public String title;
	public String time;
	public String content;
	public String url;
	public String source;
	public String sourceUrl;	
	public String sentiment;
	public List<String> tags;
	
	public N_NewsInfo(){
		title = "";
		time = "";
		content = "";
		url = "";
		source = "";
		sourceUrl = "";
		sentiment = "";
		tags = null;
	}

	public ObjectId getOid() {
		return oid;
	}

	public void setOid(ObjectId oid) {
		this.oid = oid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getSourceUrl() {
		return sourceUrl;
	}

	public void setSourceUrl(String sourceUrl) {
		this.sourceUrl = sourceUrl;
	}

	public String getSentiment() {
		return sentiment;
	}

	public void setSentiment(String sentiment) {
		this.sentiment = sentiment;
	}

	public List<String> getTags() {
		return tags;
	}

	public void setTags(List<String> tags) {
		this.tags = tags;
	}
	
	
}
