package newBasic;

import java.util.List;

import org.bson.types.ObjectId;

/*
 * 2014年9月5日14:49:03
 * 媒体报刊
 * @niuliqiang
 */
public class N_NewsPaperInfo implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2706889419480248150L;
	
	public ObjectId oid;
	public String title;
	public String time;
	public String content;
	public String source;
	public String url;
	public String sentiment;
	public List<String> tags;
	
	//
	public N_NewsPaperInfo(){
		title = "";
		time = "";
		content = "";
		source = "";
		url = "";
		sentiment = "";
		tags = null;
	}

	public ObjectId getOid() {
		return oid;
	}

	public void setOid(ObjectId oid) {
		this.oid = oid;
	}
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getSentiment() {
		return sentiment;
	}

	public void setSentiment(String sentiment) {
		this.sentiment = sentiment;
	}

	public List<String> getTags() {
		return tags;
	}

	public void setTags(List<String> tags) {
		this.tags = tags;
	}

}
