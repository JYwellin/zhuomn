package newBasic;
/*
 * 2014年8月14日21:29:01
 * 用户类
 */
public class N_User implements java.io.Serializable{
	private static final long serialVersionUID = -5654769940887697648L;
	
	public String u_name;
	public String u_password;
	public String u_role;
	public boolean u_isConfirmed;
	public int u_level;
	public String u_joinTime;
	public String u_otherInfo;
	public String u_mongoDB;
	public boolean isNotNull;
	public String type;
	
	public N_User(){
		u_name = "";
		u_password = "";
		u_role = "user";
		u_isConfirmed = false;
		u_level = 0;
		u_joinTime = "";
		u_otherInfo = "";
		u_mongoDB = "";
		isNotNull = false;
		type = "guest";
	}

	public String getU_name() {
		return u_name;
	}

	public void setU_name(String u_name) {
		this.u_name = u_name;
	}

	public String getU_password() {
		return u_password;
	}

	public void setU_password(String u_password) {
		this.u_password = u_password;
	}

	public String getU_role() {
		return u_role;
	}

	public void setU_role(String u_role) {
		this.u_role = u_role;
	}

	public boolean isU_isConfirmed() {
		return u_isConfirmed;
	}

	public void setU_isConfirmed(boolean u_isConfirmed) {
		this.u_isConfirmed = u_isConfirmed;
	}

	public int getU_level() {
		return u_level;
	}

	public void setU_level(int u_level) {
		this.u_level = u_level;
	}

	public String getU_joinTime() {
		return u_joinTime;
	}

	public void setU_joinTime(String u_joinTime) {
		this.u_joinTime = u_joinTime;
	}

	public String getU_otherInfo() {
		return u_otherInfo;
	}

	public void setU_otherInfo(String u_otherInfo) {
		this.u_otherInfo = u_otherInfo;
	}

	public String getU_mongoDB() {
		return u_mongoDB;
	}

	public void setU_mongoDB(String u_mongoDB) {
		this.u_mongoDB = u_mongoDB;
	}

	public boolean isNotNull() {
		return isNotNull;
	}

	public void setNotNull(boolean isNotNull) {
		this.isNotNull = isNotNull;
	}
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void printUserInfo(){
		System.out.println("userInfo : \n"+this.u_name+"-"+this.u_password+"-"+this.u_joinTime+"-"+this.u_isConfirmed+"-"+this.u_role+"-"+this.u_mongoDB+"-"+this.u_level+"-"+this.u_otherInfo);
	}
}
