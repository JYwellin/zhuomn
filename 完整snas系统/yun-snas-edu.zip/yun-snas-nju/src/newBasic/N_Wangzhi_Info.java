package newBasic;

import org.bson.types.ObjectId;

public class N_Wangzhi_Info implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8022937433423256981L;
	private ObjectId oid;
	private String name;
	private String url;
	private String extra;
	
	public N_Wangzhi_Info(){
		oid = null;
		name = "";
		url = "";
		extra = "";
	}

	public ObjectId getOid() {
		return oid;
	}

	public void setOid(ObjectId oid) {
		this.oid = oid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getExtra() {
		return extra;
	}

	public void setExtra(String extra) {
		this.extra = extra;
	}
	
}
