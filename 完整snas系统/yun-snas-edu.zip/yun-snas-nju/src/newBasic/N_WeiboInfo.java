package newBasic;

import java.util.Date;
import java.util.List;

import org.bson.types.ObjectId;

import newConstants.N_Constants;

/*
 * 2014年8月22日14:09:19
 * niuliqiang
 * 微博类
 */
public class N_WeiboInfo implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -882900389545253621L;
	
	private ObjectId oid;
	private String content;						//内容
	private String url;							//网页地址
	private String time;						//发表时间
	private int forward;						//转发
	private int like;							//赞
	private int comment;						//评论
	private int favorite;						//收藏
	private double attention;					//关注度
	private String sentiment;					//情感
	private List<String> keyWords;				//关键词
	
	public N_WeiboInfo(){
		content = "";
		url = "";
		time = "";
		forward = 0;
		comment = 0;
		like = 0;
		favorite = 0;
		attention = 0;
		sentiment = N_Constants.SENTIMENT_NEUTRAL;		//
		keyWords = null;
		
	}

	public ObjectId getOid() {
		return oid;
	}

	public void setOid(ObjectId oid) {
		this.oid = oid;
	}
	
	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}


	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	
	public int getForward() {
		return forward;
	}

	public void setForward(int forward) {
		this.forward = forward;
	}

	public int getLike() {
		return like;
	}

	public void setLike(int like) {
		this.like = like;
	}

	public int getComment() {
		return comment;
	}

	public void setComment(int comment) {
		this.comment = comment;
	}

	public int getFavorite() {
		return favorite;
	}

	public void setFavorite(int favorite) {
		this.favorite = favorite;
	}

	public double getAttention() {
		return attention;
	}

	public void setAttention(double attention) {
		this.attention = attention;
	}

	public List<String> getKeyWords() {
		return keyWords;
	}

	public void setKeyWords(List<String> keyWords) {
		this.keyWords = keyWords;
	}

	public String getSentiment() {
		return sentiment;
	}

	public void setSentiment(String sentiment) {
		this.sentiment = sentiment;
	}
	
}
