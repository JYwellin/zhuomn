package newConstants;

public class N_CONFIG {
	public static String USER_CONFIG_PASTTIME = "past-time";
	
	//
	public static String USER_CONFIG_PAST_HOUR = "hour";
	public static String USER_CONFIG_PAST_DAY = "day";
	public static String USER_CONFIG_PAST_WEEK = "week";
	public static String USER_CONFIG_PAST_MONTH = "month";
	public static String USER_CONFIG_PAST_NULL = "null";
	
	public static String TYPE_BANKUAI = "bankuai";
	public static String TYPE_SHIJIAN = "shijian";
	public static String TYPE_RENWU = "renwu";
}
