package newConstants;

import java.util.ArrayList;
import java.util.List;

public class N_Constants {
	// user role
	public static String USER_ROLE_USER = "user";
	public static String USER_ROLE_ADMIN = "administer";
	public static String USER_ROLE_REG = "register";

	// page tag
	public static String PAGE_TAG_GERENINFO = "geren-info";
	public static String PAGE_TAG_KEYWORDS = "geren-keywords";
	public static String PAGE_TAG_GUANZHU = "geren-guanzhu";
	public static String PAGE_TAG_MANAGE = "geren-manage";
	public static String PAGE_TAG_SHIYU = "geren-shiyu";
	public static String PAGE_TAG_SHOUJIANREN = "geren-emailer";
	public static String PAGE_TAG_PHONEPASSWORD = "geren-password_phone";
	// page tag 监控
	public static String PAGE_TAG_JK_WEIBO = "jk-weibo";
	public static String PAGE_TAG_JK_BBS = "jk-bbs";
	public static String PAGE_TAG_JK_MENHUNEWS = "jk-news";
	public static String PAGE_TAG_JK_GUANZHU = "jk-guanzhu";
	public static String PAGE_TAG_JK_NEWSPAPER = "jk-newspaper";
	public static String PAGE_TAG_JK_QINGBAOSHOUYE = "jk-qbsy";
	public static String PAGE_TAG_JK_SHIJIANGENZONG = "sjgz";
	public static String PAGE_TAG_JK_RENWUGENZONG = "rwgz";
	public static String PAGE_TAG_JK_QINGBAOPEIZHI = "qbpz";
	public static String PAGE_TAG_JK_BANKUAIPEIZHI = "bkpz";
	public static String PAGE_TAG_JK_WANGZHIPEIZHI = "wzpz";
	public static String PAGE_TAG_JK_SHIJIANPEIZHI = "sjpz";
	public static String PAGE_TAG_JK_RENWUPEIZHI	= "rwpz";
	// page tag 分析
	public static String PAGE_TAG_FX_TAG1= "fx-tag1";
	public static String PAGE_TAG_FX_TAG2= "fx-tag2";
	public static String PAGE_TAG_FX_TAG3= "fx-tag3";
	public static String PAGE_TAG_FX_TAG4= "fx-tag4";
	public static String PAGE_TAG_FX_QBTJ = "fx-qbtj";
	public static String PAGE_TAG_FX_QBCL = "fx-qbcl";
	// page tag 报告
	public static String PAGE_TAG_BG_BAOGAO = "bg-baogao";
	public static String PAGE_TAG_BG_RIBAO = "bg-ribao";
	public static String PAGE_TAG_BG_ZHOUBAO = "bg-zhoubao";
	public static String PAGE_TAG_BG_YUEBAO = "bg-yuebao";
	public static String PAGE_TAG_BG_JIBAO = "bg-jibao";
	public static String PAGE_TAG_BG_NIANBAO = "bg-nianbao";
	public static String PAGE_TAG_BG_ZHUANBAO = "bg-zhuanbao";
	public static String PAGE_TAG_BG_SCBAOGAO = "bg-scbaogao";
	// null
	public static String NULL = "null";

	//
	public static String USER_ZHUANGTAI_JIHUO = "已激活!";
	public static String USER_ZHUANGTAI_JIHUO_NOT = "未激活!";
	//
	// user database name
	public static String USER_MONGODB_NAME_QIANZHUI = "user_";
	public static String USER_MONGODB_NAME_HOUZHUI = "_database";
	public static String USER_CONFIG_COLLECTION = "user_config";
	//
	public static String USER_KEYWORDS_COLLECTION = "user_keywords";
	//
	public static String USER_WEIBO_COLLECTION = "user_weibo";
	public static String USER_BBS_COLLECTION = "user_bbs";
	public static String USER_MENHUNEWS_COLLECTION = "user_menhunews";
	public static String USER_TEST_COLLECTION = "user_test";
	public static String USER_NEWSPAPER_COLLECTION = "user_np";
	public static String USER_NEWS_COLLECTION = "user_nw";
	//
	public static int MAX_USER_KEYWORDS_NUM = 80;
	
	//
	public static int MAX_CONTENT_LENGTH = 200;
	public static int MAX_TITLE_LENGTH = 50;
	//
	public static String SENTIMENT_POSITIVE = "positive";
	public static String SENTIMENT_NEUTRAL = "neutral";
	public static String SENTIMENT_NEGATIVE = "negative";
	//
	//user type
	public static String USER_GUEST = "guest";
	public static int USER_GUEST_KEYWORDS_NUM = 3;
	public static String USER_VIP = "vip";
	public static int USER_VIP_KEYWORDS_NUM = 80;
	
	//
	public static List<String> pastTimeList = new ArrayList<String>();

	static {
		// radio choice
		pastTimeList.add("Past hour（过去1小时）");
		pastTimeList.add("Past 24 hours/day（过去1天）");
		pastTimeList.add("Past week（过去1周）");
		pastTimeList.add("Past month（过去1月）");
		pastTimeList.add("不限时间");
		//
	}
}
