package newConstants;

import java.util.ArrayList;
import java.util.List;

import newBasic.N_BBSInfo;
import newBasic.N_Bankuai_Shijian_Renwu_Info;
import newBasic.N_NewsInfo;
import newBasic.N_NewsPaperInfo;
import newBasic.N_WeiboInfo;
/*
 * 2014年8月27日14:52:53
 * niuliqiang
 * 静态类，用于存储数据
 * 数据缓冲区
 */
public class N_DataBuffer {
	//weibo
	public static String WEIBO_SORT_BY_TIME = "time";
	public static String WEIBO_SORT_BY_ATTENTION = "attention";
	public static String WEIBO_SORT_BY_SENTIMENT = "sentiment";
	public static int WEIBO_MAX_DATA_NUM = 1000;
	
	public static List<N_WeiboInfo> weiboDataBuffer = new ArrayList<N_WeiboInfo>();
	//bbs data
	public static String BBS_SORT_BY_TIME = "time";
	public static String BBS_SORT_BY_ATTENTION = "attention";
	public static String BBS_SORT_BY_SENTIMENT = "sentiment";
	public static int BBS_MAX_DATA_NUM = 1000;
	
	public static List<N_BBSInfo> bbsDataBuffer = new ArrayList<N_BBSInfo>();
	
	//newspaper
	
	public static String NP_SORT_BY_TIME = "time";
	public static String NP_SORT_BY_SENTIMENT = "sentiment";
	public static int NP_MAX_DATA_NUM = 1000;
	
	public static List<N_NewsPaperInfo> npDataBuffer = new ArrayList<N_NewsPaperInfo>();
	
	//news
	public static String NEWS_SORT_BY_TIME = "time";
	public static String NEWS_SORT_BY_SENTIMENT = "sentiment";
	public static int NEWS_MAX_DATA_NUM = 1000;
	
	public static List<N_NewsInfo> newsDataBuffer = new ArrayList<N_NewsInfo>();
	
	//版块 事件 人物
	public static String BK_SJ_RW_PAST = "day";
	public static String BK_SJ_RW_SORT = "time";
	public static int BK_SJ_RW_MAX_DATA_NUM = 5;
	public static List<N_Bankuai_Shijian_Renwu_Info> bkDataBuffer = new ArrayList<N_Bankuai_Shijian_Renwu_Info>();
	public static List<N_Bankuai_Shijian_Renwu_Info> sjDataBuffer = new ArrayList<N_Bankuai_Shijian_Renwu_Info>();
	public static List<N_Bankuai_Shijian_Renwu_Info> rwDataBuffer = new ArrayList<N_Bankuai_Shijian_Renwu_Info>();
	
	//待处理 版块 事件 人物
	public static int UNDEALED_MAX_DATA_NUM = 1000;
	
	//cursor batch size
	public static int CURSOR_BATCH_SIZE = 10000;
}
