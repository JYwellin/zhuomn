package newConstants;
/*
 * 2014年8月17日13:53:29
 * 关键字 数据表
 */
public class N_KWMongoDB {
	public static String KEYWORDS_KEYWORDS = "keywords";
	public static String KEYWORDS_ATTENTION = "attention";
	public static String KEYWORDS_COUNT = "count";
	public static String KEYWORDS_PAGE_NUM = "def_page_num";
}
