package newConstants;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

/*
 * 
 */
public class N_MongoDB_Info {
	
	public static String mongo_ip = "10.168.71.170";
	public static int mongo_port = 27017;
	
	public static boolean read_ip_port = false;
	
	/*----首次 读取mongo DB ip port信息*/
	static {
		if (read_ip_port == false) {
			String webPath = N_Constants.class.getProtectionDomain().getCodeSource().getLocation().getPath();
			if (webPath.indexOf("WEB-INF") > 0) {
				 webPath = webPath.substring(0, webPath.indexOf("WEB-INF/classes"));
			 }
			System.out.println(webPath);
			try {
				BufferedReader br = new BufferedReader(new FileReader(webPath+"configWebIp/mongo_ip_port.txt"));
				// ip
				String line1 = br.readLine();
				StringTokenizer st1 = new StringTokenizer(line1, ":");
				String name1 = "";
				String ip = "";
				if (st1.hasMoreTokens())
					name1 = st1.nextToken();
				if (st1.hasMoreElements())
					ip = st1.nextToken();
				// port
				String line2 = br.readLine();
				StringTokenizer st2 = new StringTokenizer(line2, ":");
				String name2 = "";
				String port = "";
				if (st2.hasMoreTokens())
					name2 = st2.nextToken();
				if (st2.hasMoreElements())
					port = st2.nextToken();
				if (name1.equals("ip") && name2.equals("port") && ip.equals("") == false && port.equals("") == false) {
					mongo_ip = ip;
					mongo_port = Integer.parseInt(port);
				}
				System.out.println("-------------Readed MongoDB IP and Port--------"+ "IP: " + ip + " PORT: " + port);
				br.close();
			} catch (FileNotFoundException e) {
				System.out.println("ERROR : no file !!!");
				e.printStackTrace();
			} catch (IOException e) {
				System.out.println("ERROR : no ip or port !!!");
				e.printStackTrace();
			}
		}
		read_ip_port = true;
	}
	
	//版块 事件 人物 配置collection
	//2014年10月24日 niuliqiang
	public static String USR_CONFIG_BANKUAI = "user_config_bankuai";
	public static String USR_CONFIG_SHIJIAN = "user_config_shijian";
	public static String USR_CONFIG_RENWU = "user_config_renwu";
	
	//监控网址 收件人 collection
	//2014年10月30日19:20:23
	public static String USR_CONFIG_WANGZHI= "user_config_wangzhi";
	public static String USR_CONFIG_SHOUJIANREN = "user_config_shoujianren";
	
	//待处理 
	public static String USER_ATTENTION_BANKUAI_SHIJIAN_RENWU = "user_attention_bksjrw";
	
}
