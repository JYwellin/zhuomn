package newConstants;

public class N_UserMongoDB {
	public static String allUsersMongoDB = "all_users_db";
	public static String allUsersCollection = "all_users_info";
	public static String allUsersPhoneCollection = "all_users_phone";
	public static String all_users_phone = "u_phone";
	//collection 
	public static String all_users_info_name = "u_name";
	public static String all_users_info_pwd = "u_password";
	public static String all_users_info_role = "u_role";
	public static String all_users_info_level = "u_level";
	public static String all_users_info_joinTime = "u_join_time";
	public static String all_users_info_otherInfo = "u_other_info";
	public static String all_users_info_isConfirmed = "u_is_confirmed";
	public static String all_users_info_mongoDB = "u_mongodb";
	public static String all_users_info_login = "u_login";
	public static String all_users_info_type = "u_type";
	//
	public static String allKeywordsCollection = "all_keywords";
}
