package newDataSort;

import java.util.List;

public class N_File_SortByName {
	
	String sortType = "name";
	
	public void sortDataListByQuickSort(List<String> filesList, int start, int end) {
		if(start < end){
			String pivot = filesList.get(end);
			int s = start;
			int e = end;
			while(s < e){
				while(s < e && filesList.get(s).compareToIgnoreCase(pivot) >=0 )
					s++;
				filesList.set(e, filesList.get(s));
				//
				while(s <e && filesList.get(s).compareToIgnoreCase(pivot) < 0)
					e--;
				filesList.set(s, filesList.get(e));
			}
			filesList.set(s, pivot);
			this.sortDataListByQuickSort(filesList, start, s-1);
			this.sortDataListByQuickSort(filesList, s+1, end);
		}
	}
}
