package newDataSort;

import java.util.List;

import newBasic.N_NewsInfo;
import newConstants.N_DataBuffer;

public class N_News_SortBy {
	public String sortType = N_DataBuffer.NEWS_SORT_BY_TIME;

	public N_News_SortBy(String type) {
		if (type.equals(N_DataBuffer.NEWS_SORT_BY_TIME) || type.equals(N_DataBuffer.NEWS_SORT_BY_SENTIMENT))
			sortType = type;
		else
			sortType = N_DataBuffer.NEWS_SORT_BY_TIME;
	}

	// <0 =0 >0
	public double compare(N_NewsInfo post1, N_NewsInfo post2) {
		if (sortType.equals(N_DataBuffer.NEWS_SORT_BY_TIME))
			return post1.getTime().compareTo(post2.getTime());
		else if (sortType.equals(N_DataBuffer.NEWS_SORT_BY_SENTIMENT))
			return post1.getSentiment().compareTo(post2.getSentiment());
		else
			return 0;
	}
	public void sortDataListByQuickSort(List<N_NewsInfo> postsList, int start, int end) {
	
		if(start < end){
			N_NewsInfo pivot = postsList.get(end);
			int s = start;
			int e = end;
			while(s < e){
				while(s < e && compare(postsList.get(s), pivot) >=0 )
					s++;
				postsList.set(e, postsList.get(s));
				//
				while(s <e && compare(postsList.get(e), pivot) < 0)
					e--;
				postsList.set(s, postsList.get(e));
			}
			postsList.set(s, pivot);
			this.sortDataListByQuickSort(postsList, start, s-1);
			this.sortDataListByQuickSort(postsList, s+1, end);
		}
	}
}
