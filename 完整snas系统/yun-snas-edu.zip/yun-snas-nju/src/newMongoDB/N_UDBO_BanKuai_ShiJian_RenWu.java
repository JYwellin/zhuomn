package newMongoDB;

import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.bson.types.ObjectId;

import newBasic.N_Bankuai_Shijian_Renwu_Info;
import newBasic.N_Emailer_Info;
import newBasic.N_Wangzhi_Info;
import newConstants.N_CONFIG;
import newConstants.N_Constants;
import newConstants.N_DataBuffer;
import newConstants.N_MongoDB_Info;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import com.mongodb.MongoException;
import com.mongodb.QueryOperators;

/*
 * 2014年10月24日15:07:58
 * 版块
 * 事件
 * 人物
 * 配置 数据 数据库操作
 * by niuliqiang
 */
public class N_UDBO_BanKuai_ShiJian_RenWu {
	public String userDBname;
	
	public N_UDBO_BanKuai_ShiJian_RenWu(String udbname){
		userDBname = udbname;
	}
	
	//创建一个新的版块
	public boolean createNewBanKuai(String name, List<String> tags, String type){			//name为版块名字，tags为版块关键字等	
		boolean result = false;
		//
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB user_db = mongo.getDB(userDBname);
			String collectionName = N_MongoDB_Info.USR_CONFIG_BANKUAI;
			if(type.equals(N_CONFIG.TYPE_RENWU))
				collectionName = N_MongoDB_Info.USR_CONFIG_RENWU;
			else if(type.equals(N_CONFIG.TYPE_SHIJIAN))
				collectionName = N_MongoDB_Info.USR_CONFIG_SHIJIAN;
			DBCollection configBanKuai = user_db
					.getCollection(collectionName);
			// 查找是否存在同名字
			int findN = configBanKuai.find(
					new BasicDBObject("name", name))
					.count();
			if (findN == 0) {
				BasicDBObject newBankuai = new BasicDBObject();
				newBankuai.put("name", name);
				newBankuai.put("tags", tags);
				configBanKuai.save(newBankuai);
				System.out.println("add new BANKUAI : " + name
						+ " to user db successfully!");
				result = true;
			} else {
				System.out.println("keywords : " + name
						+ " Existed in user db!!!");
			}
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		//
		return result;
	}
	//
	public List<String> getAllBanKuaiList(String type){
		List<String> bankuaiList = new ArrayList<String>();
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB user_db = mongo.getDB(userDBname);
			String collectionName = N_MongoDB_Info.USR_CONFIG_BANKUAI;
			if(type.equals(N_CONFIG.TYPE_RENWU))
				collectionName = N_MongoDB_Info.USR_CONFIG_RENWU;
			else if(type.equals(N_CONFIG.TYPE_SHIJIAN))
				collectionName = N_MongoDB_Info.USR_CONFIG_SHIJIAN;
			DBCollection configBanKuai = user_db.getCollection(collectionName);
			// 查找是否存在同名字
			DBCursor cursor = configBanKuai.find(
					new BasicDBObject("name", new BasicDBObject(QueryOperators.EXISTS, true)));
			while(cursor.hasNext()){
				DBObject dbo = cursor.next();
				if(dbo.get("name")!=null){
					 bankuaiList.add(dbo.get("name").toString());
				}
			}
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		return bankuaiList;
	}
	//根据版块name获取版块tags
	public List<String> getBanKuaiTags(String name, String type){
		List<String> tags = new ArrayList<String>();
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB user_db = mongo.getDB(userDBname);
			String collectionName = N_MongoDB_Info.USR_CONFIG_BANKUAI;
			if(type.equals(N_CONFIG.TYPE_RENWU))
				collectionName = N_MongoDB_Info.USR_CONFIG_RENWU;
			else if(type.equals(N_CONFIG.TYPE_SHIJIAN))
				collectionName = N_MongoDB_Info.USR_CONFIG_SHIJIAN;
			DBCollection configBanKuai = user_db
					.getCollection(collectionName);
			// 查找是否存在同名字
			DBCursor cursor = configBanKuai.find(
					new BasicDBObject("name", name));
			if(cursor.hasNext()){
				DBObject dbo = cursor.next();
				if(dbo.get("tags")!=null){
					tags = (List<String>) dbo.get("tags");
				}
			}
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		//System.out.println(""+tags);
		return tags;
	}
	//根据版块名字 更新版块tags
	public boolean updateBanKuaiTags(String name, List<String> newTags, String type){
		boolean result = false;
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB user_db = mongo.getDB(userDBname);
			String collectionName = N_MongoDB_Info.USR_CONFIG_BANKUAI;
			if(type.equals(N_CONFIG.TYPE_RENWU))
				collectionName = N_MongoDB_Info.USR_CONFIG_RENWU;
			else if(type.equals(N_CONFIG.TYPE_SHIJIAN))
				collectionName = N_MongoDB_Info.USR_CONFIG_SHIJIAN;
			DBCollection configBanKuai = user_db
					.getCollection(collectionName);
			//update
			configBanKuai.update(new BasicDBObject("name", name), new BasicDBObject("$set", new BasicDBObject("tags", newTags)), true, false);
			result = true;
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		return result;
	}
	//根据版块名字 删除版块
	public boolean deleteBanKuaiTags(String name, String type){
		boolean result = false;
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB user_db = mongo.getDB(userDBname);
			String collectionName = N_MongoDB_Info.USR_CONFIG_BANKUAI;
			if(type.equals(N_CONFIG.TYPE_RENWU))
				collectionName = N_MongoDB_Info.USR_CONFIG_RENWU;
			else if(type.equals(N_CONFIG.TYPE_SHIJIAN))
				collectionName = N_MongoDB_Info.USR_CONFIG_SHIJIAN;
			DBCollection configBanKuai = user_db
					.getCollection(collectionName);
			//delete
			configBanKuai.remove(new BasicDBObject("name", name));
			result = true;
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		return result;
	}
	//读取时间config
	// user config collection
		public String getUserPastTime() {
			String pastTime = N_CONFIG.USER_CONFIG_PAST_HOUR;
			//
			try {
				//
				Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
				DB user_db = mongo.getDB(userDBname);
				DBCollection configC = user_db
						.getCollection(N_Constants.USER_CONFIG_COLLECTION);
				// 查找是否存在同名字
				DBCursor cursor = configC.find(new BasicDBObject(
						N_CONFIG.USER_CONFIG_PASTTIME, new BasicDBObject(
								QueryOperators.EXISTS, true)));
				if (cursor.hasNext()) {
					DBObject dbo = cursor.next();
					pastTime = dbo.get(N_CONFIG.USER_CONFIG_PASTTIME).toString();
				} else {
					BasicDBObject config = new BasicDBObject();
					config.put(N_CONFIG.USER_CONFIG_PASTTIME,
							N_CONFIG.USER_CONFIG_PAST_HOUR);
					configC.save(config);
					pastTime = N_CONFIG.USER_CONFIG_PAST_HOUR;
				}
				System.out.println("------user past time is : " + pastTime);
				mongo.close();
				//
			} catch (UnknownHostException e) {
				e.printStackTrace();
			} catch (MongoException e) {
				e.printStackTrace();
			}
			//
			return pastTime;
		}

	//从所有数据中读取关于某个版块的数据
	public List<N_Bankuai_Shijian_Renwu_Info> getBankuaiData(String name, String type){
		List<N_Bankuai_Shijian_Renwu_Info> allDataList = new ArrayList<N_Bankuai_Shijian_Renwu_Info>();
		//
		//
		String pastTime = this.getUserPastTime();
		Calendar c = Calendar.getInstance();
		int year = c.get(Calendar.YEAR);
		int month = c.get(Calendar.MONTH) + 1;
		int day = c.get(Calendar.DAY_OF_MONTH);
		int hour = c.get(Calendar.HOUR_OF_DAY);
		int minute = c.get(Calendar.MINUTE);
		int second = c.get(Calendar.SECOND);
		if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_HOUR)) {
			if (hour > 0)
				hour -= 1;
			else
				hour = 0;
		} else if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_DAY)) {
			if (day > 0)
				day -= 1;
			else
				day = 0;
		} else if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_WEEK)) {
			if (day > 7)
				day -= 7;
			else
				day = 0;
		} else if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_MONTH)) {
			if (month > 1)
				month -= 1;
			else
				month = 1;
		} else if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_NULL)) {
			year = 0;
			month = 0;
			day = 0;
			hour = 0;
			minute = 0;
			second = 0;
		} else {
			if (day > 0)
				day -= 1;
			else
				day = 0;
		}
		c.set(year, month - 1, day, hour, minute, second);
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String sinceTime = df.format(c.getTime());
		System.out.println("------name : 【"+name+"】 reading sinceTime : 【" + sinceTime+"】");
		//keywords
		List<String> userKeywordsList = this.getBanKuaiTags(name, type);
		int queryNum = 0;
		//////weibo
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB user_db = mongo.getDB(userDBname);
			long start = System.currentTimeMillis();
			/////////////////////////////////////////////////////////////////////////////////
			DBCollection WeiboC = user_db
					.getCollection(N_Constants.USER_WEIBO_COLLECTION);
			WeiboC.createIndex(new BasicDBObject("time", -1));
			DBCursor cursor_weibo = WeiboC.find(
					new BasicDBObject("time", new BasicDBObject("$gte",
							sinceTime))).limit(N_DataBuffer.WEIBO_MAX_DATA_NUM);
			//cursor_weibo.batchSize(N_DataBuffer.CURSOR_BATCH_SIZE);
			// all Weibo
			int weiboDataNum = 0;
			while (cursor_weibo.hasNext() && weiboDataNum < N_DataBuffer.BK_SJ_RW_MAX_DATA_NUM) {
				//
				queryNum++;
				DBObject dbo = cursor_weibo.next();
				ObjectId oid = (ObjectId) dbo.get("_id");
				String content = "";
				if (dbo.get("content") != null)
					content = dbo.get("content").toString();
				String url = "";
				if (dbo.get("url") != null)
					url = dbo.get("url").toString();
				String title = content;
				String source = "新浪微博";
				List<String> tags = new ArrayList<String>();
				if (dbo.get("keyword") != null)
					tags = (List<String>) dbo.get("keyword");
				//
				if(content.length() > N_Constants.MAX_CONTENT_LENGTH){
					content = content.substring(0, N_Constants.MAX_CONTENT_LENGTH);
					content += "...";
				}
				if(title.length() > N_Constants.MAX_TITLE_LENGTH){
					title = title.substring(0, N_Constants.MAX_TITLE_LENGTH);
					title += "...";
				}
				N_Bankuai_Shijian_Renwu_Info newBSRI = new N_Bankuai_Shijian_Renwu_Info();
				newBSRI.setContent(content);
				newBSRI.setOid(oid);
				newBSRI.setSource(source);
				newBSRI.setTitle(title);
				newBSRI.setUrl(url);
				//
				for (int i = 0; i < tags.size(); i++) {
					String tag = tags.get(i);
					int keywordsIndex = userKeywordsList.indexOf(tag);
					if (keywordsIndex >= 0) {
						allDataList.add(newBSRI);
						weiboDataNum++;
						break;
					}
				}
			}
			///////////////////////////////////////////////////////////////////////////////////
			DBCollection NewsPaperC = user_db
					.getCollection(N_Constants.USER_NEWSPAPER_COLLECTION);
			NewsPaperC.createIndex(new BasicDBObject("publish_time", -1));
			DBCursor cursor_np = NewsPaperC.find(
					new BasicDBObject("publish_time", new BasicDBObject("$gte",
							sinceTime))).limit(N_DataBuffer.NP_MAX_DATA_NUM);
			//cursor_np.batchSize(N_DataBuffer.CURSOR_BATCH_SIZE);
			int npDataNum = 0;
			while (cursor_np.hasNext() && npDataNum < N_DataBuffer.BK_SJ_RW_MAX_DATA_NUM) {
				queryNum++;
				DBObject dbo = cursor_np.next();
				ObjectId oid = (ObjectId) dbo.get("_id");
				String content = "";
				if (dbo.get("content") != null)
					content = dbo.get("content").toString();
				String title = "";
				if (dbo.get("biaoti") != null)
					title = dbo.get("biaoti").toString();
				String url = "";
				if (dbo.get("url") != null)
					url = dbo.get("url").toString();
				String source = "";
				if (dbo.get("source") != null)
					source = dbo.get("source").toString();
				List<String> tags = new ArrayList<String>();
				if (dbo.get("tags") != null)
					tags = (List<String>) dbo.get("tags");
				//
				if(content.length() > N_Constants.MAX_CONTENT_LENGTH){
					content = content.substring(0, N_Constants.MAX_CONTENT_LENGTH);
					content += "...";
				}
				if(title.length() > N_Constants.MAX_TITLE_LENGTH){
					title = title.substring(0, N_Constants.MAX_TITLE_LENGTH);
					title += "...";
				}
				//
				N_Bankuai_Shijian_Renwu_Info newBSRI = new N_Bankuai_Shijian_Renwu_Info();
				newBSRI.setContent(content);
				newBSRI.setOid(oid);
				newBSRI.setSource(source);
				newBSRI.setTitle(title);
				newBSRI.setUrl(url);
				//
				for (int i = 0; i < tags.size(); i++) {
					String tag = tags.get(i);
					int keywordsIndex = userKeywordsList.indexOf(tag);
					if (keywordsIndex >= 0) {
						allDataList.add(newBSRI);
						npDataNum++;
						break;
					}
				}
			}
			//////////////////////////////////////////////////////////////////////////////////////
			DBCollection bbsC = user_db
					.getCollection(N_Constants.USER_BBS_COLLECTION);
			bbsC.createIndex(new BasicDBObject("time", -1));
			DBCursor cursor_bbs = bbsC.find(
					new BasicDBObject("time", new BasicDBObject("$gte",
							sinceTime))).limit(N_DataBuffer.BBS_MAX_DATA_NUM);
			//cursor_bbs.batchSize(N_DataBuffer.CURSOR_BATCH_SIZE);
			int bbsDataNum = 0;
			while (cursor_bbs.hasNext() && bbsDataNum < N_DataBuffer.BK_SJ_RW_MAX_DATA_NUM) {
				queryNum++;
				DBObject dbo = cursor_bbs.next();
				ObjectId oid = (ObjectId) dbo.get("_id");
				String content = "";
				if (dbo.get("content") != null)
					content = dbo.get("content").toString();
				String title = "";
				if (dbo.get("title") != null)
					title = dbo.get("title").toString();
				String url = "";
				if (dbo.get("url") != null)
					url = dbo.get("url").toString();
				String source = "";
				if (dbo.get("source") != null)
					source = dbo.get("source").toString();
				List<String> tags = new ArrayList<String>();
				if (dbo.get("tags") != null)
					tags = (List<String>) dbo.get("tags");
				//
				if(content.length() > N_Constants.MAX_CONTENT_LENGTH){
					content = content.substring(0, N_Constants.MAX_CONTENT_LENGTH);
					content += "...";
				}
				if(title.length() > N_Constants.MAX_TITLE_LENGTH){
					title = title.substring(0, N_Constants.MAX_TITLE_LENGTH);
					title += "...";
				}
				//
				N_Bankuai_Shijian_Renwu_Info newBSRI = new N_Bankuai_Shijian_Renwu_Info();
				newBSRI.setContent(content);
				newBSRI.setOid(oid);
				newBSRI.setSource(source);
				newBSRI.setTitle(title);
				newBSRI.setUrl(url);
				//
				for (int i = 0; i < tags.size(); i++) {
					String tag = tags.get(i);
					int keywordsIndex = userKeywordsList.indexOf(tag);
					if (keywordsIndex >= 0) {
						allDataList.add(newBSRI);
						bbsDataNum++;
						break;
					}
				}
			}
			//////////////////////////////////////////////////////////////////////////////////////
			DBCollection NewsC = user_db
					.getCollection(N_Constants.USER_NEWS_COLLECTION);
			NewsC.createIndex(new BasicDBObject("publish_time", -1));
			DBCursor cursor_nw = NewsC.find(
					new BasicDBObject("publish_time", new BasicDBObject("$gte",
							sinceTime))).limit(N_DataBuffer.NEWS_MAX_DATA_NUM);
			//cursor_nw.batchSize(N_DataBuffer.CURSOR_BATCH_SIZE);
			int nwDataNum = 0;
			while (cursor_nw.hasNext() && nwDataNum < N_DataBuffer.BK_SJ_RW_MAX_DATA_NUM) {
				queryNum++;
				DBObject dbo = cursor_nw.next();
				ObjectId oid = (ObjectId) dbo.get("_id");
				String content = "";
				if (dbo.get("content") != null)
					content = dbo.get("content").toString();
				String title = "";
				if (dbo.get("title") != null)
					title = dbo.get("title").toString();
				String url = "";
				if (dbo.get("url") != null)
					url = dbo.get("url").toString();
				String source = "";
				if (dbo.get("source") != null)
					source = dbo.get("source").toString();
				List<String> tags = new ArrayList<String>();
				if (dbo.get("tags") != null)
					tags = (List<String>) dbo.get("tags");
				//
				if(content.length() > N_Constants.MAX_CONTENT_LENGTH){
					content = content.substring(0, N_Constants.MAX_CONTENT_LENGTH);
					content += "...";
				}
				if(title.length() > N_Constants.MAX_TITLE_LENGTH){
					title = title.substring(0, N_Constants.MAX_TITLE_LENGTH);
					title += "...";
				}
				//
				N_Bankuai_Shijian_Renwu_Info newBSRI = new N_Bankuai_Shijian_Renwu_Info();
				newBSRI.setContent(content);
				newBSRI.setOid(oid);
				newBSRI.setSource(source);
				newBSRI.setTitle(title);
				newBSRI.setUrl(url);
				//
				for (int i = 0; i < tags.size(); i++) {
					String tag = tags.get(i);
					int keywordsIndex = userKeywordsList.indexOf(tag);
					if (keywordsIndex >= 0) {
						allDataList.add(newBSRI);
						nwDataNum++;
						break;
					}
				}
			}
			//////////////////////////////////////////////////////////////////////////////////////
			
			//////////////////////////////////////////////////////////////////////////////////////
			N_DataBuffer.bkDataBuffer =allDataList;
			long end = System.currentTimeMillis();
			System.out.println("------耗时：" + (end - start) + "毫秒!"
					+ "--- 所有数据总数为：" + allDataList.size() + "/" + queryNum+" 类型： "+type);
			//
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}

		//
		return allDataList;
	}
	/////////////////////////网址设置//////////////////////////////////
	//创建一个新的版块
		public boolean createNewWangZhi(String name, String url, String shuoming){			//name为版块名字，tags为版块关键字等	
			boolean result = false;
			//
			try {
				//
				Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
				DB user_db = mongo.getDB(userDBname);
				String collectionName = N_MongoDB_Info.USR_CONFIG_WANGZHI;
				DBCollection configWangZhi = user_db
						.getCollection(collectionName);
				// 查找是否存在同名字
				int findN = configWangZhi.find(
						new BasicDBObject("name", name))
						.count();
				if (findN == 0) {
					BasicDBObject newWangZhi = new BasicDBObject();
					newWangZhi.put("name", name);
					newWangZhi.put("url", url);
					newWangZhi.put("extra", shuoming);
					configWangZhi.save(newWangZhi);
					System.out.println("add new WangZhi : " + name
							+ " to user db successfully!");
					result = true;
				} else {
					System.out.println("keywords : " + name
							+ " Existed in user db!!!");
				}
				mongo.close();
				//
			} catch (UnknownHostException e) {
				e.printStackTrace();
			} catch (MongoException e) {
				e.printStackTrace();
			}
			//
			return result;
		}
		//
		public List<N_Wangzhi_Info> getAllWangZhiList(){
			List<N_Wangzhi_Info> WangZhiList = new ArrayList<N_Wangzhi_Info>();
			try {
				//
				Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
				DB user_db = mongo.getDB(userDBname);
				String collectionName = N_MongoDB_Info.USR_CONFIG_WANGZHI;
				DBCollection configWangZhi = user_db
						.getCollection(collectionName);
				// 查找是否存在同名字
				DBCursor cursor = configWangZhi.find(
						new BasicDBObject("name", new BasicDBObject(
								QueryOperators.EXISTS, true)));
				while(cursor.hasNext()){
					DBObject dbo = cursor.next();
					N_Wangzhi_Info newWZ = new N_Wangzhi_Info();
					ObjectId oid = (ObjectId) dbo.get("_id");
					String name = "";
					if(dbo.get("name")!=null)
						 name = dbo.get("name").toString();
					String url = "";
					if(dbo.get("url")!=null)
						url = dbo.get("url").toString();
					String extra = "";
					if(dbo.get("extra")!=null)
						extra = dbo.get("extra").toString();
					newWZ.setExtra(extra);
					newWZ.setOid(oid);
					newWZ.setName(name);
					newWZ.setUrl(url);
					WangZhiList.add(newWZ);
				}
				mongo.close();
				//
			} catch (UnknownHostException e) {
				e.printStackTrace();
			} catch (MongoException e) {
				e.printStackTrace();
			}
			return WangZhiList;
		}
		//根据版块名字 删除版块
		public boolean deleteWangZhi(ObjectId oid){
			boolean result = false;
			try {
				//
				Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
				DB user_db = mongo.getDB(userDBname);
				String collectionName = N_MongoDB_Info.USR_CONFIG_WANGZHI;
				DBCollection configWangZhi = user_db
						.getCollection(collectionName);
				//delete
				configWangZhi.remove(new BasicDBObject("_id", oid));
				result = true;
				mongo.close();
				//
			} catch (UnknownHostException e) {
				e.printStackTrace();
			} catch (MongoException e) {
				e.printStackTrace();
			}
			return result;
		}
	///////////////////////////////////////////////////////////
		/////////////////////////收件人设置//////////////////////////////////
		//创建一个新的收件人
			public boolean createNewShoujianren(String name, String email, String shuoming){			//name为版块名字，tags为版块关键字等	
				boolean result = false;
				//
				try {
					//
					Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
					DB user_db = mongo.getDB(userDBname);
					String collectionName = N_MongoDB_Info.USR_CONFIG_SHOUJIANREN;
					DBCollection configshoujianren = user_db
							.getCollection(collectionName);
					// 查找是否存在同名字
					int findN = configshoujianren.find(
							new BasicDBObject("name", name))
							.count();
					if (findN == 0) {
						BasicDBObject newshoujianren = new BasicDBObject();
						newshoujianren.put("name", name);
						newshoujianren.put("email", email);
						newshoujianren.put("extra", shuoming);
						configshoujianren.save(newshoujianren);
						System.out.println("add new shoujianren : " + name
								+ " to user db successfully!");
						result = true;
					} else {
						System.out.println("keywords : " + name
								+ " Existed in user db!!!");
					}
					mongo.close();
					//
				} catch (UnknownHostException e) {
					e.printStackTrace();
				} catch (MongoException e) {
					e.printStackTrace();
				}
				//
				return result;
			}
			//
			public List<N_Emailer_Info> getAllShoujianrenList(){
				List<N_Emailer_Info> shoujianrenList = new ArrayList<N_Emailer_Info>();
				try {
					//
					Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
					DB user_db = mongo.getDB(userDBname);
					String collectionName = N_MongoDB_Info.USR_CONFIG_SHOUJIANREN;
					DBCollection configshoujianren = user_db
							.getCollection(collectionName);
					// 查找是否存在同名字
					DBCursor cursor = configshoujianren.find(
							new BasicDBObject("name", new BasicDBObject(
									QueryOperators.EXISTS, true)));
					while(cursor.hasNext()){
						DBObject dbo = cursor.next();
						N_Emailer_Info newSJR = new N_Emailer_Info();
						ObjectId oid = (ObjectId) dbo.get("_id");
						String name = "";
						if(dbo.get("name")!=null)
							 name = dbo.get("name").toString();
						String email = "";
						if(dbo.get("email")!=null)
							email = dbo.get("email").toString();
						String extra = "";
						if(dbo.get("extra")!=null)
							extra = dbo.get("extra").toString();
						newSJR.setExtra(extra);
						newSJR.setOid(oid);
						newSJR.setName(name);
						newSJR.setEmail(email);
						shoujianrenList.add(newSJR);
					}
					mongo.close();
					//
				} catch (UnknownHostException e) {
					e.printStackTrace();
				} catch (MongoException e) {
					e.printStackTrace();
				}
				return shoujianrenList;
			}
			//根据版块名字 删除版块
			public boolean deleteShoujianren(ObjectId oid){
				boolean result = false;
				try {
					//
					Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
					DB user_db = mongo.getDB(userDBname);
					String collectionName = N_MongoDB_Info.USR_CONFIG_SHOUJIANREN;
					DBCollection configshoujianren = user_db
							.getCollection(collectionName);
					//delete
					configshoujianren.remove(new BasicDBObject("_id", oid));
					result = true;
					mongo.close();
					//
				} catch (UnknownHostException e) {
					e.printStackTrace();
				} catch (MongoException e) {
					e.printStackTrace();
				}
				return result;
			}
		///////////////////////////////////////////////////////////
		//操作用户 待处理的 数据
		public boolean addToAttentionCollection(N_Bankuai_Shijian_Renwu_Info nbsri){
			boolean result = false;
			try {
				//
				Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
				DB user_db = mongo.getDB(userDBname);
				String collectionName = N_MongoDB_Info.USER_ATTENTION_BANKUAI_SHIJIAN_RENWU;
				DBCollection attentionC = user_db
						.getCollection(collectionName);
				//
				attentionC.createIndex(new BasicDBObject("add-time", -1));
				//
				int findN = attentionC.find(new BasicDBObject("old-id", nbsri.getOid())).count();
				if(findN == 0){					//避免重复！
					//add
					DBObject newDBO = new BasicDBObject();
					newDBO.put("old-id", nbsri.getOid());
					newDBO.put("title", nbsri.getTitle());
					newDBO.put("content", nbsri.getContent());
					newDBO.put("url", nbsri.getUrl());
					newDBO.put("source", nbsri.getSource());
					newDBO.put("deal", false);
					Calendar cc = Calendar.getInstance();
					DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					String ct = df.format(cc.getTime());
					newDBO.put("add-time", ct);
					attentionC.save(newDBO);
				}
				//
				mongo.close();
				//
			} catch (UnknownHostException e) {
				e.printStackTrace();
			} catch (MongoException e) {
				e.printStackTrace();
			}
			return result;
		}
		//获取所有未处理的数据
		public List<N_Bankuai_Shijian_Renwu_Info> getAllUndealedData(){
			List<N_Bankuai_Shijian_Renwu_Info> undealedList = new ArrayList<N_Bankuai_Shijian_Renwu_Info>();
			//
			try {
				//
				Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
				DB user_db = mongo.getDB(userDBname);
				String collectionName = N_MongoDB_Info.USER_ATTENTION_BANKUAI_SHIJIAN_RENWU;
				DBCollection attentionC = user_db
						.getCollection(collectionName);
				DBCursor cursor = attentionC.find(new BasicDBObject("deal", false)).limit(N_DataBuffer.UNDEALED_MAX_DATA_NUM);
				while(cursor.hasNext()){
					DBObject dbo = cursor.next();
					N_Bankuai_Shijian_Renwu_Info nbsri = new N_Bankuai_Shijian_Renwu_Info();
					if(dbo.get("title")!=null)
						nbsri.setTitle(dbo.get("title").toString());
					if(dbo.get("content")!=null)
						nbsri.setContent(dbo.get("content").toString());
					if(dbo.get("source")!=null)
						nbsri.setSource(dbo.get("source").toString());
					nbsri.setOid((ObjectId)dbo.get("_id"));
					if(dbo.get("url")!=null)
						nbsri.setUrl(dbo.get("url").toString());
					if(dbo.get("add-time")!=null)
						nbsri.setAddTime(dbo.get("add-time").toString());
					nbsri.setDeal((Boolean)dbo.get("deal"));
					undealedList.add(nbsri);
					//
				}
				//
				mongo.close();
				//
			} catch (UnknownHostException e) {
				e.printStackTrace();
			} catch (MongoException e) {
				e.printStackTrace();
			}
			//
			return undealedList;
		}
		//change deal state
		public void changeDealState(ObjectId oid, boolean state){
			try {
				//
				Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
				DB user_db = mongo.getDB(userDBname);
				String collectionName = N_MongoDB_Info.USER_ATTENTION_BANKUAI_SHIJIAN_RENWU;
				DBCollection attentionC = user_db
						.getCollection(collectionName);
				attentionC.update(new BasicDBObject("_id", oid), new BasicDBObject(
						"$set", new BasicDBObject("deal", state)), true, false);
				//
				mongo.close();
				//
			} catch (UnknownHostException e) {
				e.printStackTrace();
			} catch (MongoException e) {
				e.printStackTrace();
			}
			
		}
		
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
	public static void main(String[] args){
		N_UDBO_BanKuai_ShiJian_RenWu test = new N_UDBO_BanKuai_ShiJian_RenWu("user_test_database");
		List<String> tags = new ArrayList<String>();
		tags.add("经济");
		tags.add("政治");
		tags.add("财经");
		test.createNewBanKuai("政治", tags, "bankuai");
		test.getBanKuaiTags("财经","bankuai");
	}
}
