package newMongoDB;

import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.bson.types.ObjectId;

import newBasic.N_BBSInfo;
import newBasic.N_KeywordsInfo;
import newBasic.N_NewsInfo;
import newBasic.N_NewsPaperInfo;
import newBasic.N_WeiboInfo;
import newConstants.N_CONFIG;
import newConstants.N_Constants;
import newConstants.N_DataBuffer;
import newConstants.N_KWMongoDB;
import newConstants.N_MongoDB_Info;
import newConstants.N_UserMongoDB;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import com.mongodb.MongoException;
import com.mongodb.QueryOperators;

import newDataSort.N_BBS_SortBy;
import newDataSort.N_NewsPaper_SortBy;
import newDataSort.N_News_SortBy;
import newDataSort.N_Weibo_SortBy;

/*
 * 2014年8月17日13:28:39
 * 操作用户 数据库
 * niuliqiang
 */
public class N_UserDBOperation {
	public String userDBname;

	public N_UserDBOperation(String dbName) {
		userDBname = dbName;
	}

	// =========================================================================//
	// 添加新的关键字到 个人数据库
	public boolean addNewKeywordsToDB(String kw) {
		boolean result = false;
		//
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB user_db = mongo.getDB(userDBname);
			DBCollection keywordsC = user_db.getCollection(N_Constants.USER_KEYWORDS_COLLECTION);
			// 查找是否存在同名字
			int findAllNum  = keywordsC.find().count();
			int findN = keywordsC.find(new BasicDBObject(N_KWMongoDB.KEYWORDS_KEYWORDS, kw))
					.count();
			if (findN == 0 && findAllNum < N_Constants.MAX_USER_KEYWORDS_NUM) {
				BasicDBObject newKeywords = new BasicDBObject();
				newKeywords.put(N_KWMongoDB.KEYWORDS_KEYWORDS, kw);
				newKeywords.put(N_KWMongoDB.KEYWORDS_ATTENTION, true);
				newKeywords.put(N_KWMongoDB.KEYWORDS_PAGE_NUM, 1);
				newKeywords.put(N_KWMongoDB.KEYWORDS_COUNT, 1);
				keywordsC.save(newKeywords);
				System.out.println("add new keywords : " + kw
						+ " to user db successfully!");
				result = true;
				// add to global db
				this.addNewKeywordsToGlobalDB(kw);
			} else {
				System.out.println("keywords : " + kw
						+ " Existed in user db!!!");
			}
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		//
		return result;
	}

	//
	// 添加新的关键字到全局数据库
	public boolean addNewKeywordsToGlobalDB(String kw) {
		boolean result = false;
		//
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB all_users_db = mongo.getDB(N_UserMongoDB.allUsersMongoDB);
			DBCollection all_users_keywords = all_users_db
					.getCollection(N_UserMongoDB.allKeywordsCollection);
			// 查找是否存在同名字
			int findN = all_users_keywords.find(
					new BasicDBObject(N_KWMongoDB.KEYWORDS_KEYWORDS, kw))
					.count();
			if (findN == 0) {
				BasicDBObject newKeywords = new BasicDBObject();
				newKeywords.put(N_KWMongoDB.KEYWORDS_KEYWORDS, kw);
				newKeywords.put(N_KWMongoDB.KEYWORDS_ATTENTION, true);
				newKeywords.put(N_KWMongoDB.KEYWORDS_PAGE_NUM, 1);
				newKeywords.put(N_KWMongoDB.KEYWORDS_COUNT, 1);
				all_users_keywords.save(newKeywords);
				System.out.println("add new keywords : " + kw
						+ " to global db successfully!");
				result = true;
			} else {
				// 更新用户计数
				DBCursor cursor = all_users_keywords.find(new BasicDBObject(
						N_KWMongoDB.KEYWORDS_KEYWORDS, kw));
				int count = 0;
				if (cursor.hasNext()) {
					DBObject dbo = cursor.next();
					if (dbo.get(N_KWMongoDB.KEYWORDS_COUNT) != null)
						count = (Integer) dbo.get(N_KWMongoDB.KEYWORDS_COUNT);
				}
				all_users_keywords.update(new BasicDBObject(
						N_KWMongoDB.KEYWORDS_KEYWORDS, kw), new BasicDBObject(
						"$set", new BasicDBObject(N_KWMongoDB.KEYWORDS_COUNT,
								count + 1)), true, false);
				System.out.println("keywords : " + kw
						+ " Existed in global db!!!");
				//
			}
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		//
		return result;
	}

	// 获取用户所有关键字list
	public List<N_KeywordsInfo> getUserKeywordsList() {
		List<N_KeywordsInfo> allUserKeywordsList = new ArrayList<N_KeywordsInfo>();
		//
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB user_db = mongo.getDB(userDBname);
			DBCollection keywordsC = user_db
					.getCollection(N_Constants.USER_KEYWORDS_COLLECTION);
			// 查找是否存在同名字
			System.out.print("------");
			DBCursor cursor = keywordsC.find();
			while (cursor.hasNext()) {
				DBObject dbo = cursor.next();
				String kw = dbo.get(N_KWMongoDB.KEYWORDS_KEYWORDS).toString();
				System.out.print("【" + kw + "】");
				boolean attention = (Boolean) dbo.get(N_KWMongoDB.KEYWORDS_ATTENTION);
				int count = (Integer) dbo.get(N_KWMongoDB.KEYWORDS_COUNT);
				int page_num = (Integer) dbo.get(N_KWMongoDB.KEYWORDS_PAGE_NUM);
				N_KeywordsInfo keyword = new N_KeywordsInfo(kw, page_num,count, attention);
				allUserKeywordsList.add(keyword);
			}
			System.out.println("------");
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		return allUserKeywordsList;
	}

	//
	// 修改关键字关注与否
	public boolean modifyKeywordAttention(String keywords, boolean attention) {
		boolean result = false;
		try {
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB user_db = mongo.getDB(userDBname);
			DBCollection keywordsC = user_db
					.getCollection(N_Constants.USER_KEYWORDS_COLLECTION);
			//
			if ((keywordsC.find(new BasicDBObject(
					N_KWMongoDB.KEYWORDS_KEYWORDS, keywords)).hasNext())) {
				keywordsC.update(new BasicDBObject(
						N_KWMongoDB.KEYWORDS_KEYWORDS, keywords),
						new BasicDBObject("$set", new BasicDBObject(
								N_KWMongoDB.KEYWORDS_ATTENTION, attention)),
						true, false);
				result = true;
			}
			//
			System.out.println("modify existed keywords : " + keywords + " : "
					+ attention);
			mongo.close();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		return result;
	}

	//
	public boolean deleteExistedKeywords(String keywords) {
		boolean delete = false;
		try {
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB user_db = mongo.getDB(userDBname);
			DBCollection keywordsC = user_db
					.getCollection(N_Constants.USER_KEYWORDS_COLLECTION);
			//
			if ((keywordsC.find(new BasicDBObject(
					N_KWMongoDB.KEYWORDS_KEYWORDS, keywords)).hasNext()))
				delete = true;
			keywordsC.findAndRemove(new BasicDBObject(
					N_KWMongoDB.KEYWORDS_KEYWORDS, keywords));
			//
			System.out.println("delete existed keywords : " + keywords
					+ " successfully!");
			// 删除全局数据库中的关键字
			this.deleteExistedKeywordsFromGlobal(keywords);
			//
			mongo.close();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		return delete;
	}

	public void deleteExistedKeywordsFromGlobal(String keywords) {
		try {
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB all_users_db = mongo.getDB(N_UserMongoDB.allUsersMongoDB);
			DBCollection all_users_keywords = all_users_db
					.getCollection(N_UserMongoDB.allKeywordsCollection);
			//
			int count = 0;
			DBCursor cursor = all_users_keywords.find(new BasicDBObject(
					N_KWMongoDB.KEYWORDS_KEYWORDS, keywords));
			if (cursor.hasNext()) {
				DBObject dbo = cursor.next();
				if (dbo.get(N_KWMongoDB.KEYWORDS_COUNT) != null)
					count = (Integer) dbo.get(N_KWMongoDB.KEYWORDS_COUNT);
			}
			if (count > 1) {
				all_users_keywords.update(new BasicDBObject(
						N_KWMongoDB.KEYWORDS_KEYWORDS, keywords),
						new BasicDBObject("$set", new BasicDBObject(
								N_KWMongoDB.KEYWORDS_COUNT, count - 1)), true,
						false);
				System.out.println("delete existed keywords from Global DB: "
						+ keywords + " count : " + (count - 1));
			} else {
				all_users_keywords.findAndRemove(new BasicDBObject(
						N_KWMongoDB.KEYWORDS_KEYWORDS, keywords));
				//
				System.out.println("delete existed keywords from Global DB: "
						+ keywords + " successfully!");
			}
			mongo.close();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
	}

	// =========================================================================//
	// user config collection
	public String getUserPastTime() {
		String pastTime = N_CONFIG.USER_CONFIG_PAST_HOUR;
		//
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB user_db = mongo.getDB(userDBname);
			DBCollection configC = user_db
					.getCollection(N_Constants.USER_CONFIG_COLLECTION);
			// 查找是否存在同名字
			DBCursor cursor = configC.find(new BasicDBObject(
					N_CONFIG.USER_CONFIG_PASTTIME, new BasicDBObject(
							QueryOperators.EXISTS, true)));
			if (cursor.hasNext()) {
				DBObject dbo = cursor.next();
				pastTime = dbo.get(N_CONFIG.USER_CONFIG_PASTTIME).toString();
			} else {
				BasicDBObject config = new BasicDBObject();
				config.put(N_CONFIG.USER_CONFIG_PASTTIME,
						N_CONFIG.USER_CONFIG_PAST_HOUR);
				configC.save(config);
				pastTime = N_CONFIG.USER_CONFIG_PAST_HOUR;
			}
			System.out.println("------user past time is : " + pastTime);
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		//
		return pastTime;
	}

	//
	public boolean changeUserPastTime(String past) {
		boolean result = false;
		//
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB user_db = mongo.getDB(userDBname);
			DBCollection configC = user_db
					.getCollection(N_Constants.USER_CONFIG_COLLECTION);
			// update past time
			configC.update(new BasicDBObject(N_CONFIG.USER_CONFIG_PASTTIME,
					new BasicDBObject(QueryOperators.EXISTS, true)),
					new BasicDBObject("$set", new BasicDBObject(
							N_CONFIG.USER_CONFIG_PASTTIME, past)), true, false);
			result = true;
			System.out.println("---update user past time is : " + past);
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		//
		return result;
	}

	// ===================================bbs======================================//
	//
	public List<N_BBSInfo> getUserAllBBS(String sortType) {
		System.out.println("------从MongoDB 读取 论坛数据!");
		List<N_BBSInfo> userBBSList = new ArrayList<N_BBSInfo>();
		//
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB user_db = mongo.getDB(userDBname);
			DBCollection bbsC = user_db
					.getCollection(N_Constants.USER_BBS_COLLECTION);
			//
			// 创建索引
			/*
			 * List<DBObject> indexList = bbsC.getIndexInfo();
			 * if(indexList.isEmpty()) bbsC.createIndex(new
			 * BasicDBObject("create_time", -1)); else{ bbsC.createIndex(new
			 * BasicDBObject("create_time", -1));
			 * System.out.println("===weibo index"); for(DBObject index :
			 * indexList){ System.out.print(index); } System.out.println(""); }
			 */
			bbsC.createIndex(new BasicDBObject("time", -1));
			//
			String pastTime = this.getUserPastTime();
			Calendar c = Calendar.getInstance();
			int year = c.get(Calendar.YEAR);
			int month = c.get(Calendar.MONTH) + 1;
			int day = c.get(Calendar.DAY_OF_MONTH);
			int hour = c.get(Calendar.HOUR_OF_DAY);
			int minute = c.get(Calendar.MINUTE);
			int second = c.get(Calendar.SECOND);
			if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_HOUR)) {
				if (hour > 0)
					hour -= 1;
				else
					hour = 0;
			} else if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_DAY)) {
				if (day > 0)
					day -= 1;
				else
					day = 0;
			} else if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_WEEK)) {
				if (day > 7)
					day -= 7;
				else
					day = 0;
			} else if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_MONTH)) {
				if (month > 1)
					month -= 1;
				else
					month = 1;
			} else if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_NULL)) {
				year = 0;
				month = 0;
				day = 0;
				hour = 0;
				minute = 0;
				second = 0;
			} else {
				if (day > 0)
					day -= 1;
				else
					day = 0;
			}
			c.set(year, month - 1, day, hour, minute, second);
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String sinceTime = df.format(c.getTime());
			System.out.println("------bbs sinceTime : " + sinceTime);
			//
			long start = System.currentTimeMillis();
			DBCursor cursor = bbsC.find(
					new BasicDBObject("time", new BasicDBObject("$gte",
							sinceTime)));//.limit(N_DataBuffer.BBS_MAX_DATA_NUM);
			long end1 = System.currentTimeMillis();
			//cursor.batchSize(N_DataBuffer.CURSOR_BATCH_SIZE);
			System.out.println("------read mongo : " + (end1 - start) + " ms");
			// keywords filter
			List<N_KeywordsInfo> userKeywordsList = this.getUserKeywordsList();
			// keywords string
			List<String> userKeywordsStrList = new ArrayList<String>();
			for (int i = 0; i < userKeywordsList.size(); i++) {
				userKeywordsStrList.add(userKeywordsList.get(i).getKeywords());
			}
			// all bbs
			int queryNum = 0;
			while (cursor.hasNext() && queryNum < N_DataBuffer.BBS_MAX_DATA_NUM) {
				queryNum++;
				DBObject dbo = cursor.next();
				ObjectId oid = (ObjectId) dbo.get("_id");
				String content = "";
				if (dbo.get("content") != null)
					content = dbo.get("content").toString();
				String title = "";
				if (dbo.get("title") != null)
					title = dbo.get("title").toString();
				String url = "";
				if (dbo.get("url") != null)
					url = dbo.get("url").toString();
				String time = "";
				if (dbo.get("time") != null)
					time = dbo.get("time").toString();
				int reply = 0;
				if (dbo.get("n_reply") != null) {
					if (dbo.get("n_reply") instanceof Integer)
						reply = (Integer) dbo.get("n_reply");
					else if (dbo.get("n_reply") instanceof String)
						reply = Integer.parseInt((String) dbo.get("n_reply"));
				}
				int click = 0;
				if (dbo.get("n_click") != null) {
					if (dbo.get("n_click") instanceof Integer)
						click = (Integer) dbo.get("n_click");
					else if (dbo.get("n_click") instanceof String)
						click = Integer.parseInt((String) dbo.get("n_click"));
				}

				int sentiment = 0;
				if (dbo.get("sentiment") != null)
					sentiment = (Integer) dbo.get("sentiment");
				String sent = N_Constants.SENTIMENT_NEUTRAL;
				if (sentiment < 0)
					sent = N_Constants.SENTIMENT_NEGATIVE;
				else if (sentiment > 0)
					sent = N_Constants.SENTIMENT_POSITIVE;
				double attention = 0;
				if (dbo.get("attention") != null)
					attention = (Double) dbo.get("attention");
				attention += (reply + click) / 1000.0;
				String source = "";
				if (dbo.get("source") != null)
					source = dbo.get("source").toString();
				String source_url = "";
				if (dbo.get("source_url") != null)
					source_url = dbo.get("source_url").toString();
				List<String> tags = new ArrayList<String>();
				if (dbo.get("tags") != null)
					tags = (List<String>) dbo.get("tags");
				int tagsSize = tags.size();
				attention *= (tagsSize + 1);
				attention = (double) ((int) (attention * 1000)) / 1000.0;
				//
				N_BBSInfo nBBS = new N_BBSInfo();
				nBBS.setOid(oid);
				nBBS.setAttention(attention);
				nBBS.setClickNum(click);
				nBBS.setContent(content);
				nBBS.setReplyNum(reply);
				nBBS.setSentiment(sent);
				nBBS.setSource(source);
				nBBS.setSource_url(source_url);
				nBBS.setTags(tags);
				nBBS.setTime(time);
				nBBS.setTitle(title);
				nBBS.setUrl(url);
				// filter
				boolean attentionKeywords = false;
				for (int i = 0; i < tags.size(); i++) {
					String tag = tags.get(i);
					int keywordsIndex = userKeywordsStrList.indexOf(tag);
					if (keywordsIndex >= 0) {
						N_KeywordsInfo nkw = userKeywordsList
								.get(keywordsIndex);
						if (nkw.isAttention()) {
							attentionKeywords = true;
						}
					}
					if (attentionKeywords)
						break;
				}
				if (attentionKeywords)
					userBBSList.add(nBBS);
			}
			N_DataBuffer.bbsDataBuffer = userBBSList;
			//
			long end2 = System.currentTimeMillis();
			System.out.println("------filter : " + (end2 - end1) + " ms");
			// sort
			long sortStart = System.currentTimeMillis();
			N_BBS_SortBy sort = new N_BBS_SortBy(sortType);
			sort.sortDataListByQuickSort(N_DataBuffer.bbsDataBuffer, 0,
					N_DataBuffer.bbsDataBuffer.size() - 1);
			long sortEnd = System.currentTimeMillis();
			System.out.println("------bbs sort : " + (sortEnd - sortStart)
					+ " ms");
			//
			long end = System.currentTimeMillis();
			System.out.println("------耗时：" + (end - start) + "毫秒!"
					+ "--- 数据总数为：" + userBBSList.size() + "/" + queryNum);
			//
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		//
		return userBBSList;
	}

	public void changeBBSSentiment(ObjectId oid, int sent) {
		System.out.println("------在MongoDB 修改 论坛数据的情感倾向!");
		//
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB user_db = mongo.getDB(userDBname);
			DBCollection bbsC = user_db
					.getCollection(N_Constants.USER_BBS_COLLECTION);
			bbsC.update(new BasicDBObject("_id", oid), new BasicDBObject(
					"$set", new BasicDBObject("sentiment", sent)), true, false);
			//
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
	}

	// ===================================newspaper======================================//
	//
	public List<N_NewsPaperInfo> getUserAllNewsPaper(String sortType) {
		System.out.println("------从MongoDB 读取 报刊数据!");
		List<N_NewsPaperInfo> userNewsPaperList = new ArrayList<N_NewsPaperInfo>();
		//
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB user_db = mongo.getDB(userDBname);
			DBCollection NewsPaperC = user_db
					.getCollection(N_Constants.USER_NEWSPAPER_COLLECTION);
			NewsPaperC.createIndex(new BasicDBObject("publish_time", -1));
			//
			String pastTime = this.getUserPastTime();
			Calendar c = Calendar.getInstance();
			int year = c.get(Calendar.YEAR);
			int month = c.get(Calendar.MONTH) + 1;
			int day = c.get(Calendar.DAY_OF_MONTH);
			int hour = c.get(Calendar.HOUR_OF_DAY);
			int minute = c.get(Calendar.MINUTE);
			int second = c.get(Calendar.SECOND);
			if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_HOUR)) {
				if (hour > 0)
					hour -= 1;
				else
					hour = 0;
			} else if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_DAY)) {
				if (day > 0)
					day -= 1;
				else
					day = 0;
			} else if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_WEEK)) {
				if (day > 7)
					day -= 7;
				else
					day = 0;
			} else if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_MONTH)) {
				if (month > 1)
					month -= 1;
				else
					month = 1;
			} else if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_NULL)) {
				year = 0;
				month = 0;
				day = 0;
				hour = 0;
				minute = 0;
				second = 0;
			} else {
				if (day > 0)
					day -= 1;
				else
					day = 0;
			}
			c.set(year, month - 1, day, hour, minute, second);
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String sinceTime = df.format(c.getTime());
			System.out.println("------NewsPaper sinceTime : " + sinceTime);
			//
			long start = System.currentTimeMillis();
			DBCursor cursor = NewsPaperC.find(
					new BasicDBObject("publish_time", new BasicDBObject("$gte",
							sinceTime))).limit(N_DataBuffer.NP_MAX_DATA_NUM);
			long end1 = System.currentTimeMillis();
			//cursor.batchSize(N_DataBuffer.CURSOR_BATCH_SIZE);
			System.out.println("------read mongo : " + (end1 - start) + " ms");
			// keywords filter
			List<N_KeywordsInfo> userKeywordsList = this.getUserKeywordsList();
			// keywords string
			List<String> userKeywordsStrList = new ArrayList<String>();
			for (int i = 0; i < userKeywordsList.size(); i++) {
				userKeywordsStrList.add(userKeywordsList.get(i).getKeywords());
			}
			// all NewsPaper
			int queryNum = 0;
			while (cursor.hasNext()) {
				queryNum++;
				DBObject dbo = cursor.next();
				ObjectId oid = (ObjectId) dbo.get("_id");
				String content = "";
				if (dbo.get("content") != null)
					content = dbo.get("content").toString();
				String title = "";
				if (dbo.get("biaoti") != null)
					title = dbo.get("biaoti").toString();
				String url = "";
				if (dbo.get("url") != null)
					url = dbo.get("url").toString();
				String time = "";
				if (dbo.get("publish_time") != null)
					time = dbo.get("publish_time").toString();
				int sentiment = 0;
				if (dbo.get("sentiment") != null)
					sentiment = (Integer) dbo.get("sentiment");
				String sent = N_Constants.SENTIMENT_NEUTRAL;
				if (sentiment < 0)
					sent = N_Constants.SENTIMENT_NEGATIVE;
				else if (sentiment > 0)
					sent = N_Constants.SENTIMENT_POSITIVE;
				String source = "";
				if (dbo.get("source") != null)
					source = dbo.get("source").toString();
				List<String> tags = new ArrayList<String>();
				if (dbo.get("tags") != null)
					tags = (List<String>) dbo.get("tags");
				//
				N_NewsPaperInfo nNewsPaper = new N_NewsPaperInfo();
				nNewsPaper.setOid(oid);
				nNewsPaper.setContent(content);
				nNewsPaper.setSentiment(sent);
				nNewsPaper.setSource(source);
				nNewsPaper.setTags(tags);
				nNewsPaper.setTime(time);
				nNewsPaper.setTitle(title);
				nNewsPaper.setUrl(url);
				// filter
				boolean attentionKeywords = false;
				for (int i = 0; i < tags.size(); i++) {
					String tag = tags.get(i);
					int keywordsIndex = userKeywordsStrList.indexOf(tag);
					if (keywordsIndex >= 0) {
						N_KeywordsInfo nkw = userKeywordsList
								.get(keywordsIndex);
						if (nkw.isAttention()) {
							attentionKeywords = true;
						}
					}
					if (attentionKeywords)
						break;
				}
				if (attentionKeywords)
					userNewsPaperList.add(nNewsPaper);
			}
			N_DataBuffer.npDataBuffer = userNewsPaperList;
			//
			long end2 = System.currentTimeMillis();
			System.out.println("------filter : " + (end2 - end1) + " ms");
			// sort
			long sortStart = System.currentTimeMillis();
			N_NewsPaper_SortBy sort = new N_NewsPaper_SortBy(sortType);
			sort.sortDataListByQuickSort(N_DataBuffer.npDataBuffer, 0,
					N_DataBuffer.npDataBuffer.size() - 1);
			long sortEnd = System.currentTimeMillis();
			System.out.println("------newspaper sort : "
					+ (sortEnd - sortStart) + " ms");
			//
			long end = System.currentTimeMillis();
			System.out.println("------耗时：" + (end - start) + "毫秒!"
					+ "--- 数据总数为：" + userNewsPaperList.size() + "/" + queryNum);
			//
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		//
		return userNewsPaperList;
	}

	public void changeNPSentiment(ObjectId oid, int sent) {
		System.out.println("------在MongoDB 修改 报刊数据的情感倾向!");
		//
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB user_db = mongo.getDB(userDBname);
			DBCollection bbsC = user_db
					.getCollection(N_Constants.USER_NEWSPAPER_COLLECTION);
			bbsC.update(new BasicDBObject("_id", oid), new BasicDBObject(
					"$set", new BasicDBObject("sentiment", sent)), true, false);
			//
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
	}

	// =================================weibo======================================//
	// 2014年9月17日16:25:21
	public List<N_WeiboInfo> getUserAllWeibo(String sortType) {
		System.out.println("------从MongoDB 读取 微博数据!");
		List<N_WeiboInfo> userWeiboList = new ArrayList<N_WeiboInfo>();
		//
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB user_db = mongo.getDB(userDBname);
			DBCollection WeiboC = user_db
					.getCollection(N_Constants.USER_WEIBO_COLLECTION);
			WeiboC.createIndex(new BasicDBObject("time", -1));
			//
			String pastTime = this.getUserPastTime();
			Calendar c = Calendar.getInstance();
			int year = c.get(Calendar.YEAR);
			int month = c.get(Calendar.MONTH) + 1;
			int day = c.get(Calendar.DAY_OF_MONTH);
			int hour = c.get(Calendar.HOUR_OF_DAY);
			int minute = c.get(Calendar.MINUTE);
			int second = c.get(Calendar.SECOND);
			if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_HOUR)) {
				if (hour > 0)
					hour -= 1;
				else
					hour = 0;
			} else if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_DAY)) {
				if (day > 0)
					day -= 1;
				else
					day = 0;
			} else if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_WEEK)) {
				if (day > 7)
					day -= 7;
				else
					day = 0;
			} else if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_MONTH)) {
				if (month > 1)
					month -= 1;
				else
					month = 1;
			} else if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_NULL)) {
				year = 0;
				month = 0;
				day = 0;
				hour = 0;
				minute = 0;
				second = 0;
			} else {
				if (day > 0)
					day -= 1;
				else
					day = 0;
			}
			c.set(year, month - 1, day, hour, minute, second);
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String sinceTime = df.format(c.getTime());
			System.out.println("------Weibo sinceTime : " + sinceTime);
			//
			long start = System.currentTimeMillis();
			DBCursor cursor = WeiboC.find(
					new BasicDBObject("time", new BasicDBObject("$gte",
							sinceTime))).limit(N_DataBuffer.WEIBO_MAX_DATA_NUM);
			long end1 = System.currentTimeMillis();
			//cursor.batchSize(N_DataBuffer.CURSOR_BATCH_SIZE);
			//System.out.println(cursor.explain());
			System.out.println("------read mongo : " + (end1 - start) + " ms"+" cursor count : "+cursor.count());
			// keywords filter
			List<N_KeywordsInfo> userKeywordsList = this.getUserKeywordsList();
			// keywords string
			List<String> userKeywordsStrList = new ArrayList<String>();
			for (int i = 0; i < userKeywordsList.size(); i++) {
				userKeywordsStrList.add(userKeywordsList.get(i).getKeywords());
			}
			// all Weibo
			int queryNum = 0;
			/*
			long cycle0 = System.currentTimeMillis();
			System.out.println(cursor.count()+" "+cursor.size());
			List<DBObject> dboList = cursor.toArray();
			System.out.println(dboList.size());
			long cycle = System.currentTimeMillis();
			System.out.print(""+(cycle-cycle0)+"ms");
			int cursorIndex = 0;
			*/
			while (cursor.hasNext() && queryNum < N_DataBuffer.WEIBO_MAX_DATA_NUM) {
				//
				queryNum++;
				DBObject dbo = cursor.next();
				ObjectId oid = (ObjectId) dbo.get("_id");
				String content = "";
				if (dbo.get("content") != null)
					content = dbo.get("content").toString();
				String url = "";
				if (dbo.get("url") != null)
					url = dbo.get("url").toString();
				String time = "";
				if (dbo.get("time") != null)
					time = dbo.get("time").toString();
				int forward = 0;
				if (dbo.get("n_forward") != null)
					forward = (Integer) dbo.get("n_forward");
				int like = 0;
				if (dbo.get("n_like") != null)
					like = (Integer) dbo.get("n_like");
				int comment = 0;
				if (dbo.get("n_comment") != null)
					comment = (Integer) dbo.get("n_comment");
				int favorite = 0;
				if (dbo.get("n_favorite") != null)
					favorite = (Integer) dbo.get("n_favorite");
				int sentiment = 0;
				if (dbo.get("sentiment") != null)
					sentiment = (Integer) dbo.get("sentiment");
				double attention = 0;
				if (dbo.get("attention") != null)
					attention = (Double) dbo.get("attention");
				attention += (forward + like + comment + favorite) / 1000.0;
				String sent = N_Constants.SENTIMENT_NEUTRAL;
				if (sentiment < 0)
					sent = N_Constants.SENTIMENT_NEGATIVE;
				else if (sentiment > 0)
					sent = N_Constants.SENTIMENT_POSITIVE;
				String source = "";
				if (dbo.get("source") != null)
					source = dbo.get("source").toString();
				List<String> tags = new ArrayList<String>();
				if (dbo.get("keyword") != null)
					tags = (List<String>) dbo.get("keyword");
				//
				N_WeiboInfo nWeibo = new N_WeiboInfo();
				nWeibo.setOid(oid);
				nWeibo.setContent(content);
				nWeibo.setUrl(url);
				nWeibo.setTime(time);
				nWeibo.setForward(forward);
				nWeibo.setFavorite(favorite);
				nWeibo.setComment(comment);
				nWeibo.setLike(like);
				nWeibo.setKeyWords(tags);
				//
				int tagsSize = tags.size();
				attention *= (tagsSize + 1);
				attention = (double) ((int) (attention * 1000)) / 1000.0;
				//
				nWeibo.setAttention(attention);
				nWeibo.setSentiment(sent);
				// filter
				
				boolean attentionKeywords = false;
				for (int i = 0; i < tags.size(); i++) {
					String tag = tags.get(i);
					int keywordsIndex = userKeywordsStrList.indexOf(tag);
					if (keywordsIndex >= 0) {
						N_KeywordsInfo nkw = userKeywordsList
								.get(keywordsIndex);
						if (nkw.isAttention()) {
							attentionKeywords = true;
						}
					}
					if (attentionKeywords)
						break;
				}
				if (attentionKeywords)
					userWeiboList.add(nWeibo);
			}
			N_DataBuffer.weiboDataBuffer = userWeiboList;
			long end2 = System.currentTimeMillis();
			System.out.println("------filter : " + (end2 - end1) + " ms");
			// sort
			long sortStart = System.currentTimeMillis();
			N_Weibo_SortBy sort = new N_Weibo_SortBy(sortType);
			sort.sortDataListByQuickSort(N_DataBuffer.weiboDataBuffer, 0,
					N_DataBuffer.weiboDataBuffer.size() - 1);
			long sortEnd = System.currentTimeMillis();
			System.out.println("------weibo sort : " + (sortEnd - sortStart)
					+ " ms");
			//
			long end = System.currentTimeMillis();
			System.out.println("------耗时：" + (end - start) + "毫秒!"
					+ "--- 数据总数为：" + userWeiboList.size() + "/" + queryNum);
			//
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		//
		return userWeiboList;
	}

	public void changeWBSentiment(ObjectId oid, int sent) {
		System.out.println("------在MongoDB 修改 微博数据的情感倾向!");
		//
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB user_db = mongo.getDB(userDBname);
			DBCollection bbsC = user_db
					.getCollection(N_Constants.USER_WEIBO_COLLECTION);
			bbsC.update(new BasicDBObject("_id", oid), new BasicDBObject(
					"$set", new BasicDBObject("sentiment", sent)), true, false);
			//
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
	}

	// =================================news======================================//
	//
	public List<N_NewsInfo> getUserAllNews(String sortType) {
		System.out.println("------从MongoDB 读取 门户新闻数据!");
		List<N_NewsInfo> userNewsList = new ArrayList<N_NewsInfo>();
		//
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB user_db = mongo.getDB(userDBname);
			DBCollection NewsC = user_db
					.getCollection(N_Constants.USER_NEWS_COLLECTION);
			NewsC.createIndex(new BasicDBObject("publish_time", -1));
			//
			String pastTime = this.getUserPastTime();
			Calendar c = Calendar.getInstance();
			int year = c.get(Calendar.YEAR);
			int month = c.get(Calendar.MONTH) + 1;
			int day = c.get(Calendar.DAY_OF_MONTH);
			int hour = c.get(Calendar.HOUR_OF_DAY);
			int minute = c.get(Calendar.MINUTE);
			int second = c.get(Calendar.SECOND);
			if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_HOUR)) {
				if (hour > 0)
					hour -= 1;
				else
					hour = 0;
			} else if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_DAY)) {
				if (day > 0)
					day -= 1;
				else
					day = 0;
			} else if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_WEEK)) {
				if (day > 7)
					day -= 7;
				else
					day = 0;
			} else if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_MONTH)) {
				if (month > 1)
					month -= 1;
				else
					month = 1;
			} else if (pastTime.equals(N_CONFIG.USER_CONFIG_PAST_NULL)) {
				year = 0;
				month = 0;
				day = 0;
				hour = 0;
				minute = 0;
				second = 0;
			} else {
				if (day > 0)
					day -= 1;
				else
					day = 0;
			}
			c.set(year, month - 1, day, hour, minute, second);
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String sinceTime = df.format(c.getTime());
			System.out.println("------News sinceTime : " + sinceTime);
			//
			long start = System.currentTimeMillis();
			DBCursor cursor = NewsC.find(
					new BasicDBObject("publish_time", new BasicDBObject("$gte",
							sinceTime))).limit(N_DataBuffer.NEWS_MAX_DATA_NUM);
			//cursor.batchSize(N_DataBuffer.CURSOR_BATCH_SIZE);
			// keywords filter
			List<N_KeywordsInfo> userKeywordsList = this.getUserKeywordsList();
			// keywords string
			List<String> userKeywordsStrList = new ArrayList<String>();
			for (int i = 0; i < userKeywordsList.size(); i++) {
				userKeywordsStrList.add(userKeywordsList.get(i).getKeywords());
			}
			long end1 = System.currentTimeMillis();
			System.out.println("------read mongo : " + (end1 - start) + " ms");
			// all News
			int queryNum = 0;
			while (cursor.hasNext()) {
				queryNum++;
				DBObject dbo = cursor.next();
				ObjectId oid = (ObjectId) dbo.get("_id");
				String content = "";
				if (dbo.get("content") != null)
					content = dbo.get("content").toString();
				String title = "";
				if (dbo.get("title") != null)
					title = dbo.get("title").toString();
				String url = "";
				if (dbo.get("url") != null)
					url = dbo.get("url").toString();
				String time = "";
				if (dbo.get("publish_time") != null)
					time = dbo.get("publish_time").toString();
				int sentiment = 0;
				if (dbo.get("sentiment") != null)
					sentiment = (Integer) dbo.get("sentiment");
				String sent = N_Constants.SENTIMENT_NEUTRAL;
				if (sentiment < 0)
					sent = N_Constants.SENTIMENT_NEGATIVE;
				else if (sentiment > 0)
					sent = N_Constants.SENTIMENT_POSITIVE;
				String source = "";
				if (dbo.get("source") != null)
					source = dbo.get("source").toString();
				String sourceUrl = "";
				if (dbo.get("source_url") != null)
					sourceUrl = dbo.get("source_url").toString();
				List<String> tags = new ArrayList<String>();
				if (dbo.get("tags") != null)
					tags = (List<String>) dbo.get("tags");
				//
				N_NewsInfo nNews = new N_NewsInfo();
				nNews.setOid(oid);
				nNews.setContent(content);
				nNews.setSentiment(sent);
				nNews.setSource(source);
				nNews.setTags(tags);
				nNews.setTime(time);
				nNews.setTitle(title);
				nNews.setUrl(url);
				nNews.setSourceUrl(sourceUrl);
				// filter
				boolean attentionKeywords = false;
				for (int i = 0; i < tags.size(); i++) {
					String tag = tags.get(i);
					int keywordsIndex = userKeywordsStrList.indexOf(tag);
					if (keywordsIndex >= 0) {
						N_KeywordsInfo nkw = userKeywordsList
								.get(keywordsIndex);
						if (nkw.isAttention()) {
							attentionKeywords = true;
						}
					}
					if (attentionKeywords)
						break;
				}
				if (attentionKeywords)
					userNewsList.add(nNews);
			}
			long end2 = System.currentTimeMillis();
			System.out.println("------filter : " + (end2 - end1) + " ms");
			N_DataBuffer.newsDataBuffer = userNewsList;
			// sort
			long sortStart = System.currentTimeMillis();
			N_News_SortBy sort = new N_News_SortBy(sortType);
			sort.sortDataListByQuickSort(N_DataBuffer.newsDataBuffer, 0,
					N_DataBuffer.newsDataBuffer.size() - 1);
			long sortEnd = System.currentTimeMillis();
			System.out.println("------news sort : " + (sortEnd - sortStart)
					+ " ms");
			//
			long end = System.currentTimeMillis();
			System.out.println("------耗时：" + (end - start) + "毫秒!"
					+ "--- 数据总数为：" + userNewsList.size() + "/" + queryNum);
			//
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		//
		return userNewsList;
	}

	public void changeNewsSentiment(ObjectId oid, int sent) {
		System.out.println("------在MongoDB 修改 门户新闻数据的情感倾向!");
		//
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB user_db = mongo.getDB(userDBname);
			DBCollection bbsC = user_db
					.getCollection(N_Constants.USER_NEWS_COLLECTION);
			bbsC.update(new BasicDBObject("_id", oid), new BasicDBObject(
					"$set", new BasicDBObject("sentiment", sent)), true, false);
			//
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
	}

	// =======================================================================//

	// =======================================================================//
	public static void main(String[] args) {

	}
}
