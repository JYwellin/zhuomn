package newMongoDB;

import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import com.mongodb.MongoException;
import com.mongodb.WriteResult;

import newBasic.N_User;
import newConstants.N_Constants;
import newConstants.N_MongoDB_Info;
import newConstants.N_UserMongoDB;

/*
 * 2014年8月14日21:37:50
 * 用户 mongo DB操作类
 * @Niuliqiang
 */
public class N_UserOperation {
	// public N_User user;

	public N_UserOperation() {

	}

	// 添加用户
	public boolean addNewUser(N_User user) {
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB all_users_db = mongo.getDB(N_UserMongoDB.allUsersMongoDB);
			DBCollection all_users_info = all_users_db.getCollection(N_UserMongoDB.allUsersCollection);
			// 查找是否存在同名字
			int existedNum = all_users_info.find(new BasicDBObject(N_UserMongoDB.all_users_info_name, user
							.getU_name())).count();
			// System.out.println(":"+existedNum);
			if (existedNum > 0)
				return false;
			//
			DBObject dbo = new BasicDBObject();
			dbo.put(N_UserMongoDB.all_users_info_name, user.getU_name());
			dbo.put(N_UserMongoDB.all_users_info_pwd, user.getU_password());
			dbo.put(N_UserMongoDB.all_users_info_isConfirmed,
					user.isU_isConfirmed());
			dbo.put(N_UserMongoDB.all_users_info_joinTime, user.getU_joinTime());
			dbo.put(N_UserMongoDB.all_users_info_level, user.getU_level());
			dbo.put(N_UserMongoDB.all_users_info_mongoDB, user.getU_mongoDB());
			dbo.put(N_UserMongoDB.all_users_info_otherInfo,
					user.getU_otherInfo());
			dbo.put(N_UserMongoDB.all_users_info_role, user.getU_role());
			dbo.put(N_UserMongoDB.all_users_info_type, user.getType());
			
			all_users_info.save(dbo);
			//
			mongo.close();
			return true;
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		return false;
	}

	// 注册用户
	public boolean registerNewUser(String name, String pwd, String role) {
		//
		N_User user = new N_User();
		Calendar c = Calendar.getInstance();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String time = df.format(c.getTime());
		user.setU_name(name);
		user.setU_password(pwd);
		user.setU_joinTime(time);
		user.setU_role(role);
		user.setType(N_Constants.USER_GUEST);
		//
		boolean result = this.addNewUser(user);
		if (result) {
			System.out.println("------注册用户成功！" + user.getU_name());
			return true;
		} else {
			System.out.println("------注册用户失败！" + user.getU_name());
			return false;
		}
	}
	
	//插入或修改手机号
	public boolean savePhoneNumber(String name,String phoneNum){
		Mongo mongo;
		try{
			mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB all_users_db = mongo.getDB(N_UserMongoDB.allUsersMongoDB);
			DBCollection all_users_phone = all_users_db.getCollection(N_UserMongoDB.allUsersPhoneCollection);

			DBObject qu=new BasicDBObject();
			qu.put(N_UserMongoDB.all_users_info_name, name);
			DBObject re=all_users_phone.findOne(qu);
			WriteResult wr;
			if(re != null){
				DBObject set_in = new BasicDBObject();
				set_in.put(N_UserMongoDB.all_users_phone, phoneNum);
				
				DBObject set_out = new BasicDBObject("$set", set_in);
				wr=all_users_phone.update(qu, set_out);
			}else{
				DBObject sa=new BasicDBObject();
				sa.put(N_UserMongoDB.all_users_info_name, name);
				sa.put(N_UserMongoDB.all_users_phone, phoneNum);
				wr=all_users_phone.insert(sa);
			}

			if(wr.getN()==1){
				mongo.close();
				return true;
			}else{
				mongo.close();
				return false;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}
	
	//根据name查找手机号
	public String findPhoneByName(String name){
		Mongo mongo;
		try{
			mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB all_users_db = mongo.getDB(N_UserMongoDB.allUsersMongoDB);
			DBCollection all_users_phone = all_users_db.getCollection(N_UserMongoDB.allUsersPhoneCollection);
			
			DBObject qu=new BasicDBObject();
			qu.put(N_UserMongoDB.all_users_info_name, name);
			DBObject re=all_users_phone.findOne(qu);
			
			if(re != null){
				mongo.close();
				return re.get(N_UserMongoDB.all_users_phone).toString();
			}else{
				mongo.close();
				return "无";
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return "无";
	}

	//change password
	public boolean changePassword(String name,String pwd){
		Mongo mongo;
		try {
			mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB all_users_db = mongo.getDB(N_UserMongoDB.allUsersMongoDB);
			DBCollection all_users_info = all_users_db.getCollection(N_UserMongoDB.allUsersCollection);
			
			DBObject query = new BasicDBObject();
			query.put(N_UserMongoDB.all_users_info_name, name);
			
			DBObject set_in = new BasicDBObject();
			set_in.put(N_UserMongoDB.all_users_info_pwd, pwd);
			
			DBObject set_out = new BasicDBObject("$set", set_in);
			WriteResult wr=all_users_info.update(query, set_out);
			
			if(wr.getN()==1){
				mongo.close();
				return true;
			}else{
				mongo.close();
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	// check user
	public boolean checkUserIsExisted(String name, String pwd) {
		boolean existed = false;
		//
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB all_users_db = mongo.getDB(N_UserMongoDB.allUsersMongoDB);
			DBCollection all_users_info = all_users_db.getCollection(N_UserMongoDB.allUsersCollection);
			// 查找是否存在同名字
			DBCursor cursor = all_users_info.find(new BasicDBObject(N_UserMongoDB.all_users_info_name, name));
			if (cursor.hasNext()) {
				DBObject dbo = cursor.next();
				String existed_pwd = dbo.get(N_UserMongoDB.all_users_info_pwd).toString();
				if (existed_pwd.equals(pwd))
					existed = true;
			}
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		//
		return existed;
	}

	// check user login or not ?
	public boolean checkUserLogin(String name) {
		boolean login = false;
		//
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB all_users_db = mongo.getDB(N_UserMongoDB.allUsersMongoDB);
			DBCollection all_users_info = all_users_db.getCollection(N_UserMongoDB.allUsersCollection);
			// 查找是否存在同名字
			DBCursor cursor = all_users_info.find(new BasicDBObject(N_UserMongoDB.all_users_info_name, name));
			if (cursor.hasNext()) {
				DBObject dbo = cursor.next();
				if (dbo.get(N_UserMongoDB.all_users_info_login) != null) {
					login = (Boolean) dbo.get(N_UserMongoDB.all_users_info_login);
				}
			}
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		//
		return login;
	}

	// change user login state
	public void changeUserLogin(String name, boolean state) {
		//
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB all_users_db = mongo.getDB(N_UserMongoDB.allUsersMongoDB);
			DBCollection all_users_info = all_users_db.getCollection(N_UserMongoDB.allUsersCollection);
			// 查找是否存在同名字
			all_users_info.update(new BasicDBObject(N_UserMongoDB.all_users_info_name, name), new BasicDBObject(
					"$set", new BasicDBObject(N_UserMongoDB.all_users_info_login, state)), true, false);
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		//
	}

	// 获取用户所有信息
	public N_User getUserAllInfo(String name, String pwd) {
		N_User user = new N_User();
		//
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB all_users_db = mongo.getDB(N_UserMongoDB.allUsersMongoDB);
			DBCollection all_users_info = all_users_db.getCollection(N_UserMongoDB.allUsersCollection);
			// 查找是否存在
			DBCursor cursor = all_users_info.find(new BasicDBObject(N_UserMongoDB.all_users_info_name, name));
			if (cursor.hasNext()) {
				DBObject dbo = cursor.next();
				String existed_pwd = dbo.get(N_UserMongoDB.all_users_info_pwd).toString();
				if (existed_pwd.equals(pwd)) {
					user.setU_name(name);
					user.setU_password(pwd);
					user.setU_isConfirmed((Boolean) dbo.get(N_UserMongoDB.all_users_info_isConfirmed));
					user.setU_joinTime(dbo.get(N_UserMongoDB.all_users_info_joinTime).toString());
					user.setU_level((Integer) dbo.get(N_UserMongoDB.all_users_info_level));
					user.setU_mongoDB(dbo.get(N_UserMongoDB.all_users_info_mongoDB).toString());
					user.setU_role(dbo.get(N_UserMongoDB.all_users_info_role).toString());
					user.setU_otherInfo(dbo.get(N_UserMongoDB.all_users_info_otherInfo).toString());
					if(dbo.get(N_UserMongoDB.all_users_info_type)!=null)
						user.setType(dbo.get(N_UserMongoDB.all_users_info_type).toString());
					user.setNotNull(true);
				}
			}
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		//
		return user;
	}

	//
	// 获取所有用户 list
	public List<N_User> getAllUsersList() {
		List<N_User> allUsersList = new ArrayList<N_User>();
		//
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB all_users_db = mongo.getDB(N_UserMongoDB.allUsersMongoDB);
			DBCollection all_users_info = all_users_db
					.getCollection(N_UserMongoDB.allUsersCollection);
			// 查找所有用户
			DBCursor cursor = all_users_info.find();
			while (cursor.hasNext()) {
				DBObject dbo = cursor.next();
				N_User user = new N_User();
				user.setU_name(dbo.get(N_UserMongoDB.all_users_info_name)
						.toString());
				user.setU_password(dbo.get(N_UserMongoDB.all_users_info_pwd)
						.toString());
				user.setU_isConfirmed((Boolean) dbo.get(N_UserMongoDB.all_users_info_isConfirmed));
				user.setU_joinTime(dbo.get(N_UserMongoDB.all_users_info_joinTime).toString());
				user.setU_level((Integer) dbo.get(N_UserMongoDB.all_users_info_level));
				user.setU_mongoDB(dbo.get(N_UserMongoDB.all_users_info_mongoDB).toString());
				user.setU_role(dbo.get(N_UserMongoDB.all_users_info_role).toString());
				user.setU_otherInfo(dbo.get(N_UserMongoDB.all_users_info_otherInfo).toString());
				if(dbo.get(N_UserMongoDB.all_users_info_type)!=null)
					user.setType(dbo.get(N_UserMongoDB.all_users_info_type).toString());
				user.setNotNull(true);
				allUsersList.add(user);
				user.printUserInfo();
			}
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		//
		return allUsersList;
	}

	// 激活用户
	public boolean jihuoUser(String name, String pwd) {
		boolean result = false;
		//
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB all_users_db = mongo.getDB(N_UserMongoDB.allUsersMongoDB);
			DBCollection all_users_info = all_users_db.getCollection(N_UserMongoDB.allUsersCollection);
			// 查找是否存在
			DBCursor cursor = all_users_info.find(new BasicDBObject(
					N_UserMongoDB.all_users_info_name, name));
			if (cursor.hasNext()) {
				DBObject dbo = cursor.next();
				String existed_pwd = dbo.get(N_UserMongoDB.all_users_info_pwd)
						.toString();
				if (existed_pwd.equals(pwd)) {
					// update条件
					DBObject updateCondition = new BasicDBObject();
					updateCondition.put(N_UserMongoDB.all_users_info_name, name);
					// update对象
					DBObject updateDBO = new BasicDBObject();
					updateDBO.put(N_UserMongoDB.all_users_info_isConfirmed,true);
					updateDBO.put(N_UserMongoDB.all_users_info_mongoDB,
							N_Constants.USER_MONGODB_NAME_QIANZHUI + name
									+ N_Constants.USER_MONGODB_NAME_HOUZHUI);
					DBObject updateSetDBO = new BasicDBObject("$set", updateDBO);
					all_users_info.update(updateCondition, updateSetDBO);
					//
					// 建立用户数据库
					DB userDB = mongo
							.getDB(N_Constants.USER_MONGODB_NAME_QIANZHUI
									+ name
									+ N_Constants.USER_MONGODB_NAME_HOUZHUI);
					DBCollection userConfigC = userDB
							.getCollection(N_Constants.USER_CONFIG_COLLECTION);
					DBCollection userKeywordsC = userDB
							.getCollection(N_Constants.USER_KEYWORDS_COLLECTION);
					DBCollection userWeiboC = userDB
							.getCollection(N_Constants.USER_WEIBO_COLLECTION);
					DBCollection userBbsC = userDB
							.getCollection(N_Constants.USER_BBS_COLLECTION);
					DBCollection userNewsC = userDB
							.getCollection(N_Constants.USER_MENHUNEWS_COLLECTION);
					//
					DBCollection userTestC = userDB
							.getCollection(N_Constants.USER_TEST_COLLECTION);
					DBObject testDBO = new BasicDBObject();
					Calendar c = Calendar.getInstance();
					DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					String time = df.format(c.getTime());
					testDBO.put("jihuo", time);
					userTestC.save(testDBO);
					//
					result = true;
					System.out.println("---成功激活用户：" + name + "!!!");
				}
			}
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		//
		return result;
	}

	// 关闭用户
	public boolean guanbiUser(String name, String pwd) {
		boolean result = false;
		//
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB all_users_db = mongo.getDB(N_UserMongoDB.allUsersMongoDB);
			DBCollection all_users_info = all_users_db.getCollection(N_UserMongoDB.allUsersCollection);
			// 查找是否存在
			DBCursor cursor = all_users_info.find(new BasicDBObject(N_UserMongoDB.all_users_info_name, name));
			if (cursor.hasNext()) {
				DBObject dbo = cursor.next();
				String existed_pwd = dbo.get(N_UserMongoDB.all_users_info_pwd)
						.toString();
				if (existed_pwd.equals(pwd)) {
					// update条件
					DBObject updateCondition = new BasicDBObject();
					updateCondition
							.put(N_UserMongoDB.all_users_info_name, name);
					// update对象
					DBObject updateDBO = new BasicDBObject();
					updateDBO.put(N_UserMongoDB.all_users_info_isConfirmed,
							false);
					DBObject updateSetDBO = new BasicDBObject("$set", updateDBO);
					all_users_info.update(updateCondition, updateSetDBO);
					//
					// 建立用户数据库
					DB userDB = mongo
							.getDB(N_Constants.USER_MONGODB_NAME_QIANZHUI
									+ name
									+ N_Constants.USER_MONGODB_NAME_HOUZHUI);
					DBCollection userConfigC = userDB
							.getCollection(N_Constants.USER_CONFIG_COLLECTION);
					DBCollection userKeywordsC = userDB
							.getCollection(N_Constants.USER_KEYWORDS_COLLECTION);
					DBCollection userWeiboC = userDB
							.getCollection(N_Constants.USER_WEIBO_COLLECTION);
					DBCollection userBbsC = userDB
							.getCollection(N_Constants.USER_BBS_COLLECTION);
					DBCollection userGoogleNewsC = userDB
							.getCollection(N_Constants.USER_MENHUNEWS_COLLECTION);
					//
					DBCollection userTestC = userDB
							.getCollection(N_Constants.USER_TEST_COLLECTION);
					DBObject testDBO = new BasicDBObject();
					Calendar c = Calendar.getInstance();
					DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					String time = df.format(c.getTime());
					testDBO.put("guanbi", time);
					userTestC.save(testDBO);
					//
					result = true;
					System.out.println("---成功关闭用户：" + name + "!!!");
				}
			}
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		//
		return result;
	}
	
	public boolean changeUserType(String name, String pwd, String type){
		boolean result = false;
		//
		try {
			//
			Mongo mongo = new Mongo(N_MongoDB_Info.mongo_ip);
			DB all_users_db = mongo.getDB(N_UserMongoDB.allUsersMongoDB);
			DBCollection all_users_info = all_users_db
					.getCollection(N_UserMongoDB.allUsersCollection);
			// 查找是否存在
			DBCursor cursor = all_users_info.find(new BasicDBObject(N_UserMongoDB.all_users_info_name, name));
			if (cursor.hasNext()) {
				DBObject dbo = cursor.next();
				String existed_pwd = dbo.get(N_UserMongoDB.all_users_info_pwd).toString();
				if (existed_pwd.equals(pwd)) {
					// update条件
					DBObject updateCondition = new BasicDBObject();
					updateCondition.put(N_UserMongoDB.all_users_info_name, name);
					// update对象
					DBObject updateDBO = new BasicDBObject();
					updateDBO.put(N_UserMongoDB.all_users_info_type, type);
					
					DBObject updateSetDBO = new BasicDBObject("$set", updateDBO);
					all_users_info.update(updateCondition, updateSetDBO, true, false);
					//
					System.out.println("------Change User Type : "+name+" , "+type);
				}
			}
			mongo.close();
			//
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
		//
		return result;
	}

	//
	public static void main(String[] args) {
		N_UserOperation uo = new N_UserOperation();
		uo.registerNewUser("snas", "snas", N_Constants.USER_ROLE_ADMIN);
		// uo.registerNewUser("test", "test", N_Constants.USER_ROLE_USER);
		// uo.registerNewUser("tt", "tt", N_Constants.USER_ROLE_USER);
		// N_User u = uo.getUserAllInfo("snas", "snas");
		// u.printUserInfo();
		// uo.getAllUsersList();
		//uo.jihuoUser("snas", "snas");
	}
}
