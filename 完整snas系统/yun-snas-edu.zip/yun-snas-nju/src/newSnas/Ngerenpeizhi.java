package newSnas;

import java.io.Serializable;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.StringTokenizer;

import newBasic.N_Emailer_Info;
import newBasic.N_User;
import newBasic.N_KeywordsInfo;
import newConstants.N_CONFIG;
import newConstants.N_Constants;
import newMongoDB.N_UDBO_BanKuai_ShiJian_RenWu;
import newMongoDB.N_UserDBOperation;
import newMongoDB.N_UserOperation;

import org.apache.wicket.Session;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.markup.html.AjaxLink;
import org.apache.wicket.ajax.markup.html.form.AjaxButton;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.RadioChoice;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.markup.repeater.Item;
import org.apache.wicket.markup.repeater.data.GridView;
import org.apache.wicket.markup.repeater.data.IDataProvider;
import org.apache.wicket.model.IModel;
import org.apache.wicket.model.LoadableDetachableModel;
import org.apache.wicket.model.Model;
import org.apache.wicket.model.PropertyModel;
import org.apache.wicket.request.mapper.parameter.PageParameters;

public class Ngerenpeizhi extends WebPage {

	/**
	 * 
	 */
	private static final long serialVersionUID = 517735632480659085L;
	private Session mySession = super.getSession();
	private String info_keywords = "";

	public List<N_KeywordsInfo> keywordsInfoList = new ArrayList<N_KeywordsInfo>();
	public N_User currentUser = (N_User) mySession.getAttribute("currentUser");
	public String role = currentUser.getU_role();
	public boolean confirmed = currentUser.isU_isConfirmed(); // 是否被激活确认！

	public String updateInfo = "";
	public List<String> pastTimeList;
	//
	public int currentKeywordsNum = 0;
	public String userType = currentUser.getType();

	//
	private WebMarkupContainer gerenInfoContainer;
	//
	// 网址配置
	private WebMarkupContainer jkSJRContainer;
	public String shoujianrenInfo = "";

	private String pageTag;

	//
	public Ngerenpeizhi(PageParameters parameters) {
		System.out
				.println("------------------------ ENTER INTO 个人配置 ------------------------");
		// DATE
		Date currentDate = new Date();
		Locale loCn = new Locale("zh", "CN");
		String sDate = DateFormat.getDateInstance(DateFormat.FULL, loCn)
				.format(currentDate);
		Label dateLabel = new Label("date", sDate);
		this.add(dateLabel);
		// 导航
		this.add(new Label("userName", currentUser.getU_name()));
		this.add(new Link("loginOut") {

			@Override
			public void onClick() {
				mySession.removeAttribute("currentUser");
				setResponsePage(Nlogin.class);
			}
		});
		this.add(new Link("linkToJianKong") {

			@Override
			public void onClick() {
				setResponsePage(Nyuqingjiankong.class);
			}
		});
		this.add(new Link("linkToFenXi") {

			@Override
			public void onClick() {
				setResponsePage(Nyuqingfenxi.class);
			}
		});
		this.add(new Link("linkToBaoGao") {

			@Override
			public void onClick() {
				setResponsePage(Nyuqingbaogao.class);
			}
		});
		this.add(new Link("linkToPeiZhi") {

			@Override
			public void onClick() {
				setResponsePage(Ngerenpeizhi.class);
			}
		});
		//
		/*-------------左侧链接----------------------*/
		Link<String> turnToInfo = new Link<String>("turnToInfo") {
			private static final long serialVersionUID = -2708888485381288316L;

			@Override
			public void onClick() {
				PageParameters pp = new PageParameters();
				pp.add("tag", N_Constants.PAGE_TAG_GERENINFO);
				setResponsePage(Ngerenpeizhi.class, pp);
			}
		};
		this.add(turnToInfo);
		Link<String> turnToKeywords = new Link<String>("turnToKeywords") {
			private static final long serialVersionUID = -708947771872756980L;

			@Override
			public void onClick() {
				PageParameters pp = new PageParameters();
				pp.add("tag", N_Constants.PAGE_TAG_KEYWORDS);
				setResponsePage(Ngerenpeizhi.class, pp);
			}
		};
		this.add(turnToKeywords);
		Link<String> turnToShiyu = new Link<String>("turnToShiyu") {
			private static final long serialVersionUID = -572656956922139212L;

			@Override
			public void onClick() {
				PageParameters pp = new PageParameters();
				pp.add("tag", N_Constants.PAGE_TAG_SHIYU);
				setResponsePage(Ngerenpeizhi.class, pp);
			}
		};
		this.add(turnToShiyu);
		Link<String> turnToEmailer = new Link<String>("turnToEmailer") {

			@Override
			public void onClick() {
				PageParameters pp = new PageParameters();
				pp.add("tag", N_Constants.PAGE_TAG_SHOUJIANREN);
				setResponsePage(Ngerenpeizhi.class, pp);
			}
		};
		this.add(turnToEmailer);
		Link<String> turnToManage = new Link<String>("turnToManage") {
			private static final long serialVersionUID = -572656956922139212L;

			@Override
			public void onClick() {
				PageParameters pp = new PageParameters();
				pp.add("tag", N_Constants.PAGE_TAG_MANAGE);
				setResponsePage(Ngerenpeizhi.class, pp);
			}
		};
		this.add(turnToManage);
		if (role.equals(N_Constants.USER_ROLE_ADMIN) == false)
			turnToManage.setVisible(false);
		//
		// 获取page tag
		pageTag = parameters.get("tag").toString();
		/*------------------welcome container-------------------*/
		WebMarkupContainer welcomeContainer = new WebMarkupContainer(
				"welcomeContainer");
		if (pageTag == null) {
			welcomeContainer.setVisible(false);
			pageTag = N_Constants.PAGE_TAG_GERENINFO;
		} else
			welcomeContainer.setVisible(false);
		this.add(welcomeContainer);
		/*------------------end-------------------*/
		/*------------------container-------------------*/
		gerenInfoContainer = new WebMarkupContainer("gerenInfoContainer");
		gerenInfoContainer.setOutputMarkupId(true);
		// session current user

		Label geren_zhuangtai, geren_name, geren_pwd, geren_joinTime, geren_role, geren_type, geren_mongodb, geren_otherInfo;
		if (currentUser != null) {
			N_UserOperation nuo = new N_UserOperation();
			N_User cUser = nuo.getUserAllInfo(currentUser.getU_name(),
					currentUser.getU_password());
			boolean isConfirmed = cUser.isU_isConfirmed();
			if (isConfirmed)
				geren_zhuangtai = new Label("geren-zhuangtai",
						N_Constants.USER_ZHUANGTAI_JIHUO);
			else
				geren_zhuangtai = new Label("geren-zhuangtai",
						N_Constants.USER_ZHUANGTAI_JIHUO_NOT);
			//
			geren_name = new Label("geren-name", cUser.getU_name());
			geren_pwd = new Label("geren-pwd", cUser.getU_password());
			geren_joinTime = new Label("geren-joinTime", cUser.getU_joinTime());
			geren_role = new Label("geren-role", cUser.getU_role());
			geren_type = new Label("geren-type", cUser.getType());
			geren_mongodb = new Label("geren-mongodb", cUser.getU_mongoDB());
			geren_otherInfo = new Label("geren-otherInfo",
					cUser.getU_otherInfo());
			//
		} else {
			geren_zhuangtai = new Label("geren-zhuangtai", N_Constants.NULL);
			geren_name = new Label("geren-name", N_Constants.NULL);
			geren_pwd = new Label("geren-pwd", N_Constants.NULL);
			geren_joinTime = new Label("geren-joinTime", N_Constants.NULL);
			geren_role = new Label("geren-role", N_Constants.NULL);
			geren_type = new Label("geren-type", N_Constants.NULL);
			geren_mongodb = new Label("geren-mongodb", N_Constants.NULL);
			geren_otherInfo = new Label("geren-otherInfo", N_Constants.NULL);
		}
		gerenInfoContainer.add(geren_zhuangtai);
		gerenInfoContainer.add(geren_name);
		gerenInfoContainer.add(geren_pwd);
		gerenInfoContainer.add(geren_joinTime);
		gerenInfoContainer.add(geren_role);
		gerenInfoContainer.add(geren_type);
		gerenInfoContainer.add(geren_mongodb);
		gerenInfoContainer.add(geren_otherInfo);
		//
		if (pageTag != null && pageTag.equals(N_Constants.PAGE_TAG_GERENINFO))
			gerenInfoContainer.setVisible(true);
		else
			gerenInfoContainer.setVisible(false);
		this.add(gerenInfoContainer);
		/*-----------------------------------------------*/
		/* ===================================== */
		final WebMarkupContainer gerenShiyuContainer = new WebMarkupContainer(
				"gerenShiyuContainer");
		gerenShiyuContainer.setOutputMarkupId(true);
		//
		Form shiyuForm = new Form("shiyuForm");
		String past = N_CONFIG.USER_CONFIG_PAST_HOUR;
		if (currentUser != null && confirmed) {
			N_UserDBOperation nudbo = new N_UserDBOperation(
					currentUser.getU_mongoDB());
			past = nudbo.getUserPastTime();
		}
		String pastTime = "";
		if (past.equals("hour"))
			pastTime = N_Constants.pastTimeList.get(0);
		else if (past.equals("day"))
			pastTime = N_Constants.pastTimeList.get(1);
		else if (past.equals("week"))
			pastTime = N_Constants.pastTimeList.get(2);
		else if (past.equals("month"))
			pastTime = N_Constants.pastTimeList.get(3);
		else if (past.equals("null"))
			pastTime = N_Constants.pastTimeList.get(4);
		else
			pastTime = N_Constants.pastTimeList.get(0);
		final RadioChoice<String> updatePastTimeChoice = new RadioChoice<String>(
				"pastTimeChoice", new Model<String>(pastTime),
				new PropertyModel<List<String>>(this, "pastTimeList"));
		shiyuForm.add(updatePastTimeChoice);
		// 更新google实时
		AjaxButton updatePastTime = new AjaxButton("updatePastTime") {
			private static final long serialVersionUID = 7178354434574341225L;

			public void onSubmit(AjaxRequestTarget target, Form form) {
				System.out
						.println("=======AJAX Button Update Past Time=======");
				String pastTime = updatePastTimeChoice
						.getDefaultModelObjectAsString();
				System.out.println("update past time : " + pastTime);
				if (currentUser != null && confirmed) {
					N_UserDBOperation nudbo = new N_UserDBOperation(
							currentUser.getU_mongoDB());
					boolean update = false;
					if (pastTime.equals(N_Constants.pastTimeList.get(0)))
						update = nudbo
								.changeUserPastTime(N_CONFIG.USER_CONFIG_PAST_HOUR);
					else if (pastTime.equals(N_Constants.pastTimeList.get(1)))
						update = nudbo
								.changeUserPastTime(N_CONFIG.USER_CONFIG_PAST_DAY);
					else if (pastTime.equals(N_Constants.pastTimeList.get(2)))
						update = nudbo
								.changeUserPastTime(N_CONFIG.USER_CONFIG_PAST_WEEK);
					else if (pastTime.equals(N_Constants.pastTimeList.get(3)))
						update = nudbo
								.changeUserPastTime(N_CONFIG.USER_CONFIG_PAST_MONTH);
					else if (pastTime.equals(N_Constants.pastTimeList.get(4)))
						update = nudbo
								.changeUserPastTime(N_CONFIG.USER_CONFIG_PAST_NULL);
					if (update)
						updateInfo = "更新成功！";
					else
						updateInfo = "更新失败！";
				} else {
					updateInfo = "未激活账户！";
				}
				//
				target.add(gerenShiyuContainer);
			}
		};
		shiyuForm.add(updatePastTime);
		//
		Label updateInfo = new Label("updateInfo", new PropertyModel<String>(
				this, "updateInfo"));
		shiyuForm.add(updateInfo);
		gerenShiyuContainer.add(shiyuForm);
		//
		if (pageTag != null && pageTag.equals(N_Constants.PAGE_TAG_SHIYU))
			gerenShiyuContainer.setVisible(true);
		else
			gerenShiyuContainer.setVisible(false);
		this.add(gerenShiyuContainer);
		/* ===================================== */
		/*------------------keywords container-------------------*/
		final WebMarkupContainer gerenKeywordsContainer = new WebMarkupContainer(
				"gerenKeywordsContainer");
		gerenKeywordsContainer.setOutputMarkupId(true);
		//
		Form<String> keywordsForm = new Form<String>("keywordsForm");
		final TextField<String> newKeywordsTF = new TextField<String>(
				"newKeywordsTF", new Model<String>(""));
		keywordsForm.add(newKeywordsTF);
		AjaxButton addKeywordsBT = new AjaxButton("addKeywordsBT") {
			private static final long serialVersionUID = 7393032448176469874L;

			public void onSubmit(AjaxRequestTarget target, Form form) {
				System.out
						.println("============Ajax Button add keywords===========");
				String addKeywords = newKeywordsTF
						.getDefaultModelObjectAsString();
				StringTokenizer st = new StringTokenizer(addKeywords, " ");
				//
				int maxKeywordsNum = 0;
				if (userType.equals(N_Constants.USER_GUEST))
					maxKeywordsNum = N_Constants.USER_GUEST_KEYWORDS_NUM;
				else if (userType.equals(N_Constants.USER_VIP))
					maxKeywordsNum = N_Constants.USER_VIP_KEYWORDS_NUM;
				//
				if (currentUser != null && confirmed) {
					N_UserDBOperation nudbo = new N_UserDBOperation(
							currentUser.getU_mongoDB());
					while (st.hasMoreTokens()
							&& currentKeywordsNum < maxKeywordsNum) {
						String addKeyword = st.nextToken();
						if (addKeyword != null
								&& addKeyword.equals("") == false
								&& addKeyword.equals(" ") == false) {
							System.out.println("new keyword : " + addKeyword);
							boolean result = nudbo
									.addNewKeywordsToDB(addKeyword); // 个人数据库
							//
							if (result)
								info_keywords = "添加新的关键字成功！";
							else
								info_keywords = "添加新的关键字失败！";
							//
							maxKeywordsNum--;
						}
					}
				} else {
					info_keywords = "未激活账户！";
				}
				target.add(gerenKeywordsContainer);
			}
		};
		keywordsForm.add(addKeywordsBT);
		Label keywordsInfo = new Label("keywordsInfo",
				new PropertyModel<String>(this, "info_keywords"));
		keywordsForm.add(keywordsInfo);
		//
		// 关键字 列表
		this.getKeywordsInfoList();
		keywordsItemsDataProvider<N_KeywordsInfo> dataProvider = new keywordsItemsDataProvider<N_KeywordsInfo>(
				keywordsInfoList);
		final GridView<N_KeywordsInfo> keywordsGridView = new GridView<N_KeywordsInfo>(
				"rows_keywords", dataProvider) {

			/**
					 * 
					 */
			private static final long serialVersionUID = 6476435431864340599L;

			@Override
			protected void populateEmptyItem(Item<N_KeywordsInfo> item) {
				item.add(new Label("keywords_label", "").setVisible(false));
				item.add(new AjaxLink("keywords_delete") {
					@Override
					public void onClick(AjaxRequestTarget arg0) {
						// TODO Auto-generated method stub
					}
				}.setVisible(false));
				item.add(new Label("keywords_attentionlabel", "")
						.setVisible(false));
				item.add(new AjaxLink("keywords_attention") {

					@Override
					public void onClick(AjaxRequestTarget arg0) {
						// TODO Auto-generated method stub
					}
				}.setVisible(false));
				item.add(new AjaxLink("keywords_cancel") {

					@Override
					public void onClick(AjaxRequestTarget arg0) {
						// TODO Auto-generated method stub
					}
				}.setVisible(false));
			}

			@Override
			protected void populateItem(Item<N_KeywordsInfo> item) {
				final N_KeywordsInfo keywordInfo = item.getModelObject();
				final String deleteKeywords = keywordInfo.getKeywords();
				//
				item.add(new Label("keywords_label", deleteKeywords));
				item.add(new AjaxLink("keywords_delete") {

					@Override
					public void onClick(AjaxRequestTarget target) {
						if (currentUser != null && confirmed) {
							N_UserDBOperation nudbo = new N_UserDBOperation(
									currentUser.getU_mongoDB());
							boolean delete = nudbo
									.deleteExistedKeywords(deleteKeywords);
							if (delete)
								info_keywords = "删除关键字成功！";
							else
								info_keywords = "删除关键字失败！";
						} else {
							info_keywords = "未激活账户！";
						}

						target.add(gerenKeywordsContainer);
					}
				});
				//
				final boolean attention = keywordInfo.isAttention();
				Label attentionLabel;
				AjaxLink<String> attentionLink = new AjaxLink<String>(
						"keywords_attention") {

					/**
							 * 
							 */
					private static final long serialVersionUID = -3554548399004149953L;

					@Override
					public void onClick(AjaxRequestTarget target) {
						if (currentUser != null && confirmed) {
							N_UserDBOperation nudbo = new N_UserDBOperation(
									currentUser.getU_mongoDB());
							boolean modify = nudbo.modifyKeywordAttention(
									deleteKeywords, true);
							if (modify)
								info_keywords = "关注成功！";
							else
								info_keywords = "关注失败！";
						} else {
							info_keywords = "未激活账户！";
						}
						target.add(gerenKeywordsContainer);
					}
				};
				AjaxLink<String> cancelLink = new AjaxLink<String>(
						"keywords_cancel") {

					/**
							 * 
							 */
					private static final long serialVersionUID = -3554548399004149953L;

					@Override
					public void onClick(AjaxRequestTarget target) {
						if (currentUser != null && confirmed) {
							N_UserDBOperation nudbo = new N_UserDBOperation(
									currentUser.getU_mongoDB());
							boolean modify = nudbo.modifyKeywordAttention(
									deleteKeywords, false);
							if (modify)
								info_keywords = "取消关注成功！";
							else
								info_keywords = "取消关注失败！";
						} else {
							info_keywords = "未激活账户！";
						}
						target.add(gerenKeywordsContainer);
					}
				};
				if (attention) { // 已关注
					attentionLabel = new Label("keywords_attentionlabel", "已关注");
					attentionLink.setVisible(false);
					cancelLink.setVisible(true);
				} else { // 未关注
					attentionLabel = new Label("keywords_attentionlabel", "未关注");
					attentionLink.setVisible(true);
					cancelLink.setVisible(false);
				}
				item.add(attentionLabel);
				item.add(attentionLink);
				item.add(cancelLink);
				//
			}
		};
		keywordsGridView.setRows(1000); // set the rows max=1000
		keywordsGridView.setColumns(4); // set the cols
		keywordsGridView.setVisible(true); // 起始可见
		keywordsForm.add(keywordsGridView);
		//
		AjaxLink zhankai_keywords = new AjaxLink("zhankai_keywords") {
			private static final long serialVersionUID = 520541986198813075L;

			@Override
			public void onClick(AjaxRequestTarget arg0) {
				if (keywordsGridView.isVisible() == true)
					keywordsGridView.setVisible(false);
				else
					keywordsGridView.setVisible(true);
				arg0.add(gerenKeywordsContainer);
			}
		};
		keywordsForm.add(zhankai_keywords);
		//
		gerenKeywordsContainer.add(keywordsForm);
		//
		if (pageTag != null && pageTag.equals(N_Constants.PAGE_TAG_KEYWORDS))
			gerenKeywordsContainer.setVisible(true);
		else
			gerenKeywordsContainer.setVisible(false);
		this.add(gerenKeywordsContainer);
		/*-----------------------------------------------*/
		/*------------------container-------------------*/
		/*-----------------------------------------------*/
		/*-------------------------------收件人配置---------------------------------------*/
		jkSJRContainer = new WebMarkupContainer("jk-SJR-Container");
		jkSJRContainer.setOutputMarkupId(true);
		//
		Form<String> shoujianrenForm = new Form<String>("shoujianrenForm");
		// 添加新的版块
		final TextField<String> shoujianrenNameTF = new TextField<String>(
				"shoujianrenNameTF", new Model<String>(""));
		shoujianrenForm.add(shoujianrenNameTF);
		final TextField<String> shoujianrenEmailTF = new TextField<String>(
				"shoujianrenEmailTF", new Model<String>(""));
		shoujianrenForm.add(shoujianrenEmailTF);
		final TextField<String> shoujianrenExtraTF = new TextField<String>(
				"shoujianrenExtraTF", new Model<String>(""));
		shoujianrenForm.add(shoujianrenExtraTF);
		AjaxButton shoujianrenAddBT = new AjaxButton("shoujianrenAddButton") {

			public void onSubmit(AjaxRequestTarget target, Form form) {
				//
				System.out.println("------ Button : add new shoujianren!");
				N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
						currentUser.getU_mongoDB());
				String shoujianrenName = shoujianrenNameTF
						.getDefaultModelObjectAsString();
				String shoujianrenEmail = shoujianrenEmailTF
						.getDefaultModelObjectAsString();
				String shoujianrenExtra = shoujianrenExtraTF
						.getDefaultModelObjectAsString();
				boolean result = false;
				if (shoujianrenName != null
						&& shoujianrenName.equals("") == false
						&& shoujianrenEmail != null && shoujianrenExtra != null)
					result = nudbo.createNewShoujianren(shoujianrenName,
							shoujianrenEmail, shoujianrenExtra);
				if (result)
					shoujianrenInfo = "添加成功！";
				else
					shoujianrenInfo = "添加失败或者已存在！";
				target.add(jkSJRContainer);
			}
		};
		shoujianrenForm.add(shoujianrenAddBT);
		Label shoujianrenInfoLabel = new Label("shoujianrenInfo",
				new PropertyModel<String>(this, "shoujianrenInfo"));
		shoujianrenForm.add(shoujianrenInfoLabel);
		// 编辑已有的版块
		final LoadableDetachableModel<List<N_Emailer_Info>> existedshoujianrenList = new LoadableDetachableModel<List<N_Emailer_Info>>() {

			@Override
			protected List<N_Emailer_Info> load() {
				N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
						currentUser.getU_mongoDB());
				return nudbo.getAllShoujianrenList();
			}
		};
		final ListView<N_Emailer_Info> existedshoujianrenView = new ListView<N_Emailer_Info>(
				"existedshoujianrenList", existedshoujianrenList) {

			@Override
			protected void populateItem(ListItem<N_Emailer_Info> item) {
				final N_Emailer_Info shoujianren = item.getModelObject();
				item.add(new Label("shoujianrenName", shoujianren.getName()));
				item.add(new Label("shoujianrenEmail", shoujianren.getEmail()));
				item.add(new Label("shoujianrenExtra", shoujianren.getExtra()));
				// 删除版块 link
				AjaxButton wzDeleteBT = new AjaxButton("shoujianrenDelete") {

					@Override
					public void onSubmit(AjaxRequestTarget target, Form form) {
						System.out.println("------ DELETE shoujianren!");
						N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
								currentUser.getU_mongoDB());
						boolean result = nudbo.deleteShoujianren(shoujianren
								.getOid());
						if (result)
							shoujianrenInfo = "删除成功！";
						else
							shoujianrenInfo = "删除失败！";
						target.add(jkSJRContainer);
					}
				};
				item.add(wzDeleteBT);
			}
		};
		shoujianrenForm.add(existedshoujianrenView);
		// 更新版块信息 link
		AjaxLink zhankaishoujianrenLink = new AjaxLink("zhankai_shoujianren") {

			@Override
			public void onClick(AjaxRequestTarget target) {
				if (existedshoujianrenView.isVisible())
					existedshoujianrenView.setVisible(false);
				else
					existedshoujianrenView.setVisible(true);
				target.add(jkSJRContainer);
			}
		};
		shoujianrenForm.add(zhankaishoujianrenLink);
		jkSJRContainer.add(shoujianrenForm);
		//
		if (pageTag != null && confirmed == true
				&& pageTag.equals(N_Constants.PAGE_TAG_SHOUJIANREN))
			jkSJRContainer.setVisible(true);
		else
			jkSJRContainer.setVisible(false);
		this.add(jkSJRContainer);
		/*------------------quanxian container-------------------*/
		WebMarkupContainer gerenQuanxianContainer = new WebMarkupContainer(
				"quanxianContainer");
		gerenQuanxianContainer.setOutputMarkupId(true);

		// 管理员权限
		if (pageTag != null && pageTag.equals(N_Constants.PAGE_TAG_MANAGE)
				&& role.equals(N_Constants.USER_ROLE_ADMIN) == false)
			gerenQuanxianContainer.setVisible(true);
		else
			gerenQuanxianContainer.setVisible(false);
		this.add(gerenQuanxianContainer);
		/*-----------------------------------------------*/

		/*------------------manage container-------------------*/
		final WebMarkupContainer gerenManageContainer = new WebMarkupContainer(
				"gerenManageContainer");
		gerenManageContainer.setOutputMarkupId(true);
		//
		Form<String> userManageForm = new Form<String>("userManageForm");
		// 用户list
		final LoadableDetachableModel<List<N_User>> allUsersList = new LoadableDetachableModel<List<N_User>>() {
			private static final long serialVersionUID = 7984011470275138696L;

			@Override
			protected List<N_User> load() {
				N_UserOperation nuo = new N_UserOperation();
				return nuo.getAllUsersList();
			}
		};
		final ListView<N_User> allUsersListView = new ListView<N_User>(
				"allUsersList", allUsersList) {
			private static final long serialVersionUID = -6925639097139999197L;

			@Override
			protected void populateItem(ListItem<N_User> item) {
				if (allUsersList.getObject().isEmpty() == false) {
					final N_User user = item.getModelObject();
					item.add(new Label("user-name", user.getU_name()));
					item.add(new Label("user-pwd", user.getU_password()));
					item.add(new Label("user-role", user.getU_role()));
					item.add(new Label("user-joinTime", user.getU_joinTime()));
					item.add(new Label("user-mongodb", user.getU_mongoDB()));
					item.add(new Label("user-otherInfo", user.getU_otherInfo()));
					boolean isConfirmed = user.isU_isConfirmed();
					if (isConfirmed)
						item.add(new Label("user-zhuangtai",
								N_Constants.USER_ZHUANGTAI_JIHUO));
					else
						item.add(new Label("user-zhuangtai",
								N_Constants.USER_ZHUANGTAI_JIHUO_NOT));
					// 激活用户 link
					AjaxLink userJihuo = new AjaxLink("user-jihuo") {

						@Override
						public void onClick(AjaxRequestTarget target) {
							N_UserOperation nuo = new N_UserOperation();
							boolean result = nuo.jihuoUser(user.getU_name(),
									user.getU_password());
							info_keywords = "激活账户！";
							target.add(gerenManageContainer);
						}
					};
					// 关闭用户 link
					AjaxLink userGuanbi = new AjaxLink("user-guanbi") {

						@Override
						public void onClick(AjaxRequestTarget target) {
							N_UserOperation nuo = new N_UserOperation();
							boolean result = nuo.guanbiUser(user.getU_name(),
									user.getU_password());
							info_keywords = "关闭账户！";
							target.add(gerenManageContainer);
						}
					};
					//
					if (isConfirmed) {
						userJihuo.setVisible(false);
						userGuanbi.setVisible(true);
					} else {
						userJihuo.setVisible(true);
						userGuanbi.setVisible(false);
					}
					item.add(userGuanbi);
					item.add(userJihuo);
					//
					String uType = user.getType();
					if (uType.equals(N_Constants.USER_GUEST))
						item.add(new Label("user-type", N_Constants.USER_GUEST));
					else if (uType.equals(N_Constants.USER_VIP))
						item.add(new Label("user-type", N_Constants.USER_VIP));
					// guest用户 link
					AjaxLink userGuest = new AjaxLink("user-guest") {

						@Override
						public void onClick(AjaxRequestTarget target) {
							N_UserOperation nuo = new N_UserOperation();
							boolean result = nuo.changeUserType(
									user.getU_name(), user.getU_password(),
									N_Constants.USER_GUEST);
							info_keywords = "设置账户为GUEST类型！";
							target.add(gerenManageContainer);
						}
					};
					// vip用户 link
					AjaxLink userVip = new AjaxLink("user-vip") {

						@Override
						public void onClick(AjaxRequestTarget target) {
							N_UserOperation nuo = new N_UserOperation();
							boolean result = nuo.changeUserType(
									user.getU_name(), user.getU_password(),
									N_Constants.USER_VIP);
							info_keywords = "设置账户为VIP类型！";
							target.add(gerenManageContainer);
						}
					};
					//
					if (uType.equals(N_Constants.USER_GUEST)) {
						userGuest.setVisible(false);
						userVip.setVisible(true);
					} else if (uType.equals(N_Constants.USER_VIP)) {
						userGuest.setVisible(true);
						userVip.setVisible(false);
					}
					item.add(userGuest);
					item.add(userVip);
				}
			}
		};
		userManageForm.add(allUsersListView);
		gerenManageContainer.add(userManageForm);
		// 管理员权限
		if (pageTag != null && pageTag.equals(N_Constants.PAGE_TAG_MANAGE)
				&& role.equals(N_Constants.USER_ROLE_ADMIN))
			gerenManageContainer.setVisible(true);
		else {
			gerenManageContainer.setVisible(false);
		}
		this.add(gerenManageContainer);
		/*-----------------------------------------------*/
	}

	public String getInfo_keywords() {
		return info_keywords;
	}

	public void setInfo_keywords(String info_keywords) {
		this.info_keywords = info_keywords;
	}

	public String getUpdateInfo() {
		return updateInfo;
	}

	public void setUpdateInfo(String updateInfo) {
		this.updateInfo = updateInfo;
	}

	// past time list

	// 获取用户关键字列表
	public List<N_KeywordsInfo> getKeywordsInfoList() {
		if (currentUser != null && confirmed) {
			N_UserDBOperation nudbo = new N_UserDBOperation(
					currentUser.getU_mongoDB());
			keywordsInfoList = nudbo.getUserKeywordsList();
			currentKeywordsNum = keywordsInfoList.size();
		}
		return keywordsInfoList;
	}

	public List<String> getPastTimeList() {
		pastTimeList = N_Constants.pastTimeList;
		return pastTimeList;
	}

	public void setPastTimeList(List<String> pastTimeList) {
		this.pastTimeList = pastTimeList;
	}

	public void setKeywordsInfoList(List<N_KeywordsInfo> keywordsInfoList) {
		this.keywordsInfoList = keywordsInfoList;
	}

	//
	// 内部类 用于给gridview提供数据源
	public class keywordsItemsDataProvider<N_KeywordsInfo> implements
			IDataProvider<N_KeywordsInfo> {
		/**
		 * 
		 */
		/** reference to the list used as dataprovider for the dataview */
		private List<N_KeywordsInfo> list;

		/**
		 * Constructs an empty provider. Useful for lazy loading together with
		 * {@linkplain #getData()}
		 */
		public keywordsItemsDataProvider() {
			if (keywordsInfoList == null) {
				throw new IllegalArgumentException(
						"argument [list] cannot be null");
			}
			list = (List<N_KeywordsInfo>) keywordsInfoList;
			System.out.println("keywords list size is :  " + list.size());
		}

		/**
		 * 
		 * @param list
		 *            the list used as dataprovider for the dataview
		 */
		public keywordsItemsDataProvider(List<N_KeywordsInfo> list) {
			if (list == null) {
				throw new IllegalArgumentException(
						"argument [list] cannot be null");
			}
			this.list = list;
		}

		/**
		 * Subclass to lazy load the list
		 * 
		 * @return The list
		 */
		protected List<N_KeywordsInfo> getData() { // 获取数据源 根据docList动态变化
			Ngerenpeizhi.this.getKeywordsInfoList();
			list = (List<N_KeywordsInfo>) keywordsInfoList;
			return list;
		}

		@Override
		public Iterator<N_KeywordsInfo> iterator(final long first,
				final long count) {
			List<N_KeywordsInfo> list = getData();

			long toIndex = first + count;
			if (toIndex > list.size()) {
				toIndex = list.size();
			}
			return list.subList((int) first, (int) toIndex).listIterator();
		}

		/**
		 * @see IDataProvider#size()
		 */
		@Override
		public long size() {
			return getData().size();
		}

		/**
		 * @see IDataProvider#model(Object)
		 */
		@Override
		public IModel<N_KeywordsInfo> model(N_KeywordsInfo object) {
			return new Model((Serializable) object);
		}

		/**
		 * @see org.apache.wicket.model.IDetachable#detach()
		 */
		@Override
		public void detach() {
		}
	};
}
