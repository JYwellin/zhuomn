package newSnas;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.link.Link;

public class Nindex extends WebPage {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5653245812660909024L;

	public Nindex() {
		System.out
				.println("------------------------ ENTER INTO 首页 ------------------------");
		// DATE
		Date currentDate = new Date();
		Locale loCn = new Locale("zh", "CN");
		String sDate = DateFormat.getDateInstance(DateFormat.FULL, loCn)
				.format(currentDate);
		Label dateLabel = new Label("date", sDate);
		this.add(dateLabel);
		//
		this.add(new Link("linkToIndex-logo") {

			@Override
			public void onClick() {
				setResponsePage(Nindex.class);
			}
		});
		this.add(new Link("linkToLogin") {

			@Override
			public void onClick() {
				setResponsePage(Nlogin.class);
			}
		});
		this.add(new Link("linkToRegister") {

			@Override
			public void onClick() {
				setResponsePage(Nlogin.class);
			}
		});
		//
	}
}
