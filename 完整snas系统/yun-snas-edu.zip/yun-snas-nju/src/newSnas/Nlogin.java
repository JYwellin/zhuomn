package newSnas;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import newMongoDB.N_UserOperation;
import newBasic.N_User;
import newConstants.N_Constants;

import org.apache.wicket.Session;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.PasswordTextField;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.model.Model;

/*
 * 2014年8月15日15:12:06
 * 用户登录 注册
 * @niuliqiang
 */
public class Nlogin extends WebPage {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5831854973111765766L;
	private Session mySession = super.getSession();

	public Nlogin() {
		System.out
				.println("------------------------ ENTER INTO 登录 注册 ------------------------");
		// DATE
		Date currentDate = new Date();
		Locale loCn = new Locale("zh", "CN");
		String sDate = DateFormat.getDateInstance(DateFormat.FULL, loCn)
				.format(currentDate);
		Label dateLabel = new Label("date", sDate);
		this.add(dateLabel);
		//
		this.add(new Link("linkToIndex-logo") {

			@Override
			public void onClick() {
				setResponsePage(Nindex.class);
			}
		});
		this.add(new Link("linkToLogin") {

			@Override
			public void onClick() {
				setResponsePage(Nlogin.class);
			}
		});
		this.add(new Link("linkToRegister") {

			@Override
			public void onClick() {
				setResponsePage(Nlogin.class);
			}
		});
		//
		// -----------------*user login *------------------------------//
		final Form<String> userLoginForm = new Form<String>("userLoginForm");
		final TextField<String> userLoginName = new TextField<String>(
				"userLoginName", new Model<String>(""));
		final PasswordTextField userLoginPwd = new PasswordTextField(
				"userLoginPwd", new Model<String>(""));
		userLoginForm.add(userLoginName);
		userLoginForm.add(userLoginPwd);
		Button userLoginBT = new Button("userLoginBT") {
			private static final long serialVersionUID = 3297208493584479300L;

			public void onSubmit() {
				String uName = userLoginName.getDefaultModelObjectAsString();
				String uPwd = userLoginPwd.getDefaultModelObjectAsString();
				N_UserOperation nuo = new N_UserOperation();
				boolean existed = nuo.checkUserIsExisted(uName, uPwd);
				boolean login = nuo.checkUserLogin(uName);
				if (existed) { // 账户存在且未重复登录
					N_User currentU = nuo.getUserAllInfo(uName, uPwd);
					mySession.setAttribute("currentUser", currentU);
					mySession.setAttribute("role", N_Constants.USER_ROLE_USER);
					mySession.removeAttribute("loginError");
					nuo.changeUserLogin(uName, true);
					System.out
							.println("---user login successfully!!! " + uName);
					setResponsePage(Nyuqingjiankong.class);
				} else {
					mySession.setAttribute("loginError", "yes");
					System.out.println("---user login failed!!! " + uName);
				}

			}
		};
		userLoginForm.add(userLoginBT);
		this.add(userLoginForm);
		// --------------------------------------------------//
		// -----------------*admin login *------------------------------//
		/*
		 * final Form<String> adminLoginForm = new
		 * Form<String>("adminLoginForm"); final TextField<String>
		 * adminLoginName = new TextField<String>( "adminLoginName", new
		 * Model<String>("")); final PasswordTextField adminLoginPwd = new
		 * PasswordTextField( "adminLoginPwd", new Model<String>(""));
		 * adminLoginForm.add(adminLoginName);
		 * adminLoginForm.add(adminLoginPwd); Button adminLoginBT = new
		 * Button("adminLoginBT") { private static final long serialVersionUID =
		 * 3049288583704874732L;
		 * 
		 * public void onSubmit() { String uName =
		 * adminLoginName.getDefaultModelObjectAsString(); String uPwd =
		 * adminLoginPwd.getDefaultModelObjectAsString(); N_UserOperation nuo =
		 * new N_UserOperation(); boolean existed =
		 * nuo.checkUserIsExisted(uName, uPwd); boolean login =
		 * nuo.checkUserLogin(uName); if (existed) { N_User currentU =
		 * nuo.getUserAllInfo(uName, uPwd);
		 * mySession.setAttribute("currentUser", currentU);
		 * mySession.setAttribute("role", N_Constants.USER_ROLE_ADMIN);
		 * mySession.removeAttribute("loginError"); nuo.changeUserLogin(uName,
		 * true); System.out .println("---admin login successfully!!! " +
		 * uName); setResponsePage(Nyuqingjiankong.class); } else {
		 * mySession.setAttribute("loginError", "yes");
		 * System.out.println("---admin login failed!!! " + uName); }
		 * 
		 * } }; adminLoginForm.add(adminLoginBT); this.add(adminLoginForm);
		 */
		// --------------------------------------------------//
		// -----------------*user register *------------------------------//
		final Form<String> userRegForm = new Form<String>("userRegForm");
		final TextField<String> userRegName = new TextField<String>(
				"userRegName", new Model<String>(""));
		final TextField<String> userRegPwd = new TextField<String>(
				"userRegPwd", new Model<String>(""));
		userRegForm.add(userRegName);
		userRegForm.add(userRegPwd);
		Button userRegBT = new Button("userRegBT") {
			private static final long serialVersionUID = -7727483619427831178L;

			public void onSubmit() {
				String uName = userRegName.getDefaultModelObjectAsString();
				String uPwd = userRegPwd.getDefaultModelObjectAsString();
				N_UserOperation nuo = new N_UserOperation();
				boolean reg = false;
				if (uName != null && uName.length() > 0 && uPwd != null
						&& uPwd.length() > 0)
					reg = nuo.registerNewUser(uName, uPwd,
							N_Constants.USER_ROLE_USER);
				if (reg) {
					N_User currentU = nuo.getUserAllInfo(uName, uPwd);
					mySession.setAttribute("currentUser", currentU);
					mySession.setAttribute("role", N_Constants.USER_ROLE_REG);
					mySession.removeAttribute("loginError");
					nuo.changeUserLogin(uName, true);
					System.out.println("---user register successfully!!! "
							+ uName);
					setResponsePage(Ngerenpeizhi.class);
				} else {
					mySession.setAttribute("loginError", "yes");
					System.out.println("---user register failed!!! " + uName);
				}

			}
		};
		userRegForm.add(userRegBT);
		this.add(userRegForm);
		// --------------------------------------------------//
		Label infoLabel;
		if (mySession.getAttribute("loginError") != null) {
			infoLabel = new Label("loginInfo", "账户密码有错！");
			// mySession.removeAttribute("loginError");
		} else
			infoLabel = new Label("loginInfo", "未登录！");
		this.add(infoLabel);
		//
	}
}
