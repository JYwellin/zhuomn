package newSnas;

import org.apache.wicket.Page;
import org.apache.wicket.protocol.http.WebApplication;

public class NsnasApplication extends WebApplication {

	@Override
	public Class<? extends Page> getHomePage() {
		// TODO Auto-generated method stub
		return Nindex.class;
	}

}
