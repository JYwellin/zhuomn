package newSnas2;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import newBasic.N_User;
import newConstants.N_Constants;
import newDataSort.N_File_SortByName;

import org.apache.wicket.Session;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.markup.html.AjaxLink;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.link.DownloadLink;
import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.model.LoadableDetachableModel;

public class NewBaogao extends WebPage {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7230650720864078398L;
	private Session mySession = super.getSession();
	public N_User currentUser = (N_User) mySession.getAttribute("currentUser");
	public boolean confirmed = currentUser.isU_isConfirmed();
	//
	private WebMarkupContainer bgAllContainer;

	//
	private WebMarkupContainer bgRIBAOContainer;
	private LoadableDetachableModel<List<String>> ribaoLDM;
	//
	private WebMarkupContainer bgZHOUBAOContainer;
	private LoadableDetachableModel<List<String>> zhoubaoLDM;
	//
	private WebMarkupContainer bgYUEBAOContainer;
	private LoadableDetachableModel<List<String>> yuebaoLDM;
	//
	//
	private WebMarkupContainer bgJIBAOContainer;
	private LoadableDetachableModel<List<String>> jibaoLDM;
	//
	private WebMarkupContainer bgNIANBAOContainer;
	private LoadableDetachableModel<List<String>> nianbaoLDM;
	//
	private WebMarkupContainer bgZHUANBAOContainer;
	private LoadableDetachableModel<List<String>> zhuanbaoLDM;
	//
	//
	private String pageTag = N_Constants.PAGE_TAG_BG_RIBAO;

	public NewBaogao() {
		System.out
				.println("------------------------ ENTER INTO 舆情报告 ------------------------");
		// 导航
		this.add(new Label("userName", currentUser.getU_name()));
		this.add(new Link("loginOut") {

			@Override
			public void onClick() {
				mySession.removeAttribute("currentUser");
				setResponsePage(NewLogin.class);
			}
		});
		this.add(new Link("linkToJianKong") {

			@Override
			public void onClick() {
				setResponsePage(NewJiankong.class);
			}
		});
		this.add(new Link("linkToFenXi") {

			@Override
			public void onClick() {
				setResponsePage(NewFenxi.class);
			}
		});
		this.add(new Link("linkToBaoGao") {

			@Override
			public void onClick() {
				setResponsePage(NewBaogao.class);
			}
		});
		this.add(new Link("linkToPeiZhi") {

			@Override
			public void onClick() {
				setResponsePage(NewPeizhi.class);
			}
		});
		//
		bgAllContainer = new WebMarkupContainer("bg-all-container");
		bgAllContainer.setOutputMarkupId(true);

		AjaxLink<String> turnToRIBAO = new AjaxLink<String>("turnToRIBAO") {
			private static final long serialVersionUID = 1750101816437676244L;

			@Override
			public void onClick(AjaxRequestTarget target) {
				pageTag = N_Constants.PAGE_TAG_BG_RIBAO;
				bgRIBAOContainer.setVisible(true);
				bgZHOUBAOContainer.setVisible(false);
				bgYUEBAOContainer.setVisible(false);
				bgJIBAOContainer.setVisible(false);
				bgNIANBAOContainer.setVisible(false);
				bgZHUANBAOContainer.setVisible(false);
				target.add(bgAllContainer);
			}
		};
		bgAllContainer.add(turnToRIBAO);
		AjaxLink<String> turnToZHOUBAO = new AjaxLink<String>("turnToZHOUBAO") {

			@Override
			public void onClick(AjaxRequestTarget target) {
				pageTag = N_Constants.PAGE_TAG_BG_ZHOUBAO;
				bgRIBAOContainer.setVisible(false);
				bgZHOUBAOContainer.setVisible(true);
				bgYUEBAOContainer.setVisible(false);
				bgJIBAOContainer.setVisible(false);
				bgNIANBAOContainer.setVisible(false);
				bgZHUANBAOContainer.setVisible(false);
				target.add(bgAllContainer);
			}
		};
		bgAllContainer.add(turnToZHOUBAO);
		AjaxLink<String> turnToYUEBAO = new AjaxLink<String>("turnToYUEBAO") {

			@Override
			public void onClick(AjaxRequestTarget target) {
				pageTag = N_Constants.PAGE_TAG_BG_YUEBAO;
				bgRIBAOContainer.setVisible(false);
				bgZHOUBAOContainer.setVisible(false);
				bgYUEBAOContainer.setVisible(true);
				bgJIBAOContainer.setVisible(false);
				bgNIANBAOContainer.setVisible(false);
				bgZHUANBAOContainer.setVisible(false);
				target.add(bgAllContainer);
			}
		};
		bgAllContainer.add(turnToYUEBAO);
		AjaxLink<String> turnToJIBAO = new AjaxLink<String>("turnToJIBAO") {

			@Override
			public void onClick(AjaxRequestTarget target) {
				pageTag = N_Constants.PAGE_TAG_BG_JIBAO;
				bgRIBAOContainer.setVisible(false);
				bgZHOUBAOContainer.setVisible(false);
				bgYUEBAOContainer.setVisible(false);
				bgJIBAOContainer.setVisible(true);
				bgNIANBAOContainer.setVisible(false);
				bgZHUANBAOContainer.setVisible(false);
				target.add(bgAllContainer);
			}
		};
		bgAllContainer.add(turnToJIBAO);
		AjaxLink<String> turnToNIANBAO = new AjaxLink<String>("turnToNIANBAO") {

			@Override
			public void onClick(AjaxRequestTarget target) {
				pageTag = N_Constants.PAGE_TAG_BG_NIANBAO;
				bgRIBAOContainer.setVisible(false);
				bgZHOUBAOContainer.setVisible(false);
				bgYUEBAOContainer.setVisible(false);
				bgJIBAOContainer.setVisible(false);
				bgNIANBAOContainer.setVisible(true);
				bgZHUANBAOContainer.setVisible(false);
				target.add(bgAllContainer);
			}
		};
		bgAllContainer.add(turnToNIANBAO);
		AjaxLink<String> turnToZHUANBAO = new AjaxLink<String>("turnToZHUANBAO") {

			@Override
			public void onClick(AjaxRequestTarget target) {
				pageTag = N_Constants.PAGE_TAG_BG_ZHUANBAO;
				bgRIBAOContainer.setVisible(false);
				bgZHOUBAOContainer.setVisible(false);
				bgYUEBAOContainer.setVisible(false);
				bgJIBAOContainer.setVisible(false);
				bgNIANBAOContainer.setVisible(false);
				bgZHUANBAOContainer.setVisible(true);
				target.add(bgAllContainer);
			}
		};
		bgAllContainer.add(turnToZHUANBAO);

		// 日报
		bgRIBAOContainer = new WebMarkupContainer("bg-ribao-container");
		bgRIBAOContainer.setOutputMarkupId(true);
		//
		final String userName = currentUser.getU_name();
		String webPath = NewBaogao.class.getProtectionDomain()
				.getCodeSource().getLocation().getPath();
		if (webPath.indexOf("WEB-INF") > 0) {
			webPath = webPath.substring(0, webPath.indexOf("WEB-INF/classes"));
		}
		// System.out.println(webPath);
		//
		final File ribaoFile = new File(webPath + "report//" + userName + "//"
				+ "day");
		final List<String> ribaoFilesList = new ArrayList<String>();
		ribaoLDM = new LoadableDetachableModel<List<String>>() {

			@Override
			protected List<String> load() {
				// TODO Auto-generated method stub
				ribaoFilesList.clear();
				if (ribaoFile.isDirectory()) {
					File[] ribaofiles = ribaoFile.listFiles();
					String max = "";
					String lastMax = "zzzzzzzzzzzzzzzzzzzzzzzzzzzz";
					int maxIndex = 0;
					for (int i = 0; i < ribaofiles.length; i++) {
						max = "";
						for(int j=0; j< ribaofiles.length; j++){
							if(ribaofiles[j].toString().compareTo(max) > 0 && ribaofiles[j].toString().compareTo(lastMax) < 0){
								max = ribaofiles[j].toString();
								maxIndex = j;
							}
						}
						lastMax = ribaofiles[maxIndex].toString();
						ribaoFilesList.add(ribaofiles[maxIndex].getAbsolutePath());
					}
				}
				//N_File_SortByName fs= new N_File_SortByName();
				//fs.sortDataListByQuickSort(ribaoFilesList, 0, ribaoFilesList.size()-1);
				System.out.println("sorted files: "+ribaoFilesList);
				return ribaoFilesList;
			}

		};
		ListView<String> ribaoListView = new ListView<String>("bg-ribao-list",
				ribaoLDM) {

			@Override
			protected void populateItem(ListItem<String> item) {
				// TODO Auto-generated method stub
				String filePath = item.getDefaultModelObjectAsString();
				File file = new File(filePath);
				String fileName = file.getName();
				item.add(new Label("ribao-name", fileName));
				DownloadLink downloadribao = new DownloadLink(
						"download-ribao-link", file);
				item.add(downloadribao);
			}
		};
		bgRIBAOContainer.add(ribaoListView);
		//
		if (pageTag != null && pageTag.equals(N_Constants.PAGE_TAG_BG_RIBAO)
				&& confirmed) {
			bgRIBAOContainer.setVisible(true);
		} else
			bgRIBAOContainer.setVisible(false);
		bgAllContainer.add(bgRIBAOContainer);
		//
		// 周报
		bgZHOUBAOContainer = new WebMarkupContainer("bg-zhoubao-container");
		bgZHOUBAOContainer.setOutputMarkupId(true);
		//
		final File zhoubaoFile = new File(webPath + "report//" + userName
				+ "//" + "week");
		final List<String> zhoubaoFilesList = new ArrayList<String>();
		zhoubaoLDM = new LoadableDetachableModel<List<String>>() {

			@Override
			protected List<String> load() {
				// TODO Auto-generated method stub
				zhoubaoFilesList.clear();
				if (zhoubaoFile.isDirectory()) {
					File[] zhoubaofiles = zhoubaoFile.listFiles();
					String max = "";
					String lastMax = "zzzzzzzzzzzzzzzzzzzzzzzzzzzz";
					int maxIndex = 0;
					for (int i = 0; i < zhoubaofiles.length; i++) {
						max = "";
						for(int j=0; j< zhoubaofiles.length; j++){
							if(zhoubaofiles[j].toString().compareTo(max) > 0 && zhoubaofiles[j].toString().compareTo(lastMax) < 0){
								max = zhoubaofiles[j].toString();
								maxIndex = j;
							}
						}
						lastMax = zhoubaofiles[maxIndex].toString();
						zhoubaoFilesList.add(zhoubaofiles[maxIndex].getAbsolutePath());
					}
				}
				//N_File_SortByName fs= new N_File_SortByName();
				//fs.sortDataListByQuickSort(zhoubaoFilesList, 0, zhoubaoFilesList.size()-1);
				System.out.println("sorted files: "+zhoubaoFilesList);
				return zhoubaoFilesList;
			}

		};
		ListView<String> zhoubaoListView = new ListView<String>(
				"bg-zhoubao-list", zhoubaoLDM) {

			@Override
			protected void populateItem(ListItem<String> item) {
				// TODO Auto-generated method stub
				String filePath = item.getDefaultModelObjectAsString();
				File file = new File(filePath);
				String fileName = file.getName();
				item.add(new Label("zhoubao-name", fileName));
				DownloadLink downloadzhoubao = new DownloadLink(
						"download-zhoubao-link", file);
				item.add(downloadzhoubao);
			}
		};
		bgZHOUBAOContainer.add(zhoubaoListView);
		//
		if (pageTag != null && pageTag.equals(N_Constants.PAGE_TAG_BG_ZHOUBAO)
				&& confirmed) {
			bgZHOUBAOContainer.setVisible(true);
		} else
			bgZHOUBAOContainer.setVisible(false);
		bgAllContainer.add(bgZHOUBAOContainer);
		//
		// 月报
		bgYUEBAOContainer = new WebMarkupContainer("bg-yuebao-container");
		bgYUEBAOContainer.setOutputMarkupId(true);
		//
		final File yuebaoFile = new File(webPath + "report//" + userName + "//"
				+ "month");
		final List<String> yuebaoFilesList = new ArrayList<String>();
		yuebaoLDM = new LoadableDetachableModel<List<String>>() {

			@Override
			protected List<String> load() {
				// TODO Auto-generated method stub
				yuebaoFilesList.clear();
				if (yuebaoFile.isDirectory()) {
					File[] yuebaofiles = yuebaoFile.listFiles();
					String max = "";
					String lastMax = "zzzzzzzzzzzzzzzzzzzzzzzzzzzz";
					int maxIndex = 0;
					for (int i = 0; i < yuebaofiles.length; i++) {
						max = "";
						for(int j=0; j< yuebaofiles.length; j++){
							if(yuebaofiles[j].toString().compareTo(max) > 0 && yuebaofiles[j].toString().compareTo(lastMax) < 0){
								max = yuebaofiles[j].toString();
								maxIndex = j;
							}
						}
						lastMax = yuebaofiles[maxIndex].toString();
						yuebaoFilesList.add(yuebaofiles[maxIndex].getAbsolutePath());
					}
				}
				//N_File_SortByName fs= new N_File_SortByName();
				//fs.sortDataListByQuickSort(yuebaoFilesList, 0, yuebaoFilesList.size()-1);
				System.out.println("sorted files: "+yuebaoFilesList);
				return yuebaoFilesList;
			}

		};
		ListView<String> yuebaoListView = new ListView<String>(
				"bg-yuebao-list", yuebaoLDM) {

			@Override
			protected void populateItem(ListItem<String> item) {
				// TODO Auto-generated method stub
				String filePath = item.getDefaultModelObjectAsString();
				File file = new File(filePath);
				String fileName = file.getName();
				item.add(new Label("yuebao-name", fileName));
				DownloadLink downloadyuebao = new DownloadLink(
						"download-yuebao-link", file);
				item.add(downloadyuebao);
			}
		};
		bgYUEBAOContainer.add(yuebaoListView);
		//
		if (pageTag != null && pageTag.equals(N_Constants.PAGE_TAG_BG_YUEBAO)
				&& confirmed) {
			bgYUEBAOContainer.setVisible(true);
		} else
			bgYUEBAOContainer.setVisible(false);
		bgAllContainer.add(bgYUEBAOContainer);
		//
		// 季报
		bgJIBAOContainer = new WebMarkupContainer("bg-jibao-container");
		bgJIBAOContainer.setOutputMarkupId(true);
		//
		final File jibaoFile = new File(webPath + "report//" + userName + "//"
				+ "quarter");
		final List<String> jibaoFilesList = new ArrayList<String>();
		jibaoLDM = new LoadableDetachableModel<List<String>>() {

			@Override
			protected List<String> load() {
				// TODO Auto-generated method stub
				jibaoFilesList.clear();
				if (jibaoFile.isDirectory()) {
					File[] jibaofiles = jibaoFile.listFiles();
					String max = "";
					String lastMax = "zzzzzzzzzzzzzzzzzzzzzzzzzzzz";
					int maxIndex = 0;
					for (int i = 0; i < jibaofiles.length; i++) {
						max = "";
						for(int j=0; j< jibaofiles.length; j++){
							if(jibaofiles[j].toString().compareTo(max) > 0 && jibaofiles[j].toString().compareTo(lastMax) < 0){
								max = jibaofiles[j].toString();
								maxIndex = j;
							}
						}
						lastMax = jibaofiles[maxIndex].toString();
						jibaoFilesList.add(jibaofiles[maxIndex].getAbsolutePath());
					}
				}
				//N_File_SortByName fs= new N_File_SortByName();
				//fs.sortDataListByQuickSort(jibaoFilesList, 0, jibaoFilesList.size()-1);
				System.out.println("sorted files: "+jibaoFilesList);
				return jibaoFilesList;
			}

		};
		ListView<String> jibaoListView = new ListView<String>("bg-jibao-list",
				jibaoLDM) {

			@Override
			protected void populateItem(ListItem<String> item) {
				// TODO Auto-generated method stub
				String filePath = item.getDefaultModelObjectAsString();
				File file = new File(filePath);
				String fileName = file.getName();
				item.add(new Label("jibao-name", fileName));
				DownloadLink downloadjibao = new DownloadLink(
						"download-jibao-link", file);
				item.add(downloadjibao);
			}
		};
		bgJIBAOContainer.add(jibaoListView);
		//
		if (pageTag != null && pageTag.equals(N_Constants.PAGE_TAG_BG_JIBAO)
				&& confirmed) {
			bgJIBAOContainer.setVisible(true);
		} else
			bgJIBAOContainer.setVisible(false);
		bgAllContainer.add(bgJIBAOContainer);
		//
		// 年报
		bgNIANBAOContainer = new WebMarkupContainer("bg-nianbao-container");
		bgNIANBAOContainer.setOutputMarkupId(true);
		//
		final File nianbaoFile = new File(webPath + "report//" + userName
				+ "//" + "year");
		final List<String> nianbaoFilesList = new ArrayList<String>();
		nianbaoLDM = new LoadableDetachableModel<List<String>>() {

			@Override
			protected List<String> load() {
				// TODO Auto-generated method stub
				nianbaoFilesList.clear();
				if (nianbaoFile.isDirectory()) {
					File[] nianbaofiles = nianbaoFile.listFiles();
					String max = "";
					String lastMax = "zzzzzzzzzzzzzzzzzzzzzzzzzzzz";
					int maxIndex = 0;
					for (int i = 0; i < nianbaofiles.length; i++) {
						max = "";
						for(int j=0; j< nianbaofiles.length; j++){
							if(nianbaofiles[j].toString().compareTo(max) > 0 && nianbaofiles[j].toString().compareTo(lastMax) < 0){
								max = nianbaofiles[j].toString();
								maxIndex = j;
							}
						}
						lastMax = nianbaofiles[maxIndex].toString();
						nianbaoFilesList.add(nianbaofiles[maxIndex].getAbsolutePath());
					}
				}
				//N_File_SortByName fs= new N_File_SortByName();
				//fs.sortDataListByQuickSort(nianbaoFilesList, 0, nianbaoFilesList.size()-1);
				System.out.println("sorted files: "+nianbaoFilesList);
				return nianbaoFilesList;
			}

		};
		ListView<String> nianbaoListView = new ListView<String>(
				"bg-nianbao-list", nianbaoLDM) {

			@Override
			protected void populateItem(ListItem<String> item) {
				// TODO Auto-generated method stub
				String filePath = item.getDefaultModelObjectAsString();
				File file = new File(filePath);
				String fileName = file.getName();
				item.add(new Label("nianbao-name", fileName));
				DownloadLink downloadnianbao = new DownloadLink(
						"download-nianbao-link", file);
				item.add(downloadnianbao);
			}
		};
		bgNIANBAOContainer.add(nianbaoListView);
		//
		if (pageTag != null && pageTag.equals(N_Constants.PAGE_TAG_BG_NIANBAO)
				&& confirmed) {
			bgNIANBAOContainer.setVisible(true);
		} else
			bgNIANBAOContainer.setVisible(false);
		bgAllContainer.add(bgNIANBAOContainer);
		//
		// 专报
		bgZHUANBAOContainer = new WebMarkupContainer("bg-zhuanbao-container");
		bgZHUANBAOContainer.setOutputMarkupId(true);
		//
		final File zhuanbaoFile = new File(webPath + "report//" + userName
				+ "//" + "zhuan");
		final List<String> zhuanbaoFilesList = new ArrayList<String>();
		zhuanbaoLDM = new LoadableDetachableModel<List<String>>() {

			@Override
			protected List<String> load() {
				// TODO Auto-generated method stub
				zhuanbaoFilesList.clear();
				if (zhuanbaoFile.isDirectory()) {
					File[] zhuanbaofiles = zhuanbaoFile.listFiles();
					String max = "";
					String lastMax = "zzzzzzzzzzzzzzzzzzzzzzzzzzzz";
					int maxIndex = 0;
					for (int i = 0; i < zhuanbaofiles.length; i++) {
						max = "";
						for(int j=0; j< zhuanbaofiles.length; j++){
							if(zhuanbaofiles[j].toString().compareTo(max) > 0 && zhuanbaofiles[j].toString().compareTo(lastMax) < 0){
								max = zhuanbaofiles[j].toString();
								maxIndex = j;
							}
						}
						lastMax = zhuanbaofiles[maxIndex].toString();
						zhuanbaoFilesList.add(zhuanbaofiles[maxIndex].getAbsolutePath());
					}
				}
				//N_File_SortByName fs= new N_File_SortByName();
				//fs.sortDataListByQuickSort(zhuanbaoFilesList, 0, zhuanbaoFilesList.size()-1);
				System.out.println("sorted files: "+zhuanbaoFilesList);
				return zhuanbaoFilesList;
			}

		};
		ListView<String> zhuanbaoListView = new ListView<String>(
				"bg-zhuanbao-list", zhuanbaoLDM) {

			@Override
			protected void populateItem(ListItem<String> item) {
				// TODO Auto-generated method stub
				String filePath = item.getDefaultModelObjectAsString();
				File file = new File(filePath);
				String fileName = file.getName();
				item.add(new Label("zhuanbao-name", fileName));
				DownloadLink downloadzhuanbao = new DownloadLink(
						"download-zhuanbao-link", file);
				item.add(downloadzhuanbao);
			}
		};
		bgZHUANBAOContainer.add(zhuanbaoListView);
		//
		if (pageTag != null && pageTag.equals(N_Constants.PAGE_TAG_BG_ZHUANBAO)
				&& confirmed) {
			bgZHUANBAOContainer.setVisible(true);
		} else
			bgZHUANBAOContainer.setVisible(false);
		bgAllContainer.add(bgZHUANBAOContainer);

		//
		this.add(bgAllContainer);
	}
}
