package newSnas2;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import newBasic.N_Bankuai_Shijian_Renwu_Info;
import newBasic.N_Emailer_Info;
import newBasic.N_User;
import newConstants.N_Constants;
import newMongoDB.N_UDBO_BanKuai_ShiJian_RenWu;
import newTools.SendEmail_163;

import org.apache.wicket.Session;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.markup.html.AjaxLink;
import org.apache.wicket.ajax.markup.html.form.AjaxButton;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.DropDownChoice;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.TextArea;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.link.ExternalLink;
import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.model.LoadableDetachableModel;
import org.apache.wicket.model.Model;
import org.apache.wicket.model.PropertyModel;
import org.apache.wicket.request.mapper.parameter.PageParameters;

public class NewFenxi extends WebPage {

	/**
	 * 
	 */
	private static final long serialVersionUID = -359657032659572232L;
	private Session mySession = super.getSession();
	public N_User currentUser = (N_User) mySession.getAttribute("currentUser");
	public boolean confirmed = currentUser.isU_isConfirmed(); // 是否被激活确认！
	//
	private WebMarkupContainer tag1Container;

	private WebMarkupContainer tag2Container;

	private WebMarkupContainer tag3Container;

	private WebMarkupContainer tag4Container;

	private WebMarkupContainer fxQBTJContainer;

	private WebMarkupContainer fxQBCLContainer;
	private WebMarkupContainer emailContainer;
	private LoadableDetachableModel<List<N_Bankuai_Shijian_Renwu_Info>> attentionLDM;
	private List<String> emailReceiverList;
	private String emailInfo = "";
	//
	private String pageTag;

	public NewFenxi(PageParameters parameters) {

		System.out
				.println("------------------------ ENTER INTO 舆情分析 ------------------------");
		// DATE
		Date currentDate = new Date();
		Locale loCn = new Locale("zh", "CN");
		String sDate = DateFormat.getDateInstance(DateFormat.FULL, loCn)
				.format(currentDate);
		Label dateLabel = new Label("date", sDate);
		this.add(dateLabel);
		// 导航
		this.add(new Label("userName", currentUser.getU_name()));
		this.add(new Link("loginOut") {

			@Override
			public void onClick() {
				mySession.removeAttribute("currentUser");
				setResponsePage(NewLogin.class);
			}
		});
		this.add(new Link("linkToJianKong") {

			@Override
			public void onClick() {
				setResponsePage(NewJiankong.class);
			}
		});
		this.add(new Link("linkToFenXi") {

			@Override
			public void onClick() {
				setResponsePage(NewFenxi.class);
			}
		});
		this.add(new Link("linkToBaoGao") {

			@Override
			public void onClick() {
				setResponsePage(NewBaogao.class);
			}
		});
		this.add(new Link("linkToPeiZhi") {

			@Override
			public void onClick() {
				setResponsePage(NewPeizhi.class);
			}
		});
		/*-------------左侧链接----------------------*/
		Link<String> turnToTag1 = new Link<String>("turnToTag1") {

			@Override
			public void onClick() {
				System.out.println("------turn to tag1");
				PageParameters pp = new PageParameters();
				pp.add("tag", N_Constants.PAGE_TAG_FX_TAG1);
				setResponsePage(NewFenxi.class, pp);
			}
		};
		this.add(turnToTag1);
		Link<String> turnToTag2 = new Link<String>("turnToTag2") {

			@Override
			public void onClick() {
				System.out.println("------turn to tag2");
				PageParameters pp = new PageParameters();
				pp.add("tag", N_Constants.PAGE_TAG_FX_TAG2);
				setResponsePage(NewFenxi.class, pp);
			}
		};
		this.add(turnToTag2);
		Link<String> turnToTag3 = new Link<String>("turnToTag3") {

			@Override
			public void onClick() {
				System.out.println("------turn to tag3");
				PageParameters pp = new PageParameters();
				pp.add("tag", N_Constants.PAGE_TAG_FX_TAG3);
				setResponsePage(NewFenxi.class, pp);
			}
		};
		this.add(turnToTag3);
		Link<String> turnToTag4 = new Link<String>("turnToTag4") {

			@Override
			public void onClick() {
				System.out.println("------turn to tag4");
				PageParameters pp = new PageParameters();
				pp.add("tag", N_Constants.PAGE_TAG_FX_TAG4);
				setResponsePage(NewFenxi.class, pp);
			}
		};
		this.add(turnToTag4);
		Link<String> turnToQBTJ = new Link<String>("turnToQBTJ") {
			private static final long serialVersionUID = -952085189998090138L;

			@Override
			public void onClick() {
				System.out.println("------turn to 情报统计!");
				PageParameters pp = new PageParameters();
				pp.add("tag", N_Constants.PAGE_TAG_FX_QBTJ);
				setResponsePage(NewFenxi.class, pp);
			}
		};
		this.add(turnToQBTJ);
		Link<String> turnToQBCL = new Link<String>("turnToQBCL") {
			private static final long serialVersionUID = 6426580044713828462L;

			@Override
			public void onClick() {
				System.out.println("------turn to 情报处理!");
				PageParameters pp = new PageParameters();
				pp.add("tag", N_Constants.PAGE_TAG_FX_QBCL);
				setResponsePage(NewFenxi.class, pp);
			}
		};
		this.add(turnToQBCL);
		//
		// 获取page tag
		pageTag = parameters.get("tag").toString();
		/*------------------JK welcome container-------------------*/
		WebMarkupContainer welcomeContainer = new WebMarkupContainer(
				"fenxi-welcome-Container");
		if (pageTag == null) {
			welcomeContainer.setVisible(false);
			pageTag = N_Constants.PAGE_TAG_FX_TAG1;
		} else
			welcomeContainer.setVisible(false);
		this.add(welcomeContainer);
		//
		// ///////////////////////////////////////////////////////////////////
		tag1Container = new WebMarkupContainer("fenxi-tag1");
		if (pageTag != null && pageTag.equals(N_Constants.PAGE_TAG_FX_TAG1))
			tag1Container.setVisible(true);
		else
			tag1Container.setVisible(false);
		this.add(tag1Container);
		// ///////////////////////////////////////////////////////////////////
		tag2Container = new WebMarkupContainer("fenxi-tag2");
		if (pageTag != null && pageTag.equals(N_Constants.PAGE_TAG_FX_TAG2))
			tag2Container.setVisible(true);
		else
			tag2Container.setVisible(false);
		this.add(tag2Container);
		// ///////////////////////////////////////////////////////////////////
		tag3Container = new WebMarkupContainer("fenxi-tag3");
		if (pageTag != null && pageTag.equals(N_Constants.PAGE_TAG_FX_TAG3))
			tag3Container.setVisible(true);
		else
			tag3Container.setVisible(false);
		this.add(tag3Container);
		// ///////////////////////////////////////////////////////////////////
		tag4Container = new WebMarkupContainer("fenxi-tag4");
		if (pageTag != null && pageTag.equals(N_Constants.PAGE_TAG_FX_TAG4))
			tag4Container.setVisible(true);
		else
			tag4Container.setVisible(false);
		this.add(tag4Container);
		/*---------------------------情报统计----------------------------------*/
		fxQBTJContainer = new WebMarkupContainer("fenxi-QBTJ-Container");
		if (pageTag != null && pageTag.equals(N_Constants.PAGE_TAG_FX_QBTJ))
			fxQBTJContainer.setVisible(true);
		else
			fxQBTJContainer.setVisible(false);
		this.add(fxQBTJContainer);
		/*--------------------------------情报处理-----------------------------*/
		fxQBCLContainer = new WebMarkupContainer("fenxi-QBCL-Container");
		fxQBCLContainer.setOutputMarkupId(true);
		//
		Form<String> fxQBCLForm = new Form<String>("fx-QBCL-form");
		// 发送邮件模块
		AjaxLink zhankaiEmailLink = new AjaxLink("zhankai_email") {

			@Override
			public void onClick(AjaxRequestTarget target) {
				if (emailContainer.isVisible())
					emailContainer.setVisible(false);
				else
					emailContainer.setVisible(true);
				target.add(fxQBCLContainer);
			}
		};
		fxQBCLForm.add(zhankaiEmailLink);
		emailContainer = new WebMarkupContainer("email-container");
		emailContainer.setVisible(false);
		emailContainer.setOutputMarkupId(true);
		// select receiver
		N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
				currentUser.getU_mongoDB());
		final DropDownChoice receiverChoice = new DropDownChoice(
				"email-receiver", new Model<String>("选择已有收件人"),
				new PropertyModel<List<String>>(this, "emailReceiverList"));
		receiverChoice.setRequired(true);
		receiverChoice.setNullValid(false);
		emailContainer.add(receiverChoice);
		// subject
		final TextField emailSubjectTF = new TextField("email-subject",
				new Model(""));
		emailContainer.add(emailSubjectTF);

		// content
		final TextArea emailContentTA = new TextArea("email-content",
				new Model(""));
		emailContainer.add(emailContentTA);
		// submit
		AjaxButton emailSendBT = new AjaxButton("email-send") {
			public void onSubmit(AjaxRequestTarget target, Form form) {
				String receiverStr = receiverChoice
						.getDefaultModelObjectAsString();
				String address = receiverStr.substring(
						receiverStr.indexOf("[") + 1, receiverStr.indexOf("]"));
				String subject = emailSubjectTF.getDefaultModelObjectAsString();
				String content = emailContentTA.getDefaultModelObjectAsString();
				System.out.println("------Send Email Info : [" + address + ", "
						+ subject + ", " + content + "]");
				if (address != null && subject != null && content != null) {
					SendEmail_163 se163 = new SendEmail_163();
					se163.SendEmail(address, subject, content);
					emailInfo = "发送邮件成功！";
				} else
					emailInfo = "发送邮件失败！";
				target.add(fxQBCLContainer);
			}
		};
		emailContainer.add(emailSendBT);
		Label emailInfoLabel = new Label("emailInfo",
				new PropertyModel<String>(this, "emailInfo"));
		emailContainer.add(emailInfoLabel);
		fxQBCLForm.add(emailContainer);
		// 未处理数据模块
		attentionLDM = new LoadableDetachableModel<List<N_Bankuai_Shijian_Renwu_Info>>() {
			private static final long serialVersionUID = 7203990854569827415L;

			@Override
			protected List<N_Bankuai_Shijian_Renwu_Info> load() {
				N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
						currentUser.getU_mongoDB());
				if (currentUser != null && confirmed && pageTag != null
						&& pageTag.equals(N_Constants.PAGE_TAG_FX_QBCL))
					return nudbo.getAllUndealedData();
				else
					return null;
			}
		};
		ListView<N_Bankuai_Shijian_Renwu_Info> attentionDataListView = new ListView<N_Bankuai_Shijian_Renwu_Info>(
				"attentionDataList", attentionLDM) {

			@Override
			protected void populateItem(
					ListItem<N_Bankuai_Shijian_Renwu_Info> item) {
				final N_Bankuai_Shijian_Renwu_Info nbsri = item
						.getModelObject();
				item.add(new ExternalLink("data-title", nbsri.getUrl(), nbsri
						.getTitle()));
				item.add(new Label("data-content", nbsri.getContent()));
				item.add(new Label("data-source", nbsri.getSource()));
				item.add(new Label("data-add-time", nbsri.getAddTime()));
				// 添加至待处理
				AjaxButton dealBT = new AjaxButton("data-deal") {

					@Override
					public void onSubmit(AjaxRequestTarget target, Form form) {
						System.out.println("------ Deal !!!");
						N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
								currentUser.getU_mongoDB());
						nudbo.changeDealState(nbsri.getOid(), true);
						target.add(fxQBCLContainer);
					}
				};
				item.add(dealBT);
			}
		};
		fxQBCLForm.add(attentionDataListView);
		fxQBCLContainer.add(fxQBCLForm);
		//
		if (pageTag != null && pageTag.equals(N_Constants.PAGE_TAG_FX_QBCL))
			fxQBCLContainer.setVisible(true);
		else
			fxQBCLContainer.setVisible(false);
		this.add(fxQBCLContainer);
		/*-------------------------------------------------------------*/
	}

	public List<String> getEmailReceiverList() {
		emailReceiverList = new ArrayList<String>();
		N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
				currentUser.getU_mongoDB());
		List<N_Emailer_Info> receiverInfoList = nudbo.getAllShoujianrenList();
		for (int i = 0; i < receiverInfoList.size(); i++) {
			N_Emailer_Info nei = receiverInfoList.get(i);
			if (nei != null)
				emailReceiverList.add(nei.getName() + "[" + nei.getEmail()
						+ "]");
		}
		return emailReceiverList;
	}

	public void setEmailReceiverList(List<String> emailReceiverList) {
		this.emailReceiverList = emailReceiverList;
	}

	public String getEmailInfo() {
		return emailInfo;
	}

	public void setEmailInfo(String emailInfo) {
		this.emailInfo = emailInfo;
	}
}
