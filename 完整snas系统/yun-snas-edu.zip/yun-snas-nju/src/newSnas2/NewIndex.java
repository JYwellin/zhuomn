package newSnas2;

import newSnas.Nindex;
import newSnas.Nlogin;

import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.link.Link;

public class NewIndex extends WebPage {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2257809065092700316L;

	public NewIndex() {
		System.out.println("------------------------ ENTER INTO 首页 ------------------------");
		//
		this.add(new Link("linkToIndex-logo") {

			@Override
			public void onClick() {
				setResponsePage(NewIndex.class);
			}
		});
		this.add(new Link("linkToLogin") {

			@Override
			public void onClick() {
				setResponsePage(NewLogin.class);
			}
		});
		this.add(new Link("linkToRegister") {

			@Override
			public void onClick() {
				setResponsePage(NewLogin.class);
			}
		});
	}
}
