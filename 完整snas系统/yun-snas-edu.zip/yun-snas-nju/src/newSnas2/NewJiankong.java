package newSnas2;

import java.io.Serializable;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.StringTokenizer;

import newBasic.N_Bankuai_Shijian_Renwu_Info;
import newBasic.N_NewsInfo;
import newBasic.N_NewsPaperInfo;
import newBasic.N_User;
import newBasic.N_Wangzhi_Info;
import newBasic.N_WeiboInfo;
import newBasic.N_BBSInfo;
import newConstants.N_CONFIG;
import newConstants.N_Constants;
import newConstants.N_DataBuffer;
import newMongoDB.N_UDBO_BanKuai_ShiJian_RenWu;
import newMongoDB.N_UserDBOperation;
import newMongoDB.N_UserOperation;

import org.apache.wicket.Session;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.markup.html.AjaxLink;
import org.apache.wicket.ajax.markup.html.form.AjaxButton;
import org.apache.wicket.ajax.markup.html.navigation.paging.AjaxPagingNavigator;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.link.ExternalLink;
import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.markup.repeater.Item;
import org.apache.wicket.markup.repeater.data.DataView;
import org.apache.wicket.markup.repeater.data.IDataProvider;
import org.apache.wicket.model.IModel;
import org.apache.wicket.model.LoadableDetachableModel;
import org.apache.wicket.model.Model;
import org.apache.wicket.model.PropertyModel;
import org.apache.wicket.request.mapper.parameter.PageParameters;
import org.bson.types.ObjectId;

public class NewJiankong extends WebPage {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3746715646210639414L;
	private Session mySession = super.getSession();

	public N_User currentUser = (N_User) mySession.getAttribute("currentUser");
	public String role = currentUser.getU_role();
	public boolean confirmed = currentUser.isU_isConfirmed(); // 是否被激活确认！

	// weibo
	private WebMarkupContainer jkWeiboContainer;
	private LoadableDetachableModel<List<N_WeiboInfo>> weiboRealTimeLDM;
	private weiboItemsDataProvider<N_WeiboInfo> weiboListProvider;
	private String weiboSortType = N_DataBuffer.WEIBO_SORT_BY_TIME;
	private boolean weiboUpdateFlag = false;
	//

	// bbs
	private WebMarkupContainer jkBBSContainer;
	private LoadableDetachableModel<List<N_BBSInfo>> bbsRealTimeLDM;
	private bbsItemsDataProvider<N_BBSInfo> bbsListProvider;
	private String bbsSortType = N_DataBuffer.BBS_SORT_BY_TIME;
	private boolean bbsUpdateFlag = false;
	//

	// newspaper
	private WebMarkupContainer jkNewsPaperContainer;
	private LoadableDetachableModel<List<N_NewsPaperInfo>> npRealTimeLDM;
	private npItemsDataProvider<N_NewsPaperInfo> npListProvider;
	private String npSortType = N_DataBuffer.NP_SORT_BY_TIME;
	private boolean newspaperUpdateFlag = false;
	// news
	private WebMarkupContainer jkNewsContainer;
	private LoadableDetachableModel<List<N_NewsInfo>> newsRealTimeLDM;
	private newsItemsDataProvider<N_NewsInfo> newsListProvider;
	private String newsSortType = N_DataBuffer.NEWS_SORT_BY_TIME;
	private boolean newsUpdateFlag = false;

	// qingbaoshouye-情报首页
	private WebMarkupContainer jkQBSYContainer;
	private LoadableDetachableModel<List<String>> bankuaiLDM;

	// 事件跟踪
	private WebMarkupContainer jkSJGZContainer;
	private LoadableDetachableModel<List<String>> shijianLDM;

	// 人物跟踪
	private WebMarkupContainer jkRWGZContainer;
	private LoadableDetachableModel<List<String>> renwuLDM;

	// 情报配置
	// 版块配置
	private WebMarkupContainer jkBKPZContainer;
	public String bankuaiInfo = "";
	// 网址配置
	private WebMarkupContainer jkWZPZContainer;
	public String wangzhiInfo = "";
	// 事件配置
	private WebMarkupContainer jkSJPZContainer;
	public String shijianInfo = "";

	// 人物配置
	private WebMarkupContainer jkRWPZContainer;
	public String renwuInfo = "";

	//
	private String pageTag;

	//

	// ********************************//
	public NewJiankong(PageParameters parameters) {
		System.out.println("------------------------ ENTER INTO 舆情监控 ------------------------");
		// DATE
		Date currentDate = new Date();
		// Locale loCn = new Locale("en", "US");
		Locale loCn = new Locale("zh", "CN");
		String sDate = DateFormat.getDateInstance(DateFormat.FULL, loCn)
				.format(currentDate);
		Label dateLabel = new Label("date", sDate);
		this.add(dateLabel);
		// 导航
		this.add(new Label("userName", currentUser.getU_name()));
		this.add(new Link("loginOut") {

			@Override
			public void onClick() {
				mySession.removeAttribute("currentUser");
				N_UserOperation nuo = new N_UserOperation();
				nuo.changeUserLogin(currentUser.getU_name(), false);
				setResponsePage(NewLogin.class);
			}
		});
		this.add(new Link("linkToJianKong") {

			@Override
			public void onClick() {
				setResponsePage(NewJiankong.class);
			}
		});
		this.add(new Link("linkToFenXi") {

			@Override
			public void onClick() {
				setResponsePage(NewFenxi.class);
			}
		});
		this.add(new Link("linkToBaoGao") {

			@Override
			public void onClick() {
				setResponsePage(NewBaogao.class);
			}
		});
		this.add(new Link("linkToPeiZhi") {

			@Override
			public void onClick() {
				setResponsePage(NewPeizhi.class);
			}
		});
		//
		// ////////////////////////////////////////////////////////////////////////////////////////////////
		final Form<String> searchForm = new Form<String>("search-form");
		// 全站检索
		final TextField<String> searchTextField = new TextField<String>(
				"searchInput", new Model<String>());
		searchTextField.setRequired(false);
		searchForm.add(searchTextField);

		searchForm.add(new Button("searchButton") {

			public void onSubmit() {
				String searchText = searchTextField
						.getDefaultModelObjectAsString();

				if (searchText != null && searchText.length() >= 1) {
					PageParameters para = new PageParameters(); // 参数
					para.add("search", searchText);
					setResponsePage(NewSearch.class, para); // 转向search页面
				}
			}
		});
		this.add(searchForm);
		// ////////////////////////////////////////////////////////////////////////////////////////////////
		/*-------------左侧链接----------------------*/
		Link<String> turnToWeibo = new Link<String>("turnToWeibo") {
			private static final long serialVersionUID = -8689056403893428148L;

			@Override
			public void onClick() {
				System.out.println("------turn to weibo 刷新weibo");
				PageParameters pp = new PageParameters();
				pp.add("tag", N_Constants.PAGE_TAG_JK_WEIBO);
				setResponsePage(NewJiankong.class, pp);
			}
		};
		this.add(turnToWeibo);
		Link<String> turnToBBS = new Link<String>("turnToBBS") {
			private static final long serialVersionUID = 2442381487728452498L;

			@Override
			public void onClick() {
				System.out.println("------turn to bbs 刷新bbs");
				PageParameters pp = new PageParameters();
				pp.add("tag", N_Constants.PAGE_TAG_JK_BBS);
				setResponsePage(NewJiankong.class, pp);
			}
		};
		this.add(turnToBBS);
		Link<String> turnToNews = new Link<String>("turnToMenhuNews") {
			private static final long serialVersionUID = 8870965928220074657L;

			@Override
			public void onClick() {
				System.out.println("------turn to news 刷新news");
				PageParameters pp = new PageParameters();
				pp.add("tag", N_Constants.PAGE_TAG_JK_MENHUNEWS);
				setResponsePage(NewJiankong.class, pp);
			}
		};
		this.add(turnToNews);
		Link<String> turnToNewspaper = new Link<String>("turnToNewspaper") {
			private static final long serialVersionUID = 6871144787196088928L;

			@Override
			public void onClick() {
				System.out.println("------turn to newspaper 刷新newspaper");
				PageParameters pp = new PageParameters();
				pp.add("tag", N_Constants.PAGE_TAG_JK_NEWSPAPER);
				setResponsePage(NewJiankong.class, pp);
			}
		};
		this.add(turnToNewspaper);
		// new link 2014-10-23
		/*-------------------------------------*/
		Link<String> turnToQBSY = new Link<String>("turnToQingbaoshouye") {
			private static final long serialVersionUID = 8870965928220074657L;

			@Override
			public void onClick() {
				System.out.println("------turn to 情报首页!");
				PageParameters pp = new PageParameters();
				pp.add("tag", N_Constants.PAGE_TAG_JK_QINGBAOSHOUYE);
				setResponsePage(NewJiankong.class, pp);
			}
		};
		this.add(turnToQBSY);
		Link<String> turnToSJGZ = new Link<String>("turnToShijiangenzong") {
			private static final long serialVersionUID = -570385890154578610L;

			@Override
			public void onClick() {
				System.out.println("------turn to 事件跟踪!");
				PageParameters pp = new PageParameters();
				pp.add("tag", N_Constants.PAGE_TAG_JK_SHIJIANGENZONG);
				setResponsePage(NewJiankong.class, pp);
			}
		};
		this.add(turnToSJGZ);
		Link<String> turnToRWGZ = new Link<String>("turnToRenwugenzong") {
			private static final long serialVersionUID = 6871144787196088928L;

			@Override
			public void onClick() {
				System.out.println("------turn to 人物跟踪!");
				PageParameters pp = new PageParameters();
				pp.add("tag", N_Constants.PAGE_TAG_JK_RENWUGENZONG);
				setResponsePage(NewJiankong.class, pp);
			}
		};
		this.add(turnToRWGZ);
		Link<String> turnToBKPZ = new Link<String>("turnToBKPZ") {
			private static final long serialVersionUID = -8201464679415411353L;

			@Override
			public void onClick() {
				System.out.println("------turn to 版块配置!");
				PageParameters pp = new PageParameters();
				pp.add("tag", N_Constants.PAGE_TAG_JK_BANKUAIPEIZHI);
				setResponsePage(NewJiankong.class, pp);
			}
		};
		this.add(turnToBKPZ);
		Link<String> turnToWZPZ = new Link<String>("turnToWZPZ") {
			private static final long serialVersionUID = -8058843560278294064L;

			@Override
			public void onClick() {
				System.out.println("------turn to 网址配置!");
				PageParameters pp = new PageParameters();
				pp.add("tag", N_Constants.PAGE_TAG_JK_WANGZHIPEIZHI);
				setResponsePage(NewJiankong.class, pp);
			}
		};
		this.add(turnToWZPZ);
		Link<String> turnToSJPZ = new Link<String>("turnToSJPZ") {
			private static final long serialVersionUID = 5974197442469137796L;

			@Override
			public void onClick() {
				System.out.println("------turn to 事件配置!");
				PageParameters pp = new PageParameters();
				pp.add("tag", N_Constants.PAGE_TAG_JK_SHIJIANPEIZHI);
				setResponsePage(NewJiankong.class, pp);
			}
		};
		this.add(turnToSJPZ);
		Link<String> turnToRWPZ = new Link<String>("turnToRWPZ") {
			private static final long serialVersionUID = -7021376709377835605L;

			@Override
			public void onClick() {
				System.out.println("------turn to 人物配置!");
				PageParameters pp = new PageParameters();
				pp.add("tag", N_Constants.PAGE_TAG_JK_RENWUPEIZHI);
				setResponsePage(NewJiankong.class, pp);
			}
		};
		this.add(turnToRWPZ);
		/*-------------------------------------*/
		/*-------------------------------------*/
		// 获取page tag
		pageTag = parameters.get("tag").toString();
		/*------------------JK welcome container-------------------*/
		WebMarkupContainer welcomeContainer = new WebMarkupContainer("jk-welcome-Container");
		if (pageTag == null) {
			welcomeContainer.setVisible(false);
			pageTag = N_Constants.PAGE_TAG_JK_QINGBAOSHOUYE;
		} else
			welcomeContainer.setVisible(false);
		this.add(welcomeContainer);
		/*------------------JK not confirmed container-------------------*/
		WebMarkupContainer notConfirmedContainer = new WebMarkupContainer("jk-notConfirmed-Container");
		if (pageTag != null && confirmed == false)
			notConfirmedContainer.setVisible(true);
		else
			notConfirmedContainer.setVisible(false);
		this.add(notConfirmedContainer);
		//
		//
		//
		//
		// ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		/*------------------JK weibo container-------------------*/
		jkWeiboContainer = new WebMarkupContainer("jk-weibo-Container");
		jkWeiboContainer.setOutputMarkupId(true);
		Form<String> jkWeiboForm = new Form<String>("jk-weibo-form");
		//
		AjaxButton jkWeiboRankTimeBT = new AjaxButton("weibo-rank-time") {
			public void onSubmit(AjaxRequestTarget target, Form form) {
				//
				System.out.println("------ Button : Rank by time!");
				weiboSortType = N_DataBuffer.WEIBO_SORT_BY_TIME;
				weiboUpdateFlag = true;
				target.add(jkWeiboContainer);
			}
		};
		jkWeiboForm.add(jkWeiboRankTimeBT);
		AjaxButton jkWeiboRankAttentionBT = new AjaxButton("weibo-rank-attention") {
			public void onSubmit(AjaxRequestTarget target, Form form) {
				//
				System.out.println("------ Button : Rank by attention!");
				weiboSortType = N_DataBuffer.WEIBO_SORT_BY_ATTENTION;
				weiboUpdateFlag = true;
				target.add(jkWeiboContainer);
			}
		};
		jkWeiboForm.add(jkWeiboRankAttentionBT);
		AjaxButton jkWeiboRankSentimentBT = new AjaxButton("weibo-rank-sentiment") {
			public void onSubmit(AjaxRequestTarget target, Form form) {
				//
				System.out.println("------ Button : Rank by sentiment!");
				weiboSortType = N_DataBuffer.WEIBO_SORT_BY_SENTIMENT;
				weiboUpdateFlag = true;
				target.add(jkWeiboContainer);
			}
		};
		jkWeiboForm.add(jkWeiboRankSentimentBT);
		//
		jkWeiboContainer.add(jkWeiboForm);
		// LDM
		weiboRealTimeLDM = new LoadableDetachableModel<List<N_WeiboInfo>>() {
			private static final long serialVersionUID = 8382012067652020185L;

			@Override
			protected List<N_WeiboInfo> load() { // list数据加载
				System.out.println("------JK 刷新-加载微博数据!");
				if (currentUser != null && confirmed && pageTag != null
						&& pageTag.equals(N_Constants.PAGE_TAG_JK_WEIBO)) {
					N_UserDBOperation nudbo = new N_UserDBOperation(currentUser.getU_mongoDB());
					nudbo.getUserAllWeibo(weiboSortType);
				}
				return N_DataBuffer.weiboDataBuffer;
			}
		};
		// 分页显示data
		weiboListProvider = new weiboItemsDataProvider<N_WeiboInfo>();
		final DataView<N_WeiboInfo> weiboListPaging = new DataView<N_WeiboInfo>(
				"weiboListPaging", weiboListProvider) {
			private static final long serialVersionUID = 5210387657912306441L;

			@Override
			protected void populateItem(Item<N_WeiboInfo> item) {
				N_WeiboInfo nwi = (newBasic.N_WeiboInfo) item.getDefaultModelObject();
				final ObjectId oid = nwi.getOid();
				String content = nwi.getContent();
				String time = nwi.getTime();
				int forward = nwi.getForward();
				int comment = nwi.getComment();
				int like = nwi.getLike();
				int favorite = nwi.getFavorite();
				double attention = nwi.getAttention();
				String sentiment = nwi.getSentiment();
				if (sentiment.equals(N_Constants.SENTIMENT_POSITIVE))
					sentiment = "正面";
				else if (sentiment.equals(N_Constants.SENTIMENT_NEGATIVE))
					sentiment = "负面";
				else
					sentiment = "中立";
				String url = nwi.getUrl();
				List<String> kwList = nwi.getKeyWords();
				String kwStr = "";
				if (kwList != null) {
					for (int i = 0; i < kwList.size(); i++)
						kwStr += kwList.get(i) + " ";
				}
				//
				ExternalLink eLink = new ExternalLink("weibo-content", url,
						content);
				item.add(eLink);
				item.add(new Label("weibo-keywords", kwStr));
				item.add(new Label("weibo-time", time));
				item.add(new Label("weibo-forward", "" + forward));
				item.add(new Label("weibo-comment", "" + comment));
				item.add(new Label("weibo-like", "" + like));
				item.add(new Label("weibo-favorite", "" + favorite));
				item.add(new Label("weibo-attention", "" + attention));
				item.add(new Label("weibo-sentiment", "" + sentiment));

				//
				Form operateForm = new Form("weibo-operate-form");

				operateForm.add(new AjaxButton("weibo-bt-positive") {
					public void onSubmit(AjaxRequestTarget target, Form form) {
						//
						System.out.println("------ Button : positive!");
						N_UserDBOperation nudbo = new N_UserDBOperation(
								currentUser.getU_mongoDB());
						//
						nudbo.changeWBSentiment(oid, 1);
						weiboUpdateFlag = true;
						//
						target.add(jkWeiboContainer);
					}
				});
				operateForm.add(new AjaxButton("weibo-bt-neutral") {
					public void onSubmit(AjaxRequestTarget target, Form form) {
						//
						System.out.println("------ Button : neutral!");
						N_UserDBOperation nudbo = new N_UserDBOperation(
								currentUser.getU_mongoDB());
						//
						nudbo.changeWBSentiment(oid, 0);
						weiboUpdateFlag = true;
						//
						target.add(jkWeiboContainer);
					}
				});
				operateForm.add(new AjaxButton("weibo-bt-negative") {
					public void onSubmit(AjaxRequestTarget target, Form form) {
						//
						System.out.println("------ Button : negative!");
						N_UserDBOperation nudbo = new N_UserDBOperation(
								currentUser.getU_mongoDB());
						//
						nudbo.changeWBSentiment(oid, -1);
						weiboUpdateFlag = true;
						//
						target.add(jkWeiboContainer);
					}
				});
				item.add(operateForm);
			}
		};
		weiboListPaging.setItemsPerPage(10); // 每页显示数目
		// 分页导航
		AjaxPagingNavigator weiboListNavigator = new AjaxPagingNavigator("weiboListNavigator", weiboListPaging) {
			private static final long serialVersionUID = 2808831266697505012L;

		};
		jkWeiboContainer.add(weiboListNavigator);
		jkWeiboContainer.add(weiboListPaging);
		//
		//
		if (pageTag != null && confirmed == true
				&& pageTag.equals(N_Constants.PAGE_TAG_JK_WEIBO))
			jkWeiboContainer.setVisible(true);
		else if (pageTag == null)
			jkWeiboContainer.setVisible(true);
		else
			jkWeiboContainer.setVisible(false);
		this.add(jkWeiboContainer);
		//
		// ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		/*------------------JK bbs container-------------------*/
		jkBBSContainer = new WebMarkupContainer("jk-bbs-Container");
		jkBBSContainer.setOutputMarkupId(true);
		Form<String> jkBBSForm = new Form<String>("jk-bbs-form");
		//
		//
		AjaxButton jkBBSRankTimeBT = new AjaxButton("bbs-rank-time") {
			/**
			 * 
			 */
			private static final long serialVersionUID = -6548999400968510015L;

			public void onSubmit(AjaxRequestTarget target, Form form) {
				//
				System.out.println("------ Button : Rank by time!");
				bbsSortType = N_DataBuffer.BBS_SORT_BY_TIME;
				bbsUpdateFlag = true;
				target.add(jkBBSContainer);
			}
		};
		jkBBSForm.add(jkBBSRankTimeBT);
		AjaxButton jkBBSRankAttentionBT = new AjaxButton("bbs-rank-attention") {
			/**
			 * 
			 */
			private static final long serialVersionUID = -1730596398617850968L;

			public void onSubmit(AjaxRequestTarget target, Form form) {
				//
				System.out.println("------ Button : Rank by attention!");
				bbsSortType = N_DataBuffer.BBS_SORT_BY_ATTENTION;
				bbsUpdateFlag = true;
				target.add(jkBBSContainer);
			}
		};
		jkBBSForm.add(jkBBSRankAttentionBT);
		AjaxButton jkBBSRankSentimentBT = new AjaxButton("bbs-rank-sentiment") {
			/**
			 * 
			 */
			private static final long serialVersionUID = -6459726977705787444L;

			public void onSubmit(AjaxRequestTarget target, Form form) {
				//
				System.out.println("------ Button : Rank by sentiment!");
				bbsSortType = N_DataBuffer.BBS_SORT_BY_SENTIMENT;
				bbsUpdateFlag = true;
				target.add(jkBBSContainer);
			}
		};
		jkBBSForm.add(jkBBSRankSentimentBT);
		//
		jkBBSContainer.add(jkBBSForm);
		// LDM
		bbsRealTimeLDM = new LoadableDetachableModel<List<N_BBSInfo>>() {
			private static final long serialVersionUID = 5679762478401194689L;

			@Override
			protected List<N_BBSInfo> load() { // list数据加载
				System.out.println("------JK 刷新-加载BBS数据!");
				if (currentUser != null && confirmed && pageTag != null
						&& pageTag.equals(N_Constants.PAGE_TAG_JK_BBS)) {
					N_UserDBOperation nudbo = new N_UserDBOperation(
							currentUser.getU_mongoDB());
					nudbo.getUserAllBBS(bbsSortType);
				}
				return N_DataBuffer.bbsDataBuffer;
			}
		};
		// 分页显示data
		bbsListProvider = new bbsItemsDataProvider<N_BBSInfo>();
		final DataView<N_BBSInfo> bbsListPaging = new DataView<N_BBSInfo>(
				"bbsListPaging", bbsListProvider) {

			/**
			 * 
			 */
			private static final long serialVersionUID = 2397473388068845528L;

			@Override
			protected void populateItem(Item<N_BBSInfo> item) {
				N_BBSInfo nbi = (N_BBSInfo) item.getDefaultModelObject();
				final ObjectId oid = nbi.getOid();
				String title = nbi.getTitle();
				final String time = nbi.getTime();
				int reply = nbi.getReplyNum();
				int click = nbi.getClickNum();
				double attention = nbi.getAttention();
				String source = nbi.getSource();
				String source_url = nbi.getSource_url();
				String sentiment = nbi.getSentiment();
				if (sentiment.equals(N_Constants.SENTIMENT_POSITIVE))
					sentiment = "正面";
				else if (sentiment.equals(N_Constants.SENTIMENT_NEGATIVE))
					sentiment = "负面";
				else
					sentiment = "中立";
				String url = nbi.getUrl();
				List<String> tags = nbi.getTags();
				String tagsStr = "";
				for (int i = 0; i < tags.size(); i++)
					tagsStr += tags.get(i) + " ";
				//
				ExternalLink eLink = new ExternalLink("bbs-title", url, title);
				item.add(eLink);
				item.add(new Label("bbs-keywords", tagsStr));
				item.add(new Label("bbs-time", time));
				ExternalLink sourceLink = new ExternalLink("bbs-source",
						source_url, source);
				item.add(sourceLink);
				item.add(new Label("bbs-reply", "" + reply));
				item.add(new Label("bbs-click", "" + click));
				item.add(new Label("bbs-attention", "" + attention));
				item.add(new Label("bbs-sentiment", "" + sentiment));
				//
				Form operateForm = new Form("bbs-operate-form");

				operateForm.add(new AjaxButton("bbs-bt-positive") {
					public void onSubmit(AjaxRequestTarget target, Form form) {
						//
						System.out.println("------ Button : positive!");
						N_UserDBOperation nudbo = new N_UserDBOperation(
								currentUser.getU_mongoDB());
						nudbo.changeBBSSentiment(oid, 1);
						bbsUpdateFlag = true;
						target.add(jkBBSContainer);
					}
				});
				operateForm.add(new AjaxButton("bbs-bt-neutral") {
					public void onSubmit(AjaxRequestTarget target, Form form) {
						//
						System.out.println("------ Button : neutral!");
						N_UserDBOperation nudbo = new N_UserDBOperation(
								currentUser.getU_mongoDB());
						nudbo.changeBBSSentiment(oid, 0);
						bbsUpdateFlag = true;
						target.add(jkBBSContainer);
					}
				});
				operateForm.add(new AjaxButton("bbs-bt-negative") {
					public void onSubmit(AjaxRequestTarget target, Form form) {
						//
						System.out.println("------ Button : negative!");
						N_UserDBOperation nudbo = new N_UserDBOperation(
								currentUser.getU_mongoDB());
						nudbo.changeBBSSentiment(oid, -1);
						bbsUpdateFlag = true;
						target.add(jkBBSContainer);
					}
				});
				item.add(operateForm);
			}
		};
		bbsListPaging.setItemsPerPage(10); // 每页显示数目
		// 分页导航
		AjaxPagingNavigator bbsListNavigator = new AjaxPagingNavigator(
				"bbsListNavigator", bbsListPaging) {
			private static final long serialVersionUID = -2510082492867685010L;

		};
		jkBBSContainer.add(bbsListNavigator);
		jkBBSContainer.add(bbsListPaging);

		//
		if (pageTag != null && confirmed == true
				&& pageTag.equals(N_Constants.PAGE_TAG_JK_BBS))
			jkBBSContainer.setVisible(true);
		else
			jkBBSContainer.setVisible(false);
		this.add(jkBBSContainer);
		//
		// /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		/*------------------JK menhu news container-------------------*/
		jkNewsContainer = new WebMarkupContainer("jk-news-Container");
		//
		jkNewsContainer.setOutputMarkupId(true);
		Form<String> jkNewsForm = new Form<String>("jk-news-form");
		//
		//
		AjaxButton jkNewsRankTimeBT = new AjaxButton("news-rank-time") {
			private static final long serialVersionUID = -3649509475633246122L;

			public void onSubmit(AjaxRequestTarget target, Form form) {
				//
				System.out.println("------ Button : Rank by time!");
				newsSortType = N_DataBuffer.NEWS_SORT_BY_TIME;
				newsUpdateFlag = true;
				target.add(jkNewsContainer);
			}
		};
		jkNewsForm.add(jkNewsRankTimeBT);
		AjaxButton jkNewsRankSentimentBT = new AjaxButton("news-rank-sentiment") {

			public void onSubmit(AjaxRequestTarget target, Form form) {
				//
				System.out.println("------ Button : Rank by sentiment!");
				newsSortType = N_DataBuffer.NEWS_SORT_BY_SENTIMENT;
				newsUpdateFlag = true;
				target.add(jkNewsContainer);
			}
		};
		jkNewsForm.add(jkNewsRankSentimentBT);
		//
		jkNewsContainer.add(jkNewsForm);
		// LDM
		newsRealTimeLDM = new LoadableDetachableModel<List<N_NewsInfo>>() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -8842486576042771839L;

			@Override
			protected List<N_NewsInfo> load() { // list数据加载
				System.out.println("------JK 刷新-加载News数据!");
				if (currentUser != null && confirmed && pageTag != null
						&& pageTag.equals(N_Constants.PAGE_TAG_JK_MENHUNEWS)) {
					N_UserDBOperation nudbo = new N_UserDBOperation(
							currentUser.getU_mongoDB());
					nudbo.getUserAllNews(newsSortType);
				}
				return N_DataBuffer.newsDataBuffer;
			}
		};
		// 分页显示data
		newsListProvider = new newsItemsDataProvider<N_NewsInfo>();
		final DataView<N_NewsInfo> NewsListPaging = new DataView<N_NewsInfo>(
				"newsListPaging", newsListProvider) {
			private static final long serialVersionUID = 6813748610720536342L;

			@Override
			protected void populateItem(Item<N_NewsInfo> item) {
				N_NewsInfo nbi = (N_NewsInfo) item.getDefaultModelObject();
				final ObjectId oid = nbi.getOid();
				String title = nbi.getTitle();
				String content = nbi.getContent();
				if (content.length() > N_Constants.MAX_CONTENT_LENGTH) {
					content = content.substring(0,
							N_Constants.MAX_CONTENT_LENGTH - 1);
					content += " ......";
				}
				//
				final String time = nbi.getTime();
				String source = nbi.getSource();
				String sourceUrl = nbi.getSourceUrl();
				String sentiment = nbi.getSentiment();
				if (sentiment.equals(N_Constants.SENTIMENT_POSITIVE))
					sentiment = "正面";
				else if (sentiment.equals(N_Constants.SENTIMENT_NEGATIVE))
					sentiment = "负面";
				else
					sentiment = "中立";
				String url = nbi.getUrl();
				List<String> tags = nbi.getTags();
				String tagsStr = "";
				for (int i = 0; i < tags.size(); i++)
					tagsStr += tags.get(i) + " ";
				//
				ExternalLink eLink = new ExternalLink("news-title", url, title);
				item.add(eLink);
				item.add(new Label("news-content", content));
				//
				item.add(new Label("news-keywords", tagsStr));
				item.add(new Label("news-time", time));
				ExternalLink sourceLink = new ExternalLink("news-source",
						sourceUrl, source);
				item.add(sourceLink);
				item.add(new Label("news-sentiment", "" + sentiment));
				//
				Form operateForm = new Form("news-operate-form");

				operateForm.add(new AjaxButton("news-bt-positive") {
					public void onSubmit(AjaxRequestTarget target, Form form) {
						//
						System.out.println("------ Button : positive!");
						N_UserDBOperation nudbo = new N_UserDBOperation(
								currentUser.getU_mongoDB());
						nudbo.changeNewsSentiment(oid, 1);
						newsUpdateFlag = true;
						target.add(jkNewsContainer);
					}
				});
				operateForm.add(new AjaxButton("news-bt-neutral") {
					public void onSubmit(AjaxRequestTarget target, Form form) {
						//
						System.out.println("------ Button : neutral!");
						N_UserDBOperation nudbo = new N_UserDBOperation(
								currentUser.getU_mongoDB());
						nudbo.changeNewsSentiment(oid, 0);
						newsUpdateFlag = true;
						target.add(jkNewsContainer);
					}
				});
				operateForm.add(new AjaxButton("news-bt-negative") {
					public void onSubmit(AjaxRequestTarget target, Form form) {
						//
						System.out.println("------ Button : negative!");
						N_UserDBOperation nudbo = new N_UserDBOperation(
								currentUser.getU_mongoDB());
						nudbo.changeNewsSentiment(oid, -1);
						newsUpdateFlag = true;
						target.add(jkNewsContainer);
					}
				});
				item.add(operateForm);
			}
		};
		NewsListPaging.setItemsPerPage(10); // 每页显示数目
		// 分页导航
		AjaxPagingNavigator NewsListNavigator = new AjaxPagingNavigator(
				"newsListNavigator", NewsListPaging) {
			private static final long serialVersionUID = -4313078083823583775L;
		};
		jkNewsContainer.add(NewsListNavigator);
		jkNewsContainer.add(NewsListPaging);
		if (pageTag != null && confirmed == true
				&& pageTag.equals(N_Constants.PAGE_TAG_JK_MENHUNEWS))
			jkNewsContainer.setVisible(true);
		else
			jkNewsContainer.setVisible(false);
		this.add(jkNewsContainer);
		//
		// /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		/*------------------JK newspaper container-------------------*/
		jkNewsPaperContainer = new WebMarkupContainer("jk-newspaper-Container");
		//
		jkNewsPaperContainer.setOutputMarkupId(true);
		Form<String> jkNewsPaperForm = new Form<String>("jk-newspaper-form");
		//
		//
		AjaxButton jkNewsPaperRankTimeBT = new AjaxButton("newspaper-rank-time") {
			/**
			 * 
			 */

			public void onSubmit(AjaxRequestTarget target, Form form) {
				//
				System.out.println("------ Button : Rank by time!");
				npSortType = N_DataBuffer.NP_SORT_BY_TIME;
				newspaperUpdateFlag = true;
				target.add(jkNewsPaperContainer);
			}
		};
		jkNewsPaperForm.add(jkNewsPaperRankTimeBT);
		AjaxButton jkNewsPaperRankSentimentBT = new AjaxButton(
				"newspaper-rank-sentiment") {

			public void onSubmit(AjaxRequestTarget target, Form form) {
				//
				System.out.println("------ Button : Rank by sentiment!");
				npSortType = N_DataBuffer.NP_SORT_BY_SENTIMENT;
				newspaperUpdateFlag = true;
				target.add(jkNewsPaperContainer);
			}
		};
		jkNewsPaperForm.add(jkNewsPaperRankSentimentBT);
		//
		jkNewsPaperContainer.add(jkNewsPaperForm);
		// LDM
		npRealTimeLDM = new LoadableDetachableModel<List<N_NewsPaperInfo>>() {
			private static final long serialVersionUID = 3870703010129635092L;

			@Override
			protected List<N_NewsPaperInfo> load() { // list数据加载
				System.out.println("------JK 刷新-加载NewsPaper数据!");
				if (currentUser != null && confirmed && pageTag != null
						&& pageTag.equals(N_Constants.PAGE_TAG_JK_NEWSPAPER)) {
					N_UserDBOperation nudbo = new N_UserDBOperation(
							currentUser.getU_mongoDB());
					nudbo.getUserAllNewsPaper(npSortType);
				}
				return N_DataBuffer.npDataBuffer;
			}
		};
		// 分页显示data
		npListProvider = new npItemsDataProvider<N_NewsPaperInfo>();
		final DataView<N_NewsPaperInfo> NewsPaperListPaging = new DataView<N_NewsPaperInfo>(
				"newspaperListPaging", npListProvider) {

			/**
			 * 
			 */
			private static final long serialVersionUID = 2397473388068845528L;

			@Override
			protected void populateItem(Item<N_NewsPaperInfo> item) {
				N_NewsPaperInfo nbi = (N_NewsPaperInfo) item
						.getDefaultModelObject();
				final ObjectId oid = nbi.getOid();
				String title = nbi.getTitle();
				String content = nbi.getContent();
				if (content.length() > N_Constants.MAX_CONTENT_LENGTH) {
					content = content.substring(0,
							N_Constants.MAX_CONTENT_LENGTH - 1);
					content += " ......";
				}
				//
				final String time = nbi.getTime();
				String source = nbi.getSource();
				String sentiment = nbi.getSentiment();
				if (sentiment.equals(N_Constants.SENTIMENT_POSITIVE))
					sentiment = "正面";
				else if (sentiment.equals(N_Constants.SENTIMENT_NEGATIVE))
					sentiment = "负面";
				else
					sentiment = "中立";
				String url = nbi.getUrl();
				List<String> tags = nbi.getTags();
				String tagsStr = "";
				for (int i = 0; i < tags.size(); i++)
					tagsStr += tags.get(i) + " ";
				//
				ExternalLink eLink = new ExternalLink("newspaper-title", url,
						title);
				item.add(eLink);
				item.add(new Label("newspaper-content", content));
				//
				item.add(new Label("newspaper-keywords", tagsStr));
				item.add(new Label("newspaper-time", time));
				ExternalLink sourceLink = new ExternalLink("newspaper-source",
						"", source);
				item.add(sourceLink);
				item.add(new Label("newspaper-sentiment", "" + sentiment));
				//
				Form operateForm = new Form("newspaper-operate-form");

				operateForm.add(new AjaxButton("newspaper-bt-positive") {
					public void onSubmit(AjaxRequestTarget target, Form form) {
						//
						System.out.println("------ Button : positive!");
						N_UserDBOperation nudbo = new N_UserDBOperation(
								currentUser.getU_mongoDB());
						nudbo.changeNPSentiment(oid, 1);
						newspaperUpdateFlag = true;
						target.add(jkNewsPaperContainer);
					}
				});
				operateForm.add(new AjaxButton("newspaper-bt-neutral") {
					public void onSubmit(AjaxRequestTarget target, Form form) {
						//
						System.out.println("------ Button : neutral!");
						N_UserDBOperation nudbo = new N_UserDBOperation(
								currentUser.getU_mongoDB());
						nudbo.changeNPSentiment(oid, 0);
						newspaperUpdateFlag = true;
						target.add(jkNewsPaperContainer);
					}
				});
				operateForm.add(new AjaxButton("newspaper-bt-negative") {
					public void onSubmit(AjaxRequestTarget target, Form form) {
						//
						System.out.println("------ Button : negative!");
						N_UserDBOperation nudbo = new N_UserDBOperation(
								currentUser.getU_mongoDB());
						nudbo.changeNPSentiment(oid, -1);
						newspaperUpdateFlag = true;
						target.add(jkNewsPaperContainer);
					}
				});
				item.add(operateForm);
			}
		};
		NewsPaperListPaging.setItemsPerPage(10); // 每页显示数目
		// 分页导航
		AjaxPagingNavigator NewsPaperListNavigator = new AjaxPagingNavigator(
				"newspaperListNavigator", NewsPaperListPaging) {
			private static final long serialVersionUID = -2510082492867685010L;

		};
		jkNewsPaperContainer.add(NewsPaperListNavigator);
		jkNewsPaperContainer.add(NewsPaperListPaging);
		//
		if (pageTag != null && confirmed == true
				&& pageTag.equals(N_Constants.PAGE_TAG_JK_NEWSPAPER))
			jkNewsPaperContainer.setVisible(true);
		else
			jkNewsPaperContainer.setVisible(false);
		this.add(jkNewsPaperContainer);
		//
		// /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		/*------------------JK guanzhu weibo container-------------------*/

		// /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		/*------------------------QBSY----------------------------------------------*/
		jkQBSYContainer = new WebMarkupContainer("jk-qingbaoshouye-Container");
		jkQBSYContainer.setOutputMarkupId(true);
		Form<String> jkQBSYForm = new Form<String>("jk-qingbaoshouye-form");
		//
		bankuaiLDM = new LoadableDetachableModel<List<String>>() {
			private static final long serialVersionUID = -7780021848483017091L;

			@Override
			protected List<String> load() {
				N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
						currentUser.getU_mongoDB());
				if (currentUser != null
						&& confirmed
						&& pageTag != null
						&& pageTag.equals(N_Constants.PAGE_TAG_JK_QINGBAOSHOUYE))
					return nudbo.getAllBanKuaiList(N_CONFIG.TYPE_BANKUAI);
				else
					return null;
			}
		};
		ListView<String> bankuaiListView = new ListView<String>("bankuaiList",
				bankuaiLDM) {
			private static final long serialVersionUID = 2628732816425802365L;

			@Override
			protected void populateItem(ListItem<String> item) {
				final String bankuaiName = item.getModelObject();
				item.add(new Label("bk-name", bankuaiName));
				item.add(new Label("bk-data", ""));
				LoadableDetachableModel<List<N_Bankuai_Shijian_Renwu_Info>> bankuaiDataLDM = new LoadableDetachableModel<List<N_Bankuai_Shijian_Renwu_Info>>() {

					@Override
					protected List<N_Bankuai_Shijian_Renwu_Info> load() {
						N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
								currentUser.getU_mongoDB());
						return nudbo.getBankuaiData(bankuaiName,
								N_CONFIG.TYPE_BANKUAI);
					}
				};
				ListView<N_Bankuai_Shijian_Renwu_Info> bankuaiDataView = new ListView<N_Bankuai_Shijian_Renwu_Info>(
						"bankuaiDataList", bankuaiDataLDM) {

					@Override
					protected void populateItem(
							ListItem<N_Bankuai_Shijian_Renwu_Info> item1) {
						final N_Bankuai_Shijian_Renwu_Info nbsri = item1
								.getModelObject();
						item1.add(new ExternalLink("bk-data-title", nbsri
								.getUrl(), nbsri.getTitle()));
						item1.add(new Label("bk-data-content", nbsri
								.getContent()));
						item1.add(new Label("bk-data-source", nbsri.getSource()));
						// 添加至待处理
						AjaxButton bkDealBT = new AjaxButton("bk-deal") {

							@Override
							public void onSubmit(AjaxRequestTarget target,
									Form form) {
								System.out.println("------ Deal BANKUAI!");
								N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
										currentUser.getU_mongoDB());
								nudbo.addToAttentionCollection(nbsri);
								target.add(jkQBSYContainer);
							}
						};
						item1.add(bkDealBT);
					}
				};
				item.add(bankuaiDataView);
			}
		};
		jkQBSYForm.add(bankuaiListView);
		jkQBSYContainer.add(jkQBSYForm);
		//
		if (pageTag != null && confirmed == true
				&& pageTag.equals(N_Constants.PAGE_TAG_JK_QINGBAOSHOUYE))
			jkQBSYContainer.setVisible(true);
		else
			jkQBSYContainer.setVisible(false);
		this.add(jkQBSYContainer);
		/*---------------------------SJGZ-------------------------------------------*/
		jkSJGZContainer = new WebMarkupContainer("jk-shijiangenzong-Container");
		jkSJGZContainer.setOutputMarkupId(true);
		//
		Form<String> jkSJGZForm = new Form<String>("jk-shijiangenzong-form");
		shijianLDM = new LoadableDetachableModel<List<String>>() {
			private static final long serialVersionUID = -1142459410245413674L;

			@Override
			protected List<String> load() {
				N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
						currentUser.getU_mongoDB());
				if (currentUser != null
						&& confirmed
						&& pageTag != null
						&& pageTag
								.equals(N_Constants.PAGE_TAG_JK_SHIJIANGENZONG))
					return nudbo.getAllBanKuaiList(N_CONFIG.TYPE_SHIJIAN);
				else
					return null;
			}
		};
		ListView<String> shijianListView = new ListView<String>("shijianList",
				shijianLDM) {
			private static final long serialVersionUID = 2628732816425802365L;

			@Override
			protected void populateItem(ListItem<String> item) {
				final String shijianName = item.getModelObject();
				item.add(new Label("sj-name", shijianName));
				item.add(new Label("sj-data", ""));
				LoadableDetachableModel<List<N_Bankuai_Shijian_Renwu_Info>> shijianDataLDM = new LoadableDetachableModel<List<N_Bankuai_Shijian_Renwu_Info>>() {

					@Override
					protected List<N_Bankuai_Shijian_Renwu_Info> load() {
						N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
								currentUser.getU_mongoDB());
						return nudbo.getBankuaiData(shijianName,
								N_CONFIG.TYPE_SHIJIAN);
					}
				};
				ListView<N_Bankuai_Shijian_Renwu_Info> shijianDataView = new ListView<N_Bankuai_Shijian_Renwu_Info>(
						"shijianDataList", shijianDataLDM) {

					@Override
					protected void populateItem(
							ListItem<N_Bankuai_Shijian_Renwu_Info> item1) {
						final N_Bankuai_Shijian_Renwu_Info nbsri = item1
								.getModelObject();
						item1.add(new ExternalLink("sj-data-title", nbsri
								.getUrl(), nbsri.getTitle()));
						item1.add(new Label("sj-data-content", nbsri
								.getContent()));
						item1.add(new Label("sj-data-source", nbsri.getSource()));
						// 添加至待处理
						AjaxButton sjDealBT = new AjaxButton("sj-deal") {

							@Override
							public void onSubmit(AjaxRequestTarget target,
									Form form) {
								System.out.println("------ Deal SHIJIAN!");
								N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
										currentUser.getU_mongoDB());
								nudbo.addToAttentionCollection(nbsri);
								target.add(jkSJPZContainer);
							}
						};
						item1.add(sjDealBT);
					}
				};
				item.add(shijianDataView);
			}
		};
		jkSJGZForm.add(shijianListView);
		jkSJGZContainer.add(jkSJGZForm);
		if (pageTag != null && confirmed == true
				&& pageTag.equals(N_Constants.PAGE_TAG_JK_SHIJIANGENZONG))
			jkSJGZContainer.setVisible(true);
		else
			jkSJGZContainer.setVisible(false);
		this.add(jkSJGZContainer);
		/*----------------------------RWGZ------------------------------------------*/
		/*----------------------------RWGZ------------------------------------------*/
		jkRWGZContainer = new WebMarkupContainer("jk-renwugenzong-Container");
		jkRWGZContainer.setOutputMarkupId(true);
		Form<String> jkRWGZForm = new Form<String>("jk-renwugenzong-form");
		//
		renwuLDM = new LoadableDetachableModel<List<String>>() {
			private static final long serialVersionUID = -1235572260494984156L;

			@Override
			protected List<String> load() {
				N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
						currentUser.getU_mongoDB());
				if (currentUser != null && confirmed && pageTag != null
						&& pageTag.equals(N_Constants.PAGE_TAG_JK_RENWUGENZONG))
					return nudbo.getAllBanKuaiList(N_CONFIG.TYPE_RENWU);
				else
					return null;
			}
		};
		ListView<String> renwuListView = new ListView<String>("renwuList",
				renwuLDM) {
			private static final long serialVersionUID = -1316957079547827680L;

			@Override
			protected void populateItem(ListItem<String> item) {
				final String renwuName = item.getModelObject();
				item.add(new Label("rw-name", renwuName));
				item.add(new Label("rw-data", ""));
				LoadableDetachableModel<List<N_Bankuai_Shijian_Renwu_Info>> renwuDataLDM = new LoadableDetachableModel<List<N_Bankuai_Shijian_Renwu_Info>>() {

					@Override
					protected List<N_Bankuai_Shijian_Renwu_Info> load() {
						N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
								currentUser.getU_mongoDB());
						return nudbo.getBankuaiData(renwuName,
								N_CONFIG.TYPE_RENWU);
					}
				};
				ListView<N_Bankuai_Shijian_Renwu_Info> renwuDataView = new ListView<N_Bankuai_Shijian_Renwu_Info>(
						"renwuDataList", renwuDataLDM) {

					@Override
					protected void populateItem(
							ListItem<N_Bankuai_Shijian_Renwu_Info> item1) {
						final N_Bankuai_Shijian_Renwu_Info nbsri = item1
								.getModelObject();
						item1.add(new ExternalLink("rw-data-title", nbsri
								.getUrl(), nbsri.getTitle()));
						item1.add(new Label("rw-data-content", nbsri
								.getContent()));
						item1.add(new Label("rw-data-source", nbsri.getSource()));
						// 添加至待处理
						AjaxButton rwDealBT = new AjaxButton("rw-deal") {

							@Override
							public void onSubmit(AjaxRequestTarget target,
									Form form) {
								System.out.println("------ Deal RENWU!");
								N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
										currentUser.getU_mongoDB());
								nudbo.addToAttentionCollection(nbsri);
								target.add(jkRWPZContainer);
							}
						};
						item1.add(rwDealBT);
					}
				};
				item.add(renwuDataView);
			}
		};
		jkRWGZForm.add(renwuListView);
		jkRWGZContainer.add(jkRWGZForm);
		//
		if (pageTag != null && confirmed == true
				&& pageTag.equals(N_Constants.PAGE_TAG_JK_RENWUGENZONG))
			jkRWGZContainer.setVisible(true);
		else
			jkRWGZContainer.setVisible(false);
		this.add(jkRWGZContainer);
		/*-----------------------------BKPZ-----------------------------------------*/
		jkBKPZContainer = new WebMarkupContainer("jk-BKPZ-Container");
		jkBKPZContainer.setOutputMarkupId(true);
		//
		Form<String> bankuaiForm = new Form<String>("bankuaiForm");
		// 添加新的版块
		final TextField<String> bankuaiNameTF = new TextField<String>(
				"bankuaiNameTF", new Model<String>(""));
		bankuaiForm.add(bankuaiNameTF);
		final TextField<String> bankuaiTagsTF = new TextField<String>(
				"bankuaiTagsTF", new Model<String>(""));
		bankuaiForm.add(bankuaiTagsTF);
		AjaxButton bankuaiAddBT = new AjaxButton("bankuaiAddButton") {

			public void onSubmit(AjaxRequestTarget target, Form form) {
				//
				System.out.println("------ Button : add new bankuai!");
				N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
						currentUser.getU_mongoDB());
				String bankuaiName = bankuaiNameTF
						.getDefaultModelObjectAsString();
				List<String> tags = new ArrayList<String>();
				String bankuaitags = bankuaiTagsTF
						.getDefaultModelObjectAsString();
				StringTokenizer st = new StringTokenizer(bankuaitags, " ");
				while (st.hasMoreTokens()) {
					String tag = st.nextToken();
					if (tag != null && tag.equals("") == false)
						tags.add(tag);
				}
				boolean result = false;
				if (bankuaiName != null && bankuaiName.equals("") == false
						&& tags != null && tags.size() > 0)
					result = nudbo.createNewBanKuai(bankuaiName, tags,
							N_CONFIG.TYPE_BANKUAI);
				if (result)
					bankuaiInfo = "添加成功！";
				else
					bankuaiInfo = "添加失败或者已存在！";
				target.add(jkBKPZContainer);
			}
		};
		bankuaiForm.add(bankuaiAddBT);
		Label bankuaiInfoLabel = new Label("bankuaiInfo",
				new PropertyModel<String>(this, "bankuaiInfo"));
		bankuaiForm.add(bankuaiInfoLabel);
		// 编辑已有的版块
		final LoadableDetachableModel<List<String>> existedBanKuaiList = new LoadableDetachableModel<List<String>>() {
			private static final long serialVersionUID = -48454242192738597L;

			@Override
			protected List<String> load() {
				N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
						currentUser.getU_mongoDB());
				if (currentUser != null
						&& confirmed
						&& pageTag != null
						&& pageTag
								.equals(N_Constants.PAGE_TAG_JK_BANKUAIPEIZHI))
					return nudbo.getAllBanKuaiList(N_CONFIG.TYPE_BANKUAI);
				else
					return null;
			}
		};
		final ListView<String> existedBanKuaiView = new ListView<String>(
				"existedBanKuaiList", existedBanKuaiList) {
			private static final long serialVersionUID = -7153295502811467665L;

			@Override
			protected void populateItem(ListItem<String> item) {
				final String bankuaiName = item.getModelObject();
				Label bkNameLabel = new Label("bankuaiName", bankuaiName);
				item.add(bkNameLabel);
				N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
						currentUser.getU_mongoDB());
				List<String> tags = nudbo.getBanKuaiTags(bankuaiName,
						N_CONFIG.TYPE_BANKUAI);
				String tagsStr = "";
				for (int i = 0; i < tags.size(); i++) {
					tagsStr += tags.get(i);
					tagsStr += " ";
				}
				final TextField<String> bkTagsTF = new TextField<String>(
						"bankuaiTags", new Model<String>(tagsStr));
				// bkTagsTF.setModelObject("");
				item.add(bkTagsTF);
				//
				// 更新版块信息 link
				AjaxButton bkUpdateBT = new AjaxButton("bankuaiUpdate") {

					public void onSubmit(AjaxRequestTarget target, Form form) {
						System.out.println("------ UPDATE BANKUAI!!!");
						N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
								currentUser.getU_mongoDB());
						List<String> newtags = new ArrayList<String>();
						String bankuaitags = bkTagsTF
								.getDefaultModelObjectAsString();
						StringTokenizer st = new StringTokenizer(bankuaitags,
								" ");
						while (st.hasMoreTokens()) {
							String tag = st.nextToken();
							if (tag != null && tag.equals("") == false)
								newtags.add(tag);
						}
						System.out.println("newTags: " + newtags);
						boolean result = nudbo.updateBanKuaiTags(bankuaiName,
								newtags, N_CONFIG.TYPE_BANKUAI);
						if (result)
							bankuaiInfo = "更新成功！";
						else
							bankuaiInfo = "更新失败！";
						target.add(jkBKPZContainer);
					}
				};
				item.add(bkUpdateBT);
				// 删除版块 link
				AjaxButton bkDeleteBT = new AjaxButton("bankuaiDelete") {

					@Override
					public void onSubmit(AjaxRequestTarget target, Form form) {
						System.out.println("------ DELETE BANKUAI!");
						N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
								currentUser.getU_mongoDB());
						boolean result = nudbo.deleteBanKuaiTags(bankuaiName,
								N_CONFIG.TYPE_BANKUAI);
						if (result)
							bankuaiInfo = "删除成功！";
						else
							bankuaiInfo = "删除失败！";
						target.add(jkBKPZContainer);
					}
				};
				item.add(bkDeleteBT);
			}
		};
		bankuaiForm.add(existedBanKuaiView);
		// 更新版块信息 link
		AjaxLink zhankaiBankuaiLink = new AjaxLink("zhankai_bankuai") {

			@Override
			public void onClick(AjaxRequestTarget target) {
				if (existedBanKuaiView.isVisible())
					existedBanKuaiView.setVisible(false);
				else
					existedBanKuaiView.setVisible(true);
				target.add(jkBKPZContainer);
			}
		};
		bankuaiForm.add(zhankaiBankuaiLink);
		//
		jkBKPZContainer.add(bankuaiForm);
		//
		if (pageTag != null && confirmed == true
				&& pageTag.equals(N_Constants.PAGE_TAG_JK_BANKUAIPEIZHI))
			jkBKPZContainer.setVisible(true);
		else
			jkBKPZContainer.setVisible(false);
		this.add(jkBKPZContainer);
		/*-------------------------------wzpz 网址配置---------------------------------------*/
		jkWZPZContainer = new WebMarkupContainer("jk-WZPZ-Container");
		jkWZPZContainer.setOutputMarkupId(true);
		//
		Form<String> wangzhiForm = new Form<String>("wangzhiForm");
		// 添加新的版块
		final TextField<String> wangzhiNameTF = new TextField<String>(
				"wangzhiNameTF", new Model<String>(""));
		wangzhiForm.add(wangzhiNameTF);
		final TextField<String> wangzhiUrlTF = new TextField<String>(
				"wangzhiUrlTF", new Model<String>(""));
		wangzhiForm.add(wangzhiUrlTF);
		final TextField<String> wangzhiExtraTF = new TextField<String>(
				"wangzhiExtraTF", new Model<String>(""));
		wangzhiForm.add(wangzhiExtraTF);
		AjaxButton wangzhiAddBT = new AjaxButton("wangzhiAddButton") {

			public void onSubmit(AjaxRequestTarget target, Form form) {
				//
				System.out.println("------ Button : add new wangzhi!");
				N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
						currentUser.getU_mongoDB());
				String wangzhiName = wangzhiNameTF
						.getDefaultModelObjectAsString();
				String wangzhiUrl = wangzhiUrlTF
						.getDefaultModelObjectAsString();
				String wangzhiExtra = wangzhiExtraTF
						.getDefaultModelObjectAsString();
				boolean result = false;
				if (wangzhiName != null && wangzhiName.equals("") == false
						&& wangzhiUrl != null && wangzhiExtra != null)
					result = nudbo.createNewWangZhi(wangzhiName, wangzhiUrl,
							wangzhiExtra);
				if (result)
					wangzhiInfo = "添加成功！";
				else
					wangzhiInfo = "添加失败或者已存在！";
				target.add(jkWZPZContainer);
			}
		};
		wangzhiForm.add(wangzhiAddBT);
		Label wangzhiInfoLabel = new Label("wangzhiInfo",
				new PropertyModel<String>(this, "wangzhiInfo"));
		wangzhiForm.add(wangzhiInfoLabel);
		// 编辑已有的版块
		final LoadableDetachableModel<List<N_Wangzhi_Info>> existedwangzhiList = new LoadableDetachableModel<List<N_Wangzhi_Info>>() {

			@Override
			protected List<N_Wangzhi_Info> load() {
				N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
						currentUser.getU_mongoDB());
				if (currentUser != null
						&& confirmed
						&& pageTag != null
						&& pageTag
								.equals(N_Constants.PAGE_TAG_JK_WANGZHIPEIZHI))
					return nudbo.getAllWangZhiList();
				else
					return null;
			}
		};
		final ListView<N_Wangzhi_Info> existedwangzhiView = new ListView<N_Wangzhi_Info>(
				"existedwangzhiList", existedwangzhiList) {

			@Override
			protected void populateItem(ListItem<N_Wangzhi_Info> item) {
				final N_Wangzhi_Info wangzhi = item.getModelObject();
				item.add(new Label("wangzhiName", wangzhi.getName()));
				item.add(new Label("wangzhiUrl", wangzhi.getUrl()));
				item.add(new Label("wangzhiExtra", wangzhi.getExtra()));
				// 删除版块 link
				AjaxButton wzDeleteBT = new AjaxButton("wangzhiDelete") {

					@Override
					public void onSubmit(AjaxRequestTarget target, Form form) {
						System.out.println("------ DELETE wangzhi!");
						N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
								currentUser.getU_mongoDB());
						boolean result = nudbo.deleteWangZhi(wangzhi.getOid());
						if (result)
							wangzhiInfo = "删除成功！";
						else
							wangzhiInfo = "删除失败！";
						target.add(jkWZPZContainer);
					}
				};
				item.add(wzDeleteBT);
			}
		};
		wangzhiForm.add(existedwangzhiView);
		// 更新版块信息 link
		AjaxLink zhankaiwangzhiLink = new AjaxLink("zhankai_wangzhi") {

			@Override
			public void onClick(AjaxRequestTarget target) {
				if (existedwangzhiView.isVisible())
					existedwangzhiView.setVisible(false);
				else
					existedwangzhiView.setVisible(true);
				target.add(jkWZPZContainer);
			}
		};
		wangzhiForm.add(zhankaiwangzhiLink);
		jkWZPZContainer.add(wangzhiForm);
		//
		if (pageTag != null && confirmed == true
				&& pageTag.equals(N_Constants.PAGE_TAG_JK_WANGZHIPEIZHI))
			jkWZPZContainer.setVisible(true);
		else
			jkWZPZContainer.setVisible(false);
		this.add(jkWZPZContainer);
		/*--------------------------------SJPZ--------------------------------------*/
		/*--------------------------------事件配置--------------------------------------*/
		jkSJPZContainer = new WebMarkupContainer("jk-SJPZ-Container");
		jkSJPZContainer.setOutputMarkupId(true);
		//
		Form<String> shijianForm = new Form<String>("shijianForm");
		// 添加新的版块
		final TextField<String> shijianNameTF = new TextField<String>(
				"shijianNameTF", new Model<String>(""));
		shijianForm.add(shijianNameTF);
		final TextField<String> shijianTagsTF = new TextField<String>(
				"shijianTagsTF", new Model<String>(""));
		shijianForm.add(shijianTagsTF);
		AjaxButton shijianAddBT = new AjaxButton("shijianAddButton") {

			public void onSubmit(AjaxRequestTarget target, Form form) {
				//
				System.out.println("------ Button : add new shijian!");
				N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
						currentUser.getU_mongoDB());
				String shijianName = shijianNameTF
						.getDefaultModelObjectAsString();
				List<String> tags = new ArrayList<String>();
				String shijiantags = shijianTagsTF
						.getDefaultModelObjectAsString();
				StringTokenizer st = new StringTokenizer(shijiantags, " ");
				while (st.hasMoreTokens()) {
					String tag = st.nextToken();
					if (tag != null && tag.equals("") == false)
						tags.add(tag);
				}
				boolean result = false;
				if (shijianName != null && shijianName.equals("") == false
						&& tags != null && tags.size() > 0)
					result = nudbo.createNewBanKuai(shijianName, tags,
							N_CONFIG.TYPE_SHIJIAN);
				if (result)
					shijianInfo = "添加成功！";
				else
					shijianInfo = "添加失败或者已存在！";
				target.add(jkSJPZContainer);
			}
		};
		shijianForm.add(shijianAddBT);
		Label shijianInfoLabel = new Label("shijianInfo",
				new PropertyModel<String>(this, "shijianInfo"));
		shijianForm.add(shijianInfoLabel);
		// 编辑已有的版块
		final LoadableDetachableModel<List<String>> existedshijianList = new LoadableDetachableModel<List<String>>() {
			private static final long serialVersionUID = -48454242192738597L;

			@Override
			protected List<String> load() {
				N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
						currentUser.getU_mongoDB());
				if (currentUser != null
						&& confirmed
						&& pageTag != null
						&& pageTag
								.equals(N_Constants.PAGE_TAG_JK_SHIJIANPEIZHI))
					return nudbo.getAllBanKuaiList(N_CONFIG.TYPE_SHIJIAN);
				else
					return null;
			}
		};
		final ListView<String> existedshijianView = new ListView<String>(
				"existedshijianList", existedshijianList) {
			private static final long serialVersionUID = -7153295502811467665L;

			@Override
			protected void populateItem(ListItem<String> item) {
				final String shijianName = item.getModelObject();
				Label bkNameLabel = new Label("shijianName", shijianName);
				item.add(bkNameLabel);
				N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
						currentUser.getU_mongoDB());
				List<String> tags = nudbo.getBanKuaiTags(shijianName,
						N_CONFIG.TYPE_SHIJIAN);
				String tagsStr = "";
				for (int i = 0; i < tags.size(); i++) {
					tagsStr += tags.get(i);
					tagsStr += " ";
				}
				final TextField<String> bkTagsTF = new TextField<String>(
						"shijianTags", new Model<String>(tagsStr));
				// bkTagsTF.setModelObject("");
				item.add(bkTagsTF);
				//
				// 更新版块信息 link
				AjaxButton bkUpdateBT = new AjaxButton("shijianUpdate") {

					public void onSubmit(AjaxRequestTarget target, Form form) {
						System.out.println("------ UPDATE shijian!!!");
						N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
								currentUser.getU_mongoDB());
						List<String> newtags = new ArrayList<String>();
						String shijiantags = bkTagsTF
								.getDefaultModelObjectAsString();
						StringTokenizer st = new StringTokenizer(shijiantags,
								" ");
						while (st.hasMoreTokens()) {
							String tag = st.nextToken();
							if (tag != null && tag.equals("") == false)
								newtags.add(tag);
						}
						System.out.println("newTags: " + newtags);
						boolean result = nudbo.updateBanKuaiTags(shijianName,
								newtags, N_CONFIG.TYPE_SHIJIAN);
						if (result)
							shijianInfo = "更新成功！";
						else
							shijianInfo = "更新失败！";
						target.add(jkSJPZContainer);
					}
				};
				item.add(bkUpdateBT);
				// 删除版块 link
				AjaxButton bkDeleteBT = new AjaxButton("shijianDelete") {

					@Override
					public void onSubmit(AjaxRequestTarget target, Form form) {
						System.out.println("------ DELETE shijian!");
						N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
								currentUser.getU_mongoDB());
						boolean result = nudbo.deleteBanKuaiTags(shijianName,
								N_CONFIG.TYPE_SHIJIAN);
						if (result)
							shijianInfo = "删除成功！";
						else
							shijianInfo = "删除失败！";
						target.add(jkSJPZContainer);
					}
				};
				item.add(bkDeleteBT);
			}
		};
		shijianForm.add(existedshijianView);
		// 更新版块信息 link
		AjaxLink zhankaishijianLink = new AjaxLink("zhankai_shijian") {

			@Override
			public void onClick(AjaxRequestTarget target) {
				if (existedshijianView.isVisible())
					existedshijianView.setVisible(false);
				else
					existedshijianView.setVisible(true);
				target.add(jkSJPZContainer);
			}
		};
		shijianForm.add(zhankaishijianLink);
		jkSJPZContainer.add(shijianForm);
		//
		//
		if (pageTag != null && confirmed == true
				&& pageTag.equals(N_Constants.PAGE_TAG_JK_SHIJIANPEIZHI))
			jkSJPZContainer.setVisible(true);
		else
			jkSJPZContainer.setVisible(false);
		this.add(jkSJPZContainer);
		/*-------------------------------RWPZ---------------------------------------*/
		/*-------------------------------人物配置---------------------------------------*/
		jkRWPZContainer = new WebMarkupContainer("jk-RWPZ-Container");
		jkRWPZContainer.setOutputMarkupId(true);
		//
		Form<String> renwuForm = new Form<String>("renwuForm");
		// 添加新的版块
		final TextField<String> renwuNameTF = new TextField<String>(
				"renwuNameTF", new Model<String>(""));
		renwuForm.add(renwuNameTF);
		final TextField<String> renwuTagsTF = new TextField<String>(
				"renwuTagsTF", new Model<String>(""));
		renwuForm.add(renwuTagsTF);
		AjaxButton renwuAddBT = new AjaxButton("renwuAddButton") {

			public void onSubmit(AjaxRequestTarget target, Form form) {
				//
				System.out.println("------ Button : add new renwu!");
				N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
						currentUser.getU_mongoDB());
				String renwuName = renwuNameTF.getDefaultModelObjectAsString();
				List<String> tags = new ArrayList<String>();
				String renwutags = renwuTagsTF.getDefaultModelObjectAsString();
				StringTokenizer st = new StringTokenizer(renwutags, " ");
				while (st.hasMoreTokens()) {
					String tag = st.nextToken();
					if (tag != null && tag.equals("") == false)
						tags.add(tag);
				}
				boolean result = false;
				if (renwuName != null && renwuName.equals("") == false
						&& tags != null && tags.size() > 0)
					result = nudbo.createNewBanKuai(renwuName, tags,
							N_CONFIG.TYPE_RENWU);
				if (result)
					renwuInfo = "添加成功！";
				else
					renwuInfo = "添加失败或者已存在！";
				target.add(jkRWPZContainer);
			}
		};
		renwuForm.add(renwuAddBT);
		Label renwuInfoLabel = new Label("renwuInfo",
				new PropertyModel<String>(this, "renwuInfo"));
		renwuForm.add(renwuInfoLabel);
		// 编辑已有的版块
		final LoadableDetachableModel<List<String>> existedrenwuList = new LoadableDetachableModel<List<String>>() {
			private static final long serialVersionUID = -48454242192738597L;

			@Override
			protected List<String> load() {
				N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
						currentUser.getU_mongoDB());
				if (currentUser != null && confirmed && pageTag != null
						&& pageTag.equals(N_Constants.PAGE_TAG_JK_RENWUPEIZHI))
					return nudbo.getAllBanKuaiList(N_CONFIG.TYPE_RENWU);
				else
					return null;
			}
		};
		final ListView<String> existedrenwuView = new ListView<String>(
				"existedrenwuList", existedrenwuList) {
			private static final long serialVersionUID = -7153295502811467665L;

			@Override
			protected void populateItem(ListItem<String> item) {
				final String renwuName = item.getModelObject();
				Label bkNameLabel = new Label("renwuName", renwuName);
				item.add(bkNameLabel);
				N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
						currentUser.getU_mongoDB());
				List<String> tags = nudbo.getBanKuaiTags(renwuName,
						N_CONFIG.TYPE_RENWU);
				String tagsStr = "";
				for (int i = 0; i < tags.size(); i++) {
					tagsStr += tags.get(i);
					tagsStr += " ";
				}
				final TextField<String> bkTagsTF = new TextField<String>(
						"renwuTags", new Model<String>(tagsStr));
				// bkTagsTF.setModelObject("");
				item.add(bkTagsTF);
				//
				// 更新版块信息 link
				AjaxButton bkUpdateBT = new AjaxButton("renwuUpdate") {

					public void onSubmit(AjaxRequestTarget target, Form form) {
						System.out.println("------ UPDATE renwu!!!");
						N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
								currentUser.getU_mongoDB());
						List<String> newtags = new ArrayList<String>();
						String renwutags = bkTagsTF
								.getDefaultModelObjectAsString();
						StringTokenizer st = new StringTokenizer(renwutags, " ");
						while (st.hasMoreTokens()) {
							String tag = st.nextToken();
							if (tag != null && tag.equals("") == false)
								newtags.add(tag);
						}
						System.out.println("newTags: " + newtags);
						boolean result = nudbo.updateBanKuaiTags(renwuName,
								newtags, N_CONFIG.TYPE_RENWU);
						if (result)
							renwuInfo = "更新成功！";
						else
							renwuInfo = "更新失败！";
						target.add(jkRWPZContainer);
					}
				};
				item.add(bkUpdateBT);
				// 删除版块 link
				AjaxButton bkDeleteBT = new AjaxButton("renwuDelete") {

					@Override
					public void onSubmit(AjaxRequestTarget target, Form form) {
						System.out.println("------ DELETE renwu!");
						N_UDBO_BanKuai_ShiJian_RenWu nudbo = new N_UDBO_BanKuai_ShiJian_RenWu(
								currentUser.getU_mongoDB());
						boolean result = nudbo.deleteBanKuaiTags(renwuName,
								N_CONFIG.TYPE_RENWU);
						if (result)
							renwuInfo = "删除成功！";
						else
							renwuInfo = "删除失败！";
						target.add(jkRWPZContainer);
					}
				};
				item.add(bkDeleteBT);
			}
		};
		renwuForm.add(existedrenwuView);
		// 更新版块信息 link
		AjaxLink zhankairenwuLink = new AjaxLink("zhankai_renwu") {

			@Override
			public void onClick(AjaxRequestTarget target) {
				if (existedrenwuView.isVisible())
					existedrenwuView.setVisible(false);
				else
					existedrenwuView.setVisible(true);
				target.add(jkRWPZContainer);
			}
		};
		renwuForm.add(zhankairenwuLink);
		jkRWPZContainer.add(renwuForm);
		//
		//
		if (pageTag != null && confirmed == true
				&& pageTag.equals(N_Constants.PAGE_TAG_JK_RENWUPEIZHI))
			jkRWPZContainer.setVisible(true);
		else
			jkRWPZContainer.setVisible(false);
		this.add(jkRWPZContainer);
		/*----------------------------------------------------------------------*/

	}

	// ********************************//

	// ********************************//

	// ********************************//

	public String getBankuaiInfo() {
		return bankuaiInfo;
	}

	public void setBankuaiInfo(String bankuaiInfo) {
		this.bankuaiInfo = bankuaiInfo;
	}

	public String getShijianInfo() {
		return shijianInfo;
	}

	public void setShijianInfo(String shijianInfo) {
		this.shijianInfo = shijianInfo;
	}

	public String getRenwuInfo() {
		return renwuInfo;
	}

	public void setRenwuInfo(String renwuInfo) {
		this.renwuInfo = renwuInfo;
	}

	public String getWangzhiInfo() {
		return wangzhiInfo;
	}

	public void setWangzhiInfo(String wangzhiInfo) {
		this.wangzhiInfo = wangzhiInfo;
	}

	// ***------------------------------------------------------------------------------==//
	// 内部类 用于给分页dataview提供数据源
	public class bbsItemsDataProvider<N_BBSInfo> implements
			IDataProvider<N_BBSInfo> {
		/**
						 * 
						 */
		private static final long serialVersionUID = -4172302313201275383L;
		/** reference to the list used as dataprovider for the dataview */
		private List<N_BBSInfo> list;

		/**
		 * Constructs an empty provider. Useful for lazy loading together with
		 * {@linkplain #getData()}
		 */
		public bbsItemsDataProvider() {
			if (bbsRealTimeLDM == null) {
				throw new IllegalArgumentException(
						"argument [list] cannot be null");
			}
			// System.out.println("iDP");
			list = (List<N_BBSInfo>) bbsRealTimeLDM.getObject();
			System.out.println("------bbs list size is :  " + list.size());
		}

		/**
		 * 
		 * @param list
		 *            the list used as dataprovider for the dataview
		 */
		public bbsItemsDataProvider(List<N_BBSInfo> list) {
			if (list == null) {
				throw new IllegalArgumentException(
						"argument [list] cannot be null");
			}
			this.list = list;
		}

		/**
		 * Subclass to lazy load the list
		 * 
		 * @return The list
		 */
		protected List<N_BBSInfo> getData() { // 获取数据源 根据docList动态变化
			// System.out.println("getdata()");
			if (bbsUpdateFlag == true) {
				bbsRealTimeLDM.detach();
				bbsUpdateFlag = false;
			}
			list = (List<N_BBSInfo>) bbsRealTimeLDM.getObject();
			return list;
		}
		
		//做分页处理
		@Override
		public Iterator<N_BBSInfo> iterator(final long first, final long count) {
			List<N_BBSInfo> list = getData();

			long toIndex = first + count;
			if (toIndex > list.size()) {
				toIndex = list.size();
			}
			return list.subList((int) first, (int) toIndex).listIterator();
		}

		/**
		 * @see IDataProvider#size()
		 */
		@Override
		public long size() {
			return getData().size();
		}

		/**
		 * @see IDataProvider#model(Object)
		 */
		@Override
		public IModel<N_BBSInfo> model(N_BBSInfo object) {
			return new Model((Serializable) object);
		}

		/**
		 * @see org.apache.wicket.model.IDetachable#detach()
		 */
		@Override
		public void detach() {
		}
	};

	// ***------------------------------------------------------------------------------==//
	// 内部类 用于给分页dataview提供数据源
	public class npItemsDataProvider<N_NewsPaperInfo> implements
			IDataProvider<N_NewsPaperInfo> {
		/**
							 * 
							 */
		private static final long serialVersionUID = 4819189866584976986L;
		/** reference to the list used as dataprovider for the dataview */
		private List<N_NewsPaperInfo> list;

		/**
		 * Constructs an empty provider. Useful for lazy loading together with
		 * {@linkplain #getData()}
		 */
		public npItemsDataProvider() {
			if (npRealTimeLDM == null) {
				throw new IllegalArgumentException(
						"argument [list] cannot be null");
			}
			// System.out.println("iDP");
			list = (List<N_NewsPaperInfo>) npRealTimeLDM.getObject();
			System.out
					.println("------NewsPaper list size is :  " + list.size());
		}

		/**
		 * 
		 * @param list
		 *            the list used as dataprovider for the dataview
		 */
		public npItemsDataProvider(List<N_NewsPaperInfo> list) {
			if (list == null) {
				throw new IllegalArgumentException(
						"argument [list] cannot be null");
			}
			this.list = list;
		}

		/**
		 * Subclass to lazy load the list
		 * 
		 * @return The list
		 */
		protected List<N_NewsPaperInfo> getData() { // 获取数据源 根据docList动态变化
			// System.out.println("getdata()");
			if (newspaperUpdateFlag == true) {
				npRealTimeLDM.detach();
				newspaperUpdateFlag = false;
			}
			list = (List<N_NewsPaperInfo>) npRealTimeLDM.getObject();
			return list;
		}

		@Override
		public Iterator<N_NewsPaperInfo> iterator(final long first,
				final long count) {
			List<N_NewsPaperInfo> list = getData();

			long toIndex = first + count;
			if (toIndex > list.size()) {
				toIndex = list.size();
			}
			return list.subList((int) first, (int) toIndex).listIterator();
		}

		/**
		 * @see IDataProvider#size()
		 */
		@Override
		public long size() {
			return getData().size();
		}

		/**
		 * @see IDataProvider#model(Object)
		 */
		@Override
		public IModel<N_NewsPaperInfo> model(N_NewsPaperInfo object) {
			return new Model((Serializable) object);
		}

		/**
		 * @see org.apache.wicket.model.IDetachable#detach()
		 */
		@Override
		public void detach() {
		}
	};

	// ***------------------------------------------------------------------------------==//
	// 内部类 用于给分页dataview提供数据源
	public class weiboItemsDataProvider<N_WeiboInfo> implements
			IDataProvider<N_WeiboInfo> {
		/**
		 * 
		 */
		private static final long serialVersionUID = -506294168847023859L;
		/**
									 * 
									 */
		/** reference to the list used as dataprovider for the dataview */
		private List<N_WeiboInfo> list;

		/**
		 * Constructs an empty provider. Useful for lazy loading together with
		 * {@linkplain #getData()}
		 */
		public weiboItemsDataProvider() {
			if (weiboRealTimeLDM == null) {
				throw new IllegalArgumentException(
						"argument [list] cannot be null");
			}
			// System.out.println("iDP");
			list = (List<N_WeiboInfo>) weiboRealTimeLDM.getObject();
			System.out.println("------Weibo list size is :  " + list.size());
		}

		/**
		 * 
		 * @param list
		 *            the list used as dataprovider for the dataview
		 */
		public weiboItemsDataProvider(List<N_WeiboInfo> list) {
			if (list == null) {
				throw new IllegalArgumentException(
						"argument [list] cannot be null");
			}
			this.list = list;
		}

		/**
		 * Subclass to lazy load the list
		 * 
		 * @return The list
		 */
		protected List<N_WeiboInfo> getData() { // 获取数据源 根据docList动态变化
			// System.out.println("getdata()");
			if (weiboUpdateFlag == true) {
				weiboRealTimeLDM.detach();
				weiboUpdateFlag = false;
			}
			list = (List<N_WeiboInfo>) weiboRealTimeLDM.getObject();
			return list;
		}

		@Override
		public Iterator<N_WeiboInfo> iterator(final long first, final long count) {
			List<N_WeiboInfo> list = getData();

			long toIndex = first + count;
			if (toIndex > list.size()) {
				toIndex = list.size();
			}
			return list.subList((int) first, (int) toIndex).listIterator();
		}

		/**
		 * @see IDataProvider#size()
		 */
		@Override
		public long size() {
			return getData().size();
		}

		/**
		 * @see IDataProvider#model(Object)
		 */
		@Override
		public IModel<N_WeiboInfo> model(N_WeiboInfo object) {
			return new Model((Serializable) object);
		}

		/**
		 * @see org.apache.wicket.model.IDetachable#detach()
		 */
		@Override
		public void detach() {
		}
	};

	// ***------------------------------------------------------------------------------==//
	// 内部类 用于给分页dataview提供数据源
	public class newsItemsDataProvider<N_NewsInfo> implements
			IDataProvider<N_NewsInfo> {
		/**
			 * 
			 */
		private static final long serialVersionUID = -7290590058567829255L;
		/**
										 * 
										 */
		/** reference to the list used as dataprovider for the dataview */
		private List<N_NewsInfo> list;

		/**
		 * Constructs an empty provider. Useful for lazy loading together with
		 * {@linkplain #getData()}
		 */
		public newsItemsDataProvider() {
			if (newsRealTimeLDM == null) {
				throw new IllegalArgumentException(
						"argument [list] cannot be null");
			}
			// System.out.println("iDP");
			list = (List<N_NewsInfo>) newsRealTimeLDM.getObject();
			System.out.println("------News list size is :  " + list.size());
		}

		/**
		 * 
		 * @param list
		 *            the list used as dataprovider for the dataview
		 */
		public newsItemsDataProvider(List<N_NewsInfo> list) {
			if (list == null) {
				throw new IllegalArgumentException(
						"argument [list] cannot be null");
			}
			this.list = list;
		}

		/**
		 * Subclass to lazy load the list
		 * 
		 * @return The list
		 */
		protected List<N_NewsInfo> getData() { // 获取数据源 根据docList动态变化
			// System.out.println("getdata()");
			if (newsUpdateFlag == true) {
				newsRealTimeLDM.detach();
				newsUpdateFlag = false;
			}
			list = (List<N_NewsInfo>) newsRealTimeLDM.getObject();
			return list;
		}

		@Override
		public Iterator<N_NewsInfo> iterator(final long first, final long count) {
			// System.out.println("iterator");
			List<N_NewsInfo> list = getData();

			long toIndex = first + count;
			if (toIndex > list.size()) {
				toIndex = list.size();
			}
			return list.subList((int) first, (int) toIndex).listIterator();
		}

		/**
		 * @see IDataProvider#size()
		 */
		@Override
		public long size() {
			// System.out.println("size");
			return getData().size();
		}

		/**
		 * @see IDataProvider#model(Object)
		 */
		@Override
		public IModel<N_NewsInfo> model(N_NewsInfo object) {
			// System.out.println("model");
			return new Model((Serializable) object);
		}

		/**
		 * @see org.apache.wicket.model.IDetachable#detach()
		 */
		@Override
		public void detach() {
			// System.out.println("detach");
		}
	};
}
