package newSnas2;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import newBasic.N_User;
import newConstants.N_Constants;
import newMongoDB.N_UserOperation;

import org.apache.wicket.Application;
import org.apache.wicket.Session;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.PasswordTextField;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.model.Model;
import org.apache.wicket.settings.def.ApplicationSettings;

public class NewLogin extends WebPage {
	private static final long serialVersionUID = 3110180328206631770L;
	private Session mySession = super.getSession();

	static {
		// **********设置错误页面转到登陆页面**********
//		Application appli = Application.get();
//		ApplicationSettings sett = (ApplicationSettings) appli.getApplicationSettings();
//		NewIndex newIndex = new NewIndex();
//		sett.setPageExpiredErrorPage(newIndex.getClass());
//		sett.setInternalErrorPage(newIndex.getClass());
//		sett.setAccessDeniedPage(newIndex.getClass());
		// *********************
	}

	public NewLogin() {
		System.out.println("------------------------ ENTER INTO 登录 注册 ------------------------");
		//
		this.add(new Link("linkToIndex-logo") {

			@Override
			public void onClick() {
				setResponsePage(NewIndex.class);
			}
		});
		// DATE
		Date currentDate = new Date();
		Locale loCn = new Locale("zh", "CN");
		String sDate = DateFormat.getDateInstance(DateFormat.FULL, loCn).format(currentDate);
		Label dateLabel = new Label("date", sDate);
		this.add(dateLabel);
		//
		// -----------------*user login *------------------------------//
		final Form<String> userLoginForm = new Form<String>("userLoginForm");
		final TextField<String> userLoginName = new TextField<String>("userLoginName", new Model<String>(""));
		final PasswordTextField userLoginPwd = new PasswordTextField("userLoginPwd", new Model<String>(""));
		userLoginForm.add(userLoginName);
		userLoginForm.add(userLoginPwd);
		Button userLoginBT = new Button("userLoginBT") {
			private static final long serialVersionUID = 5723400945666428371L;

			public void onSubmit() {
				String uName = userLoginName.getDefaultModelObjectAsString();
				String uPwd = userLoginPwd.getDefaultModelObjectAsString();
				N_UserOperation nuo = new N_UserOperation();
				boolean existed = nuo.checkUserIsExisted(uName, uPwd);
				boolean login = nuo.checkUserLogin(uName);
				if (existed) { // 账户存在且未重复登录
					N_User currentU = nuo.getUserAllInfo(uName, uPwd);
					mySession.setAttribute("currentUser", currentU);
					mySession.setAttribute("role", N_Constants.USER_ROLE_USER);
					mySession.removeAttribute("loginError");
					nuo.changeUserLogin(uName, true);
					System.out.println("---user login successfully!!! " + uName);
					setResponsePage(NewJiankong.class);
				} else {
					mySession.setAttribute("loginError", "yes");
					System.out.println("---user login failed!!! " + uName);
				}

			}
		};
		userLoginForm.add(userLoginBT);
		// --------------------------------------------------//
		Label infoLabel;
		if (mySession.getAttribute("loginError") != null) {
			infoLabel = new Label("loginInfo", "账户密码有错！");
			// mySession.removeAttribute("loginError");
		} else {
			infoLabel = new Label("loginInfo", "未登录！");
		}
		userLoginForm.add(infoLabel);
		//
		this.add(userLoginForm);
		//
		// -----------------*user register *------------------------------//
		final Form<String> userRegForm = new Form<String>("userRegForm");
		final TextField<String> userRegName = new TextField<String>("userRegName", new Model<String>(""));
		final TextField<String> userRegPwd = new TextField<String>("userRegPwd", new Model<String>(""));
		userRegForm.add(userRegName);
		userRegForm.add(userRegPwd);
		Button userRegBT = new Button("userRegBT") {
			private static final long serialVersionUID = -6580709270575308573L;

			public void onSubmit() {
				String uName = userRegName.getDefaultModelObjectAsString();
				String uPwd = userRegPwd.getDefaultModelObjectAsString();
				N_UserOperation nuo = new N_UserOperation();
				boolean reg = false;
				if (uName != null && uName.length() > 0 && uPwd != null && uPwd.length() > 0)
					reg = nuo.registerNewUser(uName, uPwd, N_Constants.USER_ROLE_USER);
				if (reg) {
					N_User currentU = nuo.getUserAllInfo(uName, uPwd);
					mySession.setAttribute("currentUser", currentU);
					mySession.setAttribute("role", N_Constants.USER_ROLE_REG);
					mySession.removeAttribute("loginError");
					nuo.changeUserLogin(uName, true);
					System.out.println("---user register successfully!!! " + uName);
					setResponsePage(NewPeizhi.class);
				} else {
					mySession.setAttribute("loginError", "yes");
					System.out.println("---user register failed!!! " + uName);
				}

			}
		};
		userRegForm.add(userRegBT);
		this.add(userRegForm);

	}
}
