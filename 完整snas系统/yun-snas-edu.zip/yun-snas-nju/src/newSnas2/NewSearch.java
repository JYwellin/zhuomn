package newSnas2;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.StringTokenizer;

import newBasic.N_BBSInfo;
import newBasic.N_NewsInfo;
import newBasic.N_NewsPaperInfo;
import newBasic.N_User;
import newBasic.N_WeiboInfo;
import newConstants.N_Constants;
import newConstants.N_DataBuffer;

import org.apache.wicket.Session;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.link.ExternalLink;
import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.model.LoadableDetachableModel;
import org.apache.wicket.model.Model;
import org.apache.wicket.model.PropertyModel;
import org.apache.wicket.request.mapper.parameter.PageParameters;

public class NewSearch extends WebPage {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6767185361454567850L;
	private Session mySession = super.getSession();
	public N_User currentUser = (N_User) mySession.getAttribute("currentUser");

	private boolean search = false;

	// weibo
	public int weiboResultsNum = 0;

	// bbs
	public int bbsResultsNum = 0;

	// news
	public int newsResultsNum = 0;

	// newspaper
	public int newspaperResultsNum = 0;

	public NewSearch(PageParameters parameters) {
		System.out
				.println("------------------------ ENTER INTO 全站搜索 PAGE ------------------------");
		// DATE
		Date currentDate = new Date();
		Locale loCn = new Locale("zh", "CN");
		String sDate = DateFormat.getDateInstance(DateFormat.FULL, loCn)
				.format(currentDate);
		Label dateLabel = new Label("date", sDate);
		this.add(dateLabel);
		// 导航
		this.add(new Label("userName", currentUser.getU_name()));
		this.add(new Link("loginOut") {

			@Override
			public void onClick() {
				mySession.removeAttribute("currentUser");
				setResponsePage(NewLogin.class);
			}
		});
		this.add(new Link("linkToJianKong") {

			@Override
			public void onClick() {
				setResponsePage(NewJiankong.class);
			}
		});
		this.add(new Link("linkToFenXi") {

			@Override
			public void onClick() {
				setResponsePage(NewFenxi.class);
			}
		});
		this.add(new Link("linkToBaoGao") {

			@Override
			public void onClick() {
				setResponsePage(NewBaogao.class);
			}
		});
		this.add(new Link("linkToPeiZhi") {

			@Override
			public void onClick() {
				setResponsePage(NewPeizhi.class);
			}
		});
		//
		// ////////////////////////////////////////////////////////////////////////////////////////////////
		final Form<String> searchForm = new Form<String>("search-form");
		// 全站检索
		final TextField<String> searchTextField = new TextField<String>(
				"searchInput", new Model<String>());
		searchTextField.setRequired(false);
		searchForm.add(searchTextField);

		searchForm.add(new Button("searchButton") {

			/**
	 * 
	 */
			private static final long serialVersionUID = 6384053811667019071L;

			public void onSubmit() {
				String searchText = searchTextField
						.getDefaultModelObjectAsString();

				if (searchText != null && searchText.length() >= 1) {
					PageParameters para = new PageParameters(); // 参数
					para.add("search", searchText);
					setResponsePage(NewSearch.class, para); // 转向search页面
				}
			}
		});
		this.add(searchForm);
		// ////////////////////////////////////////////////////////////////////////////////////////////////
		String searchText = parameters.get("search").toString();
		final List<String> keys = new ArrayList<String>();
		if (searchText != null) {
			this.add(new Label("searchText", searchText));
			StringTokenizer st = new StringTokenizer(searchText, " ");
			while (st.hasMoreTokens()) {
				keys.add(st.nextToken());
			}
			search = true;
		} else {
			this.add(new Label("searchText", ""));
		}
		// ------------------------------------------------------------------------------//
		final List<N_WeiboInfo> weiboList = new ArrayList<N_WeiboInfo>();

		/* ======================weibo search result======================== */
		LoadableDetachableModel<List<N_WeiboInfo>> weiboResultList = new LoadableDetachableModel<List<N_WeiboInfo>>() {

			@Override
			protected List<N_WeiboInfo> load() {
				System.out.println("加载微博搜索结果："+ N_DataBuffer.weiboDataBuffer.size());
				for (int i = 0; i < N_DataBuffer.weiboDataBuffer.size(); i++) {
					N_WeiboInfo w = N_DataBuffer.weiboDataBuffer.get(i);
					boolean satisfied = false;
					for (int j = 0; j < keys.size(); j++) {
						String key = keys.get(j);
						if (w.getContent().contains(key) || w.getKeyWords().contains(key)) {
							satisfied = true;
							break;
						}
					}
					if (satisfied && search) {
						weiboList.add(w);
						weiboResultsNum++;
					}
				}
				//
				return weiboList;
			}
		};
		// weibo hot messages
		final ListView<N_WeiboInfo> weiboResultListView = new ListView<N_WeiboInfo>(
				"weiboResultsList", weiboResultList) {

			/**
			 * 
			 */
			private static final long serialVersionUID = -6788186636334034421L;

			@Override
			protected void populateItem(ListItem<N_WeiboInfo> item) {
				N_WeiboInfo weibo = item.getModelObject();
				String weiboContent = weibo.getContent();
				String url = weibo.getUrl();
				String time = weibo.getTime();
				int zhuanfaliang = weibo.getForward();
				// keywords
				List<String> tags = new ArrayList<String>();
				tags = weibo.getKeyWords();
				String keywords = "";
				for (int i = 0; i < tags.size(); i++) {
					keywords += tags.get(i);
					if (i < tags.size() - 1)
						keywords += " ";
				}
				int commentNum = weibo.getComment();
				//

				ExternalLink eLink = new ExternalLink("weiboTitle", url,
						weiboContent + "...");
				item.add(eLink);
				//
				item.add(new Label("weiboKeyWords", keywords));
				item.add(new Label("weiboTime", time));
				item.add(new Label("weiboZhuanfa", "" + zhuanfaliang));
				item.add(new Label("weiboComment", "" + commentNum));
			}
		};
		this.add(weiboResultListView);
		// 微博搜索结果总数
		Label weiboSearchNumLabel = new Label("weiboResultsNum",
				new PropertyModel<Integer>(this, "weiboResultsNum"));
		this.add(weiboSearchNumLabel);
		//
		// ///////////////////////////////////////////////////////////////////////////////////////////////////
		// ------------------------------------------------------------------------------//
		final List<N_BBSInfo> bbsList = new ArrayList<N_BBSInfo>();

		/* ======================bbs search result======================== */
		LoadableDetachableModel<List<N_BBSInfo>> bbsResultsList = new LoadableDetachableModel<List<N_BBSInfo>>() {

			@Override
			protected List<N_BBSInfo> load() {
				System.out.println("加载论坛搜索结果："
						+ N_DataBuffer.bbsDataBuffer.size());
				for (int i = 0; i < N_DataBuffer.bbsDataBuffer.size(); i++) {
					N_BBSInfo w = N_DataBuffer.bbsDataBuffer.get(i);
					boolean satisfied = false;
					for (int j = 0; j < keys.size(); j++) {
						String key = keys.get(j);
						if (w.getContent().contains(key)
								|| w.getTitle().contains(key)
								|| w.getSource().contains(key)
								|| w.getTags().contains(key)) {
							satisfied = true;
							break;
						}
					}
					if (satisfied && search) {
						bbsList.add(w);
						bbsResultsNum++;
					}
				}
				//
				return bbsList;
			}
		};
		// bbs hot messages
		final ListView<N_BBSInfo> bbsResultsListView = new ListView<N_BBSInfo>(
				"bbsResultsList", bbsResultsList) {

			/**
					 * 
					 */
			private static final long serialVersionUID = -6788186636334034421L;

			@Override
			protected void populateItem(ListItem<N_BBSInfo> item) {
				N_BBSInfo bbs = item.getModelObject();
				String url = bbs.getUrl();
				String time = bbs.getTime();
				String source = bbs.getSource();
				String source_url = bbs.getSource_url();
				String title = bbs.getTitle();
				int reply = bbs.getReplyNum();
				int click = bbs.getClickNum();
				double attention = bbs.getAttention();
				String sentiment = bbs.getSentiment();
				if (sentiment.equals(N_Constants.SENTIMENT_POSITIVE))
					sentiment = "正面";
				else if (sentiment.equals(N_Constants.SENTIMENT_NEGATIVE))
					sentiment = "负面";
				else
					sentiment = "中立";
				List<String> tags = bbs.getTags();
				String tagsStr = "";
				for (int i = 0; i < tags.size(); i++)
					tagsStr += tags.get(i) + " ";
				item.add(new ExternalLink("bbsTitle", url, title));
				item.add(new Label("bbsTags", tagsStr));
				item.add(new Label("bbsTime", time));
				item.add(new ExternalLink("bbsSource", source_url, source));
				item.add(new Label("bbsReply", "" + reply));
				item.add(new Label("bbsClick", "" + click));
				item.add(new Label("bbsAttention", "" + attention));
				item.add(new Label("bbsSentiment", "" + sentiment));
			}
		};
		this.add(bbsResultsListView);
		// 微博搜索结果总数
		Label bbsSearchNumLabel = new Label("bbsResultsNum",
				new PropertyModel<Integer>(this, "bbsResultsNum"));
		this.add(bbsSearchNumLabel);
		//

		// /////////////////////////////////////////////////////////news//////////////////////////////////////////////////////////////////////
		// ------------------------------------------------------------------------------//
		final List<N_NewsInfo> NewsList = new ArrayList<N_NewsInfo>();

		/* ======================News search result======================== */
		LoadableDetachableModel<List<N_NewsInfo>> NewsResultList = new LoadableDetachableModel<List<N_NewsInfo>>() {

			@Override
			protected List<N_NewsInfo> load() {
				System.out.println("加载门户新闻搜索结果："
						+ N_DataBuffer.newsDataBuffer.size());
				for (int i = 0; i < N_DataBuffer.newsDataBuffer.size(); i++) {
					N_NewsInfo w = N_DataBuffer.newsDataBuffer.get(i);
					boolean satisfied = false;
					for (int j = 0; j < keys.size(); j++) {
						String key = keys.get(j);
						if (w.getTitle().contains(key)
								|| w.getContent().contains(key)
								|| w.getTags().contains(key)
								|| w.getSource().contains(key)) {
							satisfied = true;
							break;
						}
					}
					if (satisfied && search) {
						NewsList.add(w);
						newsResultsNum++;
					}
				}
				//
				return NewsList;
			}
		};
		// News hot messages
		final ListView<N_NewsInfo> NewsResultListView = new ListView<N_NewsInfo>(
				"newsResultsList", NewsResultList) {

			@Override
			protected void populateItem(ListItem<N_NewsInfo> item) {
				N_NewsInfo news = item.getModelObject();
				String title = news.getTitle();
				String content = news.getContent();
				if (content.length() > N_Constants.MAX_CONTENT_LENGTH) {
					content = content.substring(0,
							N_Constants.MAX_CONTENT_LENGTH - 1);
					content += " ......";
				}
				//
				final String time = news.getTime();
				String source = news.getSource();
				String sourceUrl = news.getSourceUrl();
				String sentiment = news.getSentiment();
				if (sentiment.equals(N_Constants.SENTIMENT_POSITIVE))
					sentiment = "正面";
				else if (sentiment.equals(N_Constants.SENTIMENT_NEGATIVE))
					sentiment = "负面";
				else
					sentiment = "中立";
				String url = news.getUrl();
				List<String> tags = news.getTags();
				String tagsStr = "";
				for (int i = 0; i < tags.size(); i++)
					tagsStr += tags.get(i) + " ";
				//
				//
				ExternalLink eLink = new ExternalLink("news-title", url, title);
				item.add(eLink);
				item.add(new Label("news-content", content));
				//
				item.add(new Label("news-keywords", tagsStr));
				item.add(new Label("news-time", time));
				ExternalLink sourceLink = new ExternalLink("news-source",
						sourceUrl, source);
				item.add(sourceLink);
				item.add(new Label("news-sentiment", "" + sentiment));
			}
		};
		this.add(NewsResultListView);
		// 门户新闻搜索结果总数
		Label newsSearchNumLabel = new Label("newsResultsNum",
				new PropertyModel<Integer>(this, "newsResultsNum"));
		this.add(newsSearchNumLabel);
		//
		// //////////////////////////////////////////////////////////////newspaper//////////////////////////////////////////////////////////////////
		// ------------------------------------------------------------------------------//
		final List<N_NewsPaperInfo> NewspaperList = new ArrayList<N_NewsPaperInfo>();

		/* ======================News search result======================== */
		LoadableDetachableModel<List<N_NewsPaperInfo>> NewspaperResultList = new LoadableDetachableModel<List<N_NewsPaperInfo>>() {

			@Override
			protected List<N_NewsPaperInfo> load() {
				System.out.println("加载媒体报刊搜索结果："
						+ N_DataBuffer.npDataBuffer.size());
				for (int i = 0; i < N_DataBuffer.npDataBuffer.size(); i++) {
					N_NewsPaperInfo w = N_DataBuffer.npDataBuffer.get(i);
					boolean satisfied = false;
					for (int j = 0; j < keys.size(); j++) {
						String key = keys.get(j);
						if (w.getTitle().contains(key)
								|| w.getContent().contains(key)
								|| w.getTags().contains(key)
								|| w.getSource().contains(key)) {
							satisfied = true;
							break;
						}
					}
					if (satisfied && search) {
						NewspaperList.add(w);
						newspaperResultsNum++;
					}
				}
				//
				return NewspaperList;
			}
		};
		// News hot messages
		final ListView<N_NewsPaperInfo> NewspaperResultListView = new ListView<N_NewsPaperInfo>(
				"newspaperResultsList", NewspaperResultList) {

			@Override
			protected void populateItem(ListItem<N_NewsPaperInfo> item) {
				N_NewsPaperInfo np = item.getModelObject();
				String title = np.getTitle();
				String content = np.getContent();
				if (content.length() > N_Constants.MAX_CONTENT_LENGTH) {
					content = content.substring(0,
							N_Constants.MAX_CONTENT_LENGTH - 1);
					content += " ......";
				}
				//
				final String time = np.getTime();
				String source = np.getSource();
				String sentiment = np.getSentiment();
				if (sentiment.equals(N_Constants.SENTIMENT_POSITIVE))
					sentiment = "正面";
				else if (sentiment.equals(N_Constants.SENTIMENT_NEGATIVE))
					sentiment = "负面";
				else
					sentiment = "中立";
				String url = np.getUrl();
				List<String> tags = np.getTags();
				String tagsStr = "";
				for (int i = 0; i < tags.size(); i++)
					tagsStr += tags.get(i) + " ";
				//
				//
				ExternalLink eLink = new ExternalLink("newspaper-title", url,
						title);
				item.add(eLink);
				item.add(new Label("newspaper-content", content));
				//
				item.add(new Label("newspaper-keywords", tagsStr));
				item.add(new Label("newspaper-time", time));
				ExternalLink sourceLink = new ExternalLink("newspaper-source",
						"", source);
				item.add(sourceLink);
				item.add(new Label("newspaper-sentiment", "" + sentiment));
			}
		};
		this.add(NewspaperResultListView);
		// 媒体报刊搜索结果总数
		Label newspaperSearchNumLabel = new Label("newspaperResultsNum",
				new PropertyModel<Integer>(this, "newspaperResultsNum"));
		this.add(newspaperSearchNumLabel);
	}

	public int getWeiboResultsNum() {
		return weiboResultsNum;
	}

	public void setWeiboResultsNum(int weiboResultsNum) {
		this.weiboResultsNum = weiboResultsNum;
	}

	public int getBbsResultsNum() {
		return bbsResultsNum;
	}

	public void setBbsResultsNum(int bbsResultsNum) {
		this.bbsResultsNum = bbsResultsNum;
	}

	public int getNewsResultsNum() {
		return newsResultsNum;
	}

	public void setNewsResultsNum(int newsResultsNum) {
		this.newsResultsNum = newsResultsNum;
	}

	public int getNewspaperResultsNum() {
		return newspaperResultsNum;
	}

	public void setNewspaperResultsNum(int newspaperResultsNum) {
		this.newspaperResultsNum = newspaperResultsNum;
	}

	//
}
