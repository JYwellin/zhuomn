package newSnas2;

import org.apache.wicket.Page;
import org.apache.wicket.protocol.http.WebApplication;

public class NewSnasApplication extends WebApplication {

	@Override
	public Class<? extends Page> getHomePage() {
		// TODO Auto-generated method stub
		return NewIndex.class;
	}

}
