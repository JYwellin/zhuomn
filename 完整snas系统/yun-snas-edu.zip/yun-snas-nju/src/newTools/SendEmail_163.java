package newTools;

public class SendEmail_163 {
	public void SendEmail(String to, String subject, String content){
		//这个类主要是设置邮件   
	     EmailSendInfo mailInfo = new EmailSendInfo();    
	     mailInfo.setMailServerHost("smtp.163.com");    
	     mailInfo.setMailServerPort("25");    
	     mailInfo.setValidate(true);    
	     mailInfo.setUserName("snas_admin@163.com");    
	     mailInfo.setPassword("snasadmin");//您的邮箱密码    
	     mailInfo.setFromAddress("snas_admin@163.com");
	     //
	     mailInfo.setToAddress(to);    
	     mailInfo.setSubject(subject);    
	     mailInfo.setContent(content); 
	     //这个类主要来发送邮件   
	     EmailSender sms = new EmailSender();   
	     sms.sendTextMail(mailInfo);//发送文体格式    
	}
}
