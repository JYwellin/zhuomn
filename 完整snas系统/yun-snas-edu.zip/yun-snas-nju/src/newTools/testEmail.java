package newTools;

public class testEmail {
	public static void main(String[] args){   
        //这个类主要是设置邮件   
     EmailSendInfo mailInfo = new EmailSendInfo();    
     mailInfo.setMailServerHost("smtp.163.com");    
     mailInfo.setMailServerPort("25");    
     mailInfo.setValidate(true);    
     mailInfo.setUserName("ken_niu@163.com");    
     mailInfo.setPassword("kenniuliqiang");//您的邮箱密码    
     mailInfo.setFromAddress("ken_niu@163.com");    
     mailInfo.setToAddress("ken_niu@163.com");    
     mailInfo.setSubject("test subject");    
     mailInfo.setContent("test content");    
        //这个类主要来发送邮件   
     EmailSender sms = new EmailSender();   
     
         sms.sendTextMail(mailInfo);//发送文体格式    
         sms.sendHtmlMail(mailInfo);//发送html格式   
   }
}
